import math
import bpy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty)
from bpy_extras import view3d_utils
from mathutils import Vector, geometry

KAPPA = 0.5522847498307936  # circle approximation constant for cubic beziers


# ----------------------------------------------------------------------------
# Spline snapshot helpers
# Edit-mode curve data is awkward to resize, so heavy operations snapshot the
# bezier splines into plain python objects, change them, and write them back.
# ----------------------------------------------------------------------------

class PT:
    __slots__ = ("co", "hl", "hr", "hlt", "hrt", "radius", "tilt", "sel")

    def __init__(self, co, hl=None, hr=None, hlt="FREE", hrt="FREE", radius=1.0, tilt=0.0, sel=False):
        self.co = Vector(co)
        self.hl = Vector(hl) if hl is not None else self.co.copy()
        self.hr = Vector(hr) if hr is not None else self.co.copy()
        self.hlt, self.hrt, self.radius, self.tilt, self.sel = hlt, hrt, radius, tilt, sel

    def copy(self):
        return PT(self.co, self.hl, self.hr, self.hlt, self.hrt, self.radius, self.tilt, self.sel)


class SP:
    __slots__ = ("pts", "cyclic", "res", "smooth", "mat")

    def __init__(self, pts=None, cyclic=False, res=12, smooth=True, mat=0):
        self.pts = pts or []
        self.cyclic, self.res, self.smooth, self.mat = cyclic, res, smooth, mat


def snapshot(curve, convert=False):
    out = []
    for s in curve.splines:
        if s.type != 'BEZIER':
            if not convert:
                raise ValueError("Only Bezier splines are supported. Use 'Convert To Spline' first.")
            kind = 'VECTOR' if s.type == 'POLY' else 'AUTO'
            pts = [PT(p.co.xyz, hlt=kind, hrt=kind, radius=p.radius, tilt=p.tilt) for p in s.points]
            out.append(SP(pts, s.use_cyclic_u, s.resolution_u, s.use_smooth, s.material_index))
            continue
        pts = []
        for b in s.bezier_points:
            sel = b.select_control_point or b.select_left_handle or b.select_right_handle
            pts.append(PT(b.co, b.handle_left, b.handle_right, b.handle_left_type,
                          b.handle_right_type, b.radius, b.tilt, sel))
        out.append(SP(pts, s.use_cyclic_u, s.resolution_u, s.use_smooth, s.material_index))
    return out


def restore(curve, splines):
    curve.splines.clear()
    for sd in splines:
        if not sd.pts:
            continue
        s = curve.splines.new('BEZIER')
        s.bezier_points.add(len(sd.pts) - 1)
        s.use_cyclic_u = sd.cyclic
        s.resolution_u = sd.res
        s.use_smooth = sd.smooth
        s.material_index = sd.mat
        for b, p in zip(s.bezier_points, sd.pts):
            b.handle_left_type = b.handle_right_type = 'FREE'
            b.co = p.co
            b.handle_left = p.hl
            b.handle_right = p.hr
            b.handle_left_type = p.hlt
            b.handle_right_type = p.hrt
            b.radius = p.radius
            b.tilt = p.tilt
            b.select_control_point = b.select_left_handle = b.select_right_handle = p.sel


def reverse_sp(sd):
    sd.pts.reverse()
    for p in sd.pts:
        p.hl, p.hr = p.hr, p.hl
        p.hlt, p.hrt = p.hrt, p.hlt


def freeze(p):
    """Make handles free so a point keeps its exact shape when neighbours change."""
    p.hlt = p.hrt = 'FREE'


def seg_pts(sd, i):
    """Return (a, b) for the segment starting at point i, or None if it doesn't exist."""
    n = len(sd.pts)
    if i < n - 1:
        return sd.pts[i], sd.pts[i + 1]
    if sd.cyclic and n > 1 and i == n - 1:
        return sd.pts[i], sd.pts[0]
    return None


def seg_count(sd):
    n = len(sd.pts)
    return n if sd.cyclic and n > 1 else max(n - 1, 0)


# ----------------------------------------------------------------------------
# Bezier math
# ----------------------------------------------------------------------------

def bez_point(p0, h0, h1, p1, t):
    u = 1.0 - t
    return u ** 3 * p0 + 3 * u * u * t * h0 + 3 * u * t * t * h1 + t ** 3 * p1


def bez_tangent(p0, h0, h1, p1, t):
    u = 1.0 - t
    return 3 * u * u * (h0 - p0) + 6 * u * t * (h1 - h0) + 3 * t * t * (p1 - h1)


def bez_split(p0, h0, h1, p1, t):
    """De Casteljau split. Returns (left4, right4) tuples of control points."""
    a, b, c = p0.lerp(h0, t), h0.lerp(h1, t), h1.lerp(p1, t)
    d, e = a.lerp(b, t), b.lerp(c, t)
    m = d.lerp(e, t)
    return (p0.copy(), a, d, m), (m.copy(), e, c, p1.copy())


def bez_length(p0, h0, h1, p1, t0=0.0, t1=1.0, n=24):
    total, prev = 0.0, bez_point(p0, h0, h1, p1, t0)
    for i in range(1, n + 1):
        cur = bez_point(p0, h0, h1, p1, t0 + (t1 - t0) * i / n)
        total += (cur - prev).length
        prev = cur
    return total


def t_at_distance_from_end(p0, h0, h1, p1, dist, from_end=True, n=48):
    """Parameter t at arc-length `dist` measured from the end (or start) of a segment."""
    total, prev = 0.0, None
    ts = [i / n for i in range(n + 1)]
    if from_end:
        ts.reverse()
    for t in ts:
        cur = bez_point(p0, h0, h1, p1, t)
        if prev is not None:
            step = (cur - prev).length
            if total + step >= dist:
                f = (dist - total) / step if step > 1e-12 else 0.0
                return prev_t + (t - prev_t) * f
            total += step
        prev, prev_t = cur, t
    return 0.0 if from_end else 1.0


def spline_normal(sd):
    """Rough plane normal of a spline (Newell). Falls back to +Z."""
    pts = [p.co for p in sd.pts]
    n = Vector()
    for i, a in enumerate(pts):
        b = pts[(i + 1) % len(pts)]
        n.x += (a.y - b.y) * (a.z + b.z)
        n.y += (a.z - b.z) * (a.x + b.x)
        n.z += (a.x - b.x) * (a.y + b.y)
    return n.normalized() if n.length > 1e-9 else Vector((0, 0, 1))


# ----------------------------------------------------------------------------
# Shape builders (return list of SP)
# ----------------------------------------------------------------------------

def _corner(co):
    return PT(co, hlt='VECTOR', hrt='VECTOR')


def _smooth(co, tangent, hl_len, hr_len):
    t = Vector(tangent).normalized()
    co = Vector(co)
    return PT(co, co - t * hl_len, co + t * hr_len, 'ALIGNED', 'ALIGNED')


def make_ellipse(rx, ry):
    pts = []
    for i in range(4):
        a = i * math.pi / 2
        co = Vector((rx * math.cos(a), ry * math.sin(a), 0))
        tan = Vector((-rx * math.sin(a), ry * math.cos(a), 0))
        pts.append(PT(co, co - tan * KAPPA, co + tan * KAPPA, 'ALIGNED', 'ALIGNED'))
    return [SP(pts, True)]


def make_rectangle(length, width, radius):
    hx, hy = length / 2, width / 2
    r = max(0.0, min(radius, hx, hy))
    corners = [Vector((hx, -hy, 0)), Vector((hx, hy, 0)), Vector((-hx, hy, 0)), Vector((-hx, -hy, 0))]
    if r <= 1e-9:
        return [SP([_corner(c) for c in corners], True)]
    pts = []
    for i, c in enumerate(corners):
        prev, nxt = corners[i - 1], corners[(i + 1) % 4]
        entry = c + (prev - c).normalized() * r
        exit_ = c + (nxt - c).normalized() * r
        pts.append(PT(entry, hlt='FREE', hrt='FREE'))
        pts[-1].hr = entry + (c - entry) * KAPPA
        pts.append(PT(exit_, hlt='FREE', hrt='FREE'))
        pts[-1].hl = exit_ + (c - exit_) * KAPPA
    for i, p in enumerate(pts):  # straight sides: handles at 1/3 along the edge
        if i % 2 == 1:
            nxt = pts[(i + 1) % len(pts)]
            p.hr = p.co + (nxt.co - p.co) / 3
            nxt.hl = nxt.co + (p.co - nxt.co) / 3
    return [SP(pts, True)]


def make_arc(radius, start_deg, end_deg, pie, closed):
    a0, a1 = math.radians(start_deg), math.radians(end_deg)
    if a1 <= a0:
        a1 += 2 * math.pi
    sweep = a1 - a0
    n = max(1, math.ceil(sweep / (math.pi / 2) - 1e-5))
    step = sweep / n
    hlen = 4.0 / 3.0 * math.tan(step / 4) * radius
    pts = []
    for i in range(n + 1):
        a = a0 + step * i
        co = Vector((radius * math.cos(a), radius * math.sin(a), 0))
        tan = Vector((-math.sin(a), math.cos(a), 0))
        pts.append(PT(co, co - tan * hlen, co + tan * hlen, 'ALIGNED', 'ALIGNED'))
    if pie:
        pts.append(_corner((0, 0, 0)))
    return [SP(pts, bool(pie or closed))]


def make_ngon(radius, sides, circular):
    sides = max(3, sides)
    pts = []
    hlen = 4.0 / 3.0 * math.tan(math.pi / (2 * sides)) * radius
    for i in range(sides):
        a = 2 * math.pi * i / sides
        co = Vector((radius * math.cos(a), radius * math.sin(a), 0))
        if circular:
            pts.append(_smooth(co, (-math.sin(a), math.cos(a), 0), hlen, hlen))
        else:
            pts.append(_corner(co))
    return [SP(pts, True)]


def make_star(r1, r2, points):
    points = max(3, points)
    pts = []
    for i in range(points * 2):
        a = math.pi * i / points
        r = r1 if i % 2 == 0 else r2
        pts.append(_corner((r * math.cos(a), r * math.sin(a), 0)))
    return [SP(pts, True)]


def make_helix(r1, r2, height, turns, clockwise):
    turns = max(0.01, turns)
    segs = max(2, int(math.ceil(turns * 8)))
    total = 2 * math.pi * turns * (-1 if clockwise else 1)
    pts = []

    def state(f):
        th = total * f
        r = r1 + (r2 - r1) * f
        dr = (r2 - r1)
        co = Vector((r * math.cos(th), r * math.sin(th), height * f))
        d = Vector((dr * math.cos(th) - r * math.sin(th) * total,
                    dr * math.sin(th) + r * math.cos(th) * total, height))
        return co, d  # d = derivative wrt f

    for i in range(segs + 1):
        co, d = state(i / segs)
        h = d / (3.0 * segs)
        pts.append(PT(co, co - h, co + h, 'ALIGNED', 'ALIGNED'))
    return [SP(pts, False)]


# ----------------------------------------------------------------------------
# Object creation
# ----------------------------------------------------------------------------

def new_spline_object(context, name, splines, location=None):
    curve = bpy.data.curves.new(name, 'CURVE')
    curve.dimensions = '3D'
    curve.resolution_u = 12
    restore(curve, splines)
    obj = bpy.data.objects.new(name, curve)
    context.collection.objects.link(obj)
    if context.mode != 'OBJECT' and context.active_object is not None:
        try:
            bpy.ops.object.mode_set(mode='OBJECT')
        except RuntimeError:
            pass
    for o in context.selected_objects:
        o.select_set(False)
    obj.select_set(True)
    context.view_layer.objects.active = obj
    obj.location = location if location is not None else context.scene.cursor.location
    return obj


class _ShapeBase:
    bl_options = {'REGISTER', 'UNDO'}
    shape_name = "Shape"

    def build(self):
        raise NotImplementedError

    def execute(self, context):
        new_spline_object(context, self.shape_name, self.build())
        return {'FINISHED'}


class MAXSPLINE_OT_rectangle(_ShapeBase, bpy.types.Operator):
    bl_idname = "maxspline.rectangle"
    bl_label = "Rectangle"
    shape_name = "Rectangle"
    length: FloatProperty(name="Length", default=2.0, min=0.0, unit='LENGTH')
    width: FloatProperty(name="Width", default=1.0, min=0.0, unit='LENGTH')
    corner_radius: FloatProperty(name="Corner Radius", default=0.0, min=0.0, unit='LENGTH')

    def build(self):
        return make_rectangle(self.length, self.width, self.corner_radius)


class MAXSPLINE_OT_circle(_ShapeBase, bpy.types.Operator):
    bl_idname = "maxspline.circle"
    bl_label = "Circle"
    shape_name = "Circle"
    radius: FloatProperty(name="Radius", default=1.0, min=0.0, unit='LENGTH')

    def build(self):
        return make_ellipse(self.radius, self.radius)


class MAXSPLINE_OT_ellipse(_ShapeBase, bpy.types.Operator):
    bl_idname = "maxspline.ellipse"
    bl_label = "Ellipse"
    shape_name = "Ellipse"
    length: FloatProperty(name="Length", default=2.0, min=0.0, unit='LENGTH')
    width: FloatProperty(name="Width", default=1.0, min=0.0, unit='LENGTH')

    def build(self):
        return make_ellipse(self.length / 2, self.width / 2)


class MAXSPLINE_OT_arc(_ShapeBase, bpy.types.Operator):
    bl_idname = "maxspline.arc"
    bl_label = "Arc"
    shape_name = "Arc"
    radius: FloatProperty(name="Radius", default=1.0, min=0.0, unit='LENGTH')
    start: FloatProperty(name="From", default=0.0, subtype='ANGLE')
    end: FloatProperty(name="To", default=math.pi / 2, subtype='ANGLE')
    pie: BoolProperty(name="Pie Slice", default=False)
    closed: BoolProperty(name="Closed", default=False)

    def build(self):
        return make_arc(self.radius, math.degrees(self.start), math.degrees(self.end), self.pie, self.closed)


class MAXSPLINE_OT_donut(_ShapeBase, bpy.types.Operator):
    bl_idname = "maxspline.donut"
    bl_label = "Donut"
    shape_name = "Donut"
    radius1: FloatProperty(name="Radius 1", default=1.0, min=0.0, unit='LENGTH')
    radius2: FloatProperty(name="Radius 2", default=0.5, min=0.0, unit='LENGTH')

    def build(self):
        return make_ellipse(self.radius1, self.radius1) + make_ellipse(self.radius2, self.radius2)


class MAXSPLINE_OT_ngon(_ShapeBase, bpy.types.Operator):
    bl_idname = "maxspline.ngon"
    bl_label = "NGon"
    shape_name = "NGon"
    radius: FloatProperty(name="Radius", default=1.0, min=0.0, unit='LENGTH')
    sides: IntProperty(name="Sides", default=6, min=3, max=256)
    circular: BoolProperty(name="Circular", default=False)

    def build(self):
        return make_ngon(self.radius, self.sides, self.circular)


class MAXSPLINE_OT_star(_ShapeBase, bpy.types.Operator):
    bl_idname = "maxspline.star"
    bl_label = "Star"
    shape_name = "Star"
    radius1: FloatProperty(name="Radius 1", default=1.0, min=0.0, unit='LENGTH')
    radius2: FloatProperty(name="Radius 2", default=0.5, min=0.0, unit='LENGTH')
    points: IntProperty(name="Points", default=5, min=3, max=256)

    def build(self):
        return make_star(self.radius1, self.radius2, self.points)


class MAXSPLINE_OT_helix(_ShapeBase, bpy.types.Operator):
    bl_idname = "maxspline.helix"
    bl_label = "Helix"
    shape_name = "Helix"
    radius1: FloatProperty(name="Radius 1", default=1.0, min=0.0, unit='LENGTH')
    radius2: FloatProperty(name="Radius 2", default=1.0, min=0.0, unit='LENGTH')
    height: FloatProperty(name="Height", default=2.0, unit='LENGTH')
    turns: FloatProperty(name="Turns", default=3.0, min=0.01)
    clockwise: BoolProperty(name="Clockwise", default=False)

    def build(self):
        return make_helix(self.radius1, self.radius2, self.height, self.turns, self.clockwise)


# ----------------------------------------------------------------------------
# Interactive Line tool (click = corner, click-drag = bezier, RMB/Enter = finish)
# ----------------------------------------------------------------------------

def _view3d_context(context):
    area = context.area
    if area is None or area.type != 'VIEW_3D':
        return None, None
    region = next((r for r in area.regions if r.type == 'WINDOW'), None)
    return region, area.spaces.active.region_3d


class MAXSPLINE_OT_line(bpy.types.Operator):
    bl_idname = "maxspline.line"
    bl_label = "Line"
    bl_description = ("Draw a spline. Click = Corner, click-drag = Bezier, click the first point to close, "
                      "Right-click/Enter = finish, Backspace = remove last point, Esc = cancel, Ctrl = snap")
    bl_options = {'UNDO'}

    snap: FloatProperty(name="Ctrl Snap", description="Grid size used while holding Ctrl",
                        default=0.25, min=0.001, unit='LENGTH')

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D'

    # -- plane / projection helpers
    def _pick_plane(self):
        vd = self.rv3d.view_rotation @ Vector((0, 0, -1))
        ax = max(range(3), key=lambda i: abs(vd[i]))
        if abs(vd[ax]) > 0.999:
            n = Vector((0, 0, 0))
            n[ax] = 1.0
            return n
        if abs(vd.z) < 0.1:
            return vd.normalized()
        return Vector((0, 0, 1))

    def _hit(self, event):
        mx, my = event.mouse_x - self.region.x, event.mouse_y - self.region.y
        o = view3d_utils.region_2d_to_origin_3d(self.region, self.rv3d, (mx, my))
        d = view3d_utils.region_2d_to_vector_3d(self.region, self.rv3d, (mx, my))
        hit = geometry.intersect_line_plane(o, o + d, self.plane_co, self.plane_no)
        if hit is None or (hit - o).dot(d) < 0:
            return None
        if event.ctrl:
            rel = hit - self.plane_co
            s = self.snap
            hit = self.plane_co + Vector((round(rel.x / s) * s, round(rel.y / s) * s, round(rel.z / s) * s))
        return hit

    def _inside(self, event):
        r = self.region
        return r.x <= event.mouse_x < r.x + r.width and r.y <= event.mouse_y < r.y + r.height

    def _screen(self, co):
        p = view3d_utils.location_3d_to_region_2d(self.region, self.rv3d, co)
        return p

    # -- curve writing
    def _write(self, hover=None):
        if self.origin is None:
            return
        pts = [p.copy() for p in self.pts]
        if hover is not None and not self.closed:
            pts.append(_corner(hover))
        for p in pts:
            p.co = p.co - self.origin
            p.hl = p.hl - self.origin
            p.hr = p.hr - self.origin
        restore(self.curve, [SP(pts, self.closed)] if pts else [])

    def _status(self, context):
        context.workspace.status_text_set(
            "Line:  LMB click = Corner  |  LMB drag = Bezier  |  click first point = close  |  "
            "RMB/Enter = finish  |  Backspace = undo point  |  Esc = cancel  |  Ctrl = snap")

    def invoke(self, context, event):
        self.region, self.rv3d = _view3d_context(context)
        if self.region is None:
            self.report({'WARNING'}, "Run from a 3D viewport")
            return {'CANCELLED'}
        self.plane_co = context.scene.cursor.location.copy()
        self.plane_no = self._pick_plane()
        self.pts, self.closed, self.dragging, self.press_px = [], False, False, None
        self.origin = None
        self.curve = bpy.data.curves.new("Line", 'CURVE')
        self.curve.dimensions = '3D'
        self.curve.resolution_u = 12
        self.obj = bpy.data.objects.new("Line", self.curve)
        context.collection.objects.link(self.obj)
        for o in context.selected_objects:
            o.select_set(False)
        self.obj.select_set(True)
        context.view_layer.objects.active = self.obj
        self._status(context)
        context.window.cursor_modal_set('CROSSHAIR')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _cleanup(self, context):
        context.workspace.status_text_set(None)
        context.window.cursor_modal_restore()

    def _cancel(self, context):
        self._cleanup(context)
        obj, curve = self.obj, self.curve
        bpy.data.objects.remove(obj, do_unlink=True)
        bpy.data.curves.remove(curve)
        return {'CANCELLED'}

    def _finish(self, context):
        self._write(None)
        self._cleanup(context)
        if len(self.pts) < 2:
            return self._cancel_silent(context)
        return {'FINISHED'}

    def _cancel_silent(self, context):
        bpy.data.objects.remove(self.obj, do_unlink=True)
        bpy.data.curves.remove(self.curve)
        return {'CANCELLED'}

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN', 'TRACKPADZOOM',
                          'NDOF_MOTION'} or event.type.startswith('NUMPAD') or \
                (event.type in {'LEFTMOUSE', 'MOUSEMOVE'} and not self._inside(event) and not self.dragging):
            return {'PASS_THROUGH'}
        context.area.tag_redraw()

        if event.type in {'ESC'} and event.value == 'PRESS':
            return self._cancel(context)
        if event.type in {'RET', 'NUMPAD_ENTER', 'SPACE'} and event.value == 'PRESS':
            return self._finish(context)
        if event.type == 'RIGHTMOUSE' and event.value == 'PRESS':
            return self._finish(context)
        if event.type == 'BACK_SPACE' and event.value == 'PRESS':
            if self.pts:
                self.pts.pop()
                self.closed = False
                if not self.pts:
                    return self._cancel(context)
                self._write(self._hit(event))
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            hit = self._hit(event)
            if hit is None:
                return {'RUNNING_MODAL'}
            if self.origin is None:
                self.origin = hit.copy()
                self.obj.location = self.origin
            # close on first point
            if len(self.pts) >= 2:
                sp = self._screen(self.pts[0].co)
                if sp is not None and (sp - Vector((event.mouse_x - self.region.x,
                                                    event.mouse_y - self.region.y))).length < 12:
                    self.closed = True
                    return self._finish(context)
            self.pts.append(_corner(hit))
            self.dragging = True
            self.press_px = (event.mouse_x, event.mouse_y)
            self._write(None)
            return {'RUNNING_MODAL'}

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            self.dragging = False
            self._write(self._hit(event))
            return {'RUNNING_MODAL'}

        if event.type == 'MOUSEMOVE':
            hit = self._hit(event)
            if hit is None:
                return {'RUNNING_MODAL'}
            if self.dragging and self.pts:
                dx = event.mouse_x - self.press_px[0]
                dy = event.mouse_y - self.press_px[1]
                p = self.pts[-1]
                if math.hypot(dx, dy) > 4:
                    p.hlt = p.hrt = 'ALIGNED'
                    p.hr = hit
                    p.hl = p.co * 2 - hit
                self._write(None)
            else:
                self._write(hit)
            return {'RUNNING_MODAL'}

        return {'RUNNING_MODAL'}


# ----------------------------------------------------------------------------
# Edit-mode operator helpers
# ----------------------------------------------------------------------------

def _edit_curve_poll(context):
    o = context.active_object
    return o is not None and o.type == 'CURVE' and context.mode == 'EDIT_CURVE'


class _EditSnapshotOp:
    """Base for ops that snapshot -> transform -> restore the active curve."""
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return _edit_curve_poll(context)

    def transform(self, context, splines):
        raise NotImplementedError

    def execute(self, context):
        obj = context.active_object
        bpy.ops.object.mode_set(mode='OBJECT')
        try:
            sps = snapshot(obj.data)
            result = self.transform(context, sps)
            if result is None:
                result = sps
            restore(obj.data, result)
        except ValueError as e:
            self.report({'ERROR'}, str(e))
            bpy.ops.object.mode_set(mode='EDIT')
            return {'CANCELLED'}
        bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}


# -- Vertex types -----------------------------------------------------------

_VTYPES = {
    'CORNER': ('VECTOR', "Corner", "Sharp vertex, straight segments"),
    'SMOOTH': ('AUTOMATIC', "Smooth", "Automatically smoothed vertex, no handles"),
    'BEZIER': ('ALIGNED', "Bezier", "Aligned tangent handles"),
    'BEZIER_CORNER': ('FREE_ALIGN', "Bezier Corner", "Independent tangent handles"),
}


class MAXSPLINE_OT_vertex_type(bpy.types.Operator):
    bl_idname = "maxspline.vertex_type"
    bl_label = "Vertex Type"
    bl_options = {'REGISTER', 'UNDO'}
    kind: EnumProperty(name="Type", items=[(k, v[1], v[2]) for k, v in _VTYPES.items()])

    @classmethod
    def poll(cls, context):
        return _edit_curve_poll(context)

    @classmethod
    def description(cls, context, properties):
        return _VTYPES[properties.kind][2]

    def execute(self, context):
        # Make sure selected control points also select their handles
        for s in context.active_object.data.splines:
            for b in s.bezier_points:
                if b.select_control_point:
                    b.select_left_handle = b.select_right_handle = True
        bpy.ops.curve.handle_type_set(type=_VTYPES[self.kind][0])
        return {'FINISHED'}


# -- Refine / Insert --------------------------------------------------------

def closest_on_segment_screen(region, rv3d, mouse, a, b, steps=24):
    """Find parameter t on bezier segment (a,b PT) closest to mouse in screen space."""
    best = (1e9, 0.0)
    prev, prev_t = None, 0.0
    for i in range(steps + 1):
        t = i / steps
        w = bez_point(a.co, a.hr, b.hl, b.co, t)
        sp = view3d_utils.location_3d_to_region_2d(region, rv3d, w)
        if sp is None:
            prev = None
            continue
        if prev is not None:
            seg = sp - prev
            l2 = seg.length_squared
            f = 0.0 if l2 < 1e-12 else max(0.0, min(1.0, (mouse - prev).dot(seg) / l2))
            d = (prev + seg * f - mouse).length
            if d < best[0]:
                best = (d, prev_t + (t - prev_t) * f)
        prev, prev_t = sp, t
    return best


def insert_point(sd, i, t):
    """Insert a point on segment i of spline sd at parameter t (exact shape preserved)."""
    a, b = seg_pts(sd, i)
    (p0, h0, h1, m), (m2, g1, g2, p3) = bez_split(a.co, a.hr, b.hl, b.co, t)
    rad, tilt = (a.radius + b.radius) / 2, (a.tilt + b.tilt) / 2
    if a.hrt == 'VECTOR' and b.hlt == 'VECTOR':
        # straight segment: new vertex is a Corner, neighbours keep their handle types
        new = PT(m, m, m, 'VECTOR', 'VECTOR', rad, tilt, True)
    else:
        freeze(a)
        freeze(b)
        a.hr = h0
        b.hl = g2
        new = PT(m, h1, g1, 'ALIGNED', 'ALIGNED', rad, tilt, True)
    sd.pts.insert(i + 1, new)
    return new


class MAXSPLINE_OT_refine(bpy.types.Operator):
    bl_idname = "maxspline.refine"
    bl_label = "Refine"
    bl_description = "Click on spline segments to insert vertices. Right-click/Esc/Enter to finish"
    bl_options = {'UNDO'}

    @classmethod
    def poll(cls, context):
        return _edit_curve_poll(context) and context.area and context.area.type == 'VIEW_3D'

    def invoke(self, context, event):
        self.region, self.rv3d = _view3d_context(context)
        context.window.cursor_modal_set('CROSSHAIR')
        context.workspace.status_text_set("Refine:  LMB on a segment = insert vertex  |  RMB/Esc/Enter = finish")
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _end(self, context):
        context.workspace.status_text_set(None)
        context.window.cursor_modal_restore()

    def _pick(self, context, event):
        obj = context.active_object
        mouse = Vector((event.mouse_x - self.region.x, event.mouse_y - self.region.y))
        mw = obj.matrix_world
        bpy.ops.object.mode_set(mode='OBJECT')
        try:
            sps = snapshot(obj.data)
        except ValueError as e:
            bpy.ops.object.mode_set(mode='EDIT')
            self.report({'ERROR'}, str(e))
            return
        best = (16.0, None, None, None)  # pixels threshold
        for si, sd in enumerate(sps):
            for i in range(seg_count(sd)):
                a, b = seg_pts(sd, i)
                wa = PT(mw @ a.co, mw @ a.hl, mw @ a.hr)
                wb = PT(mw @ b.co, mw @ b.hl, mw @ b.hr)
                d, t = closest_on_segment_screen(self.region, self.rv3d, mouse, wa, wb)
                if d < best[0] and 0.001 < t < 0.999:
                    best = (d, si, i, t)
        if best[1] is not None:
            for sd in sps:
                for p in sd.pts:
                    p.sel = False
            insert_point(sps[best[1]], best[2], best[3])
            restore(obj.data, sps)
        bpy.ops.object.mode_set(mode='EDIT')

    def modal(self, context, event):
        if event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN',
                          'TRACKPADZOOM'} or event.type.startswith('NUMPAD'):
            return {'PASS_THROUGH'}
        if event.type in {'RIGHTMOUSE', 'ESC', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self._end(context)
            return {'FINISHED'}
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            r = self.region
            if r.x <= event.mouse_x < r.x + r.width and r.y <= event.mouse_y < r.y + r.height:
                self._pick(context, event)
                context.area.tag_redraw()
                return {'RUNNING_MODAL'}
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}


class MAXSPLINE_OT_divide(bpy.types.Operator):
    bl_idname = "maxspline.divide"
    bl_label = "Divide"
    bl_description = "Insert evenly spaced vertices into the selected segments"
    bl_options = {'REGISTER', 'UNDO'}
    count: IntProperty(name="Vertices", default=1, min=1, max=100)

    @classmethod
    def poll(cls, context):
        return _edit_curve_poll(context)

    def execute(self, context):
        bpy.ops.curve.subdivide(number_cuts=self.count)
        return {'FINISHED'}


# -- Break -----------------------------------------------------------------

class MAXSPLINE_OT_break(_EditSnapshotOp, bpy.types.Operator):
    bl_idname = "maxspline.break_vertex"
    bl_label = "Break"
    bl_description = "Split the spline at the selected vertices (each becomes two overlapping end vertices)"

    def transform(self, context, sps):
        out = []
        for sd in sps:
            n = len(sd.pts)
            cuts = [i for i, p in enumerate(sd.pts) if p.sel
                    and (sd.cyclic or 0 < i < n - 1)]
            if not cuts:
                out.append(sd)
                continue
            if sd.cyclic:
                # rotate so first cut is index 0 and unroll
                k = cuts[0]
                sd.pts = sd.pts[k:] + sd.pts[:k]
                cuts = sorted({(c - k) % n for c in cuts})
                cuts = [c for c in cuts if c != 0]
                sd.cyclic = False
                first_copy = sd.pts[0].copy()
                sd.pts.append(first_copy)  # closing duplicate at the end
                pieces_pts = self._split(sd.pts, cuts)
            else:
                pieces_pts = self._split(sd.pts, cuts)
            for pp in pieces_pts:
                out.append(SP(pp, False, sd.res, sd.smooth, sd.mat))
        return out

    @staticmethod
    def _split(pts, cuts):
        pieces, start = [], 0
        for c in cuts:
            a = pts[start:c + 1]
            tail = pts[c].copy()
            freeze(a[-1])
            freeze(tail)
            pieces.append(a)
            pts[c] = tail
            start = c
        pieces.append(pts[start:])
        for pc in pieces:
            for p in (pc[0], pc[-1]):
                freeze(p)
        return pieces


# -- Weld ------------------------------------------------------------------

class MAXSPLINE_OT_weld(_EditSnapshotOp, bpy.types.Operator):
    bl_idname = "maxspline.weld"
    bl_label = "Weld"
    bl_description = "Merge selected end vertices that are within the threshold distance"
    threshold: FloatProperty(name="Threshold", default=0.1, min=0.0, unit='LENGTH')

    def transform(self, context, sps):
        thr = self.threshold
        changed = True
        while changed:
            changed = False
            ends = []
            for si, sd in enumerate(sps):
                if sd.cyclic or len(sd.pts) < 1:
                    continue
                if sd.pts[0].sel:
                    ends.append((si, 0))
                if len(sd.pts) > 1 and sd.pts[-1].sel:
                    ends.append((si, 1))
            for ia in range(len(ends)):
                for ib in range(ia + 1, len(ends)):
                    (sa, ea), (sb, eb) = ends[ia], ends[ib]
                    pa = sps[sa].pts[0 if ea == 0 else -1]
                    pb = sps[sb].pts[0 if eb == 0 else -1]
                    if (pa.co - pb.co).length > thr:
                        continue
                    self._join(sps, sa, ea, sb, eb)
                    changed = True
                    break
                if changed:
                    break
        return sps

    @staticmethod
    def _join(sps, sa, ea, sb, eb):
        A, B = sps[sa], sps[sb]
        if sa == sb:
            # Close the spline: first and last merge
            first, last = A.pts[0], A.pts[-1]
            mid = (first.co + last.co) / 2
            m = PT(mid, last.hl + (mid - last.co), first.hr + (mid - first.co), last.hlt, first.hrt,
                   first.radius, first.tilt, True)
            A.pts = [m] + A.pts[1:-1]
            A.cyclic = True
            return
        if ea == 0:
            reverse_sp(A)  # make A's join end the last point
        if eb == 1:
            reverse_sp(B)  # make B's join end the first point
        a, b = A.pts[-1], B.pts[0]
        mid = (a.co + b.co) / 2
        m = PT(mid, a.hl + (mid - a.co), b.hr + (mid - b.co), a.hlt, b.hrt, a.radius, a.tilt, True)
        A.pts = A.pts[:-1] + [m] + B.pts[1:]
        del sps[sb]


# -- Fillet / Chamfer ------------------------------------------------------

def _tangent_in(a, b, t=1.0):
    return bez_tangent(a.co, a.hr, b.hl, b.co, t)


class _CornerCutBase(_EditSnapshotOp):
    mode = 'FILLET'

    def transform(self, context, sps):
        amount = self.amount
        out = []
        for sd in sps:
            self._process(sd, amount)
            out.append(sd)
        return out

    def _process(self, sd, amount):
        # process from the back so indices stay valid
        n = len(sd.pts)
        indices = [i for i, p in enumerate(sd.pts) if p.sel
                   and (sd.cyclic or 0 < i < n - 1)]
        for i in sorted(indices, reverse=True):
            self._cut(sd, i, amount)

    def _cut(self, sd, i, amount):
        n = len(sd.pts)
        if n < 3:
            return
        pi, ni = (i - 1) % n, (i + 1) % n
        P, V, N = sd.pts[pi], sd.pts[i], sd.pts[ni]
        # geometry of incoming and outgoing segments around V
        len_in = bez_length(P.co, P.hr, V.hl, V.co)
        len_out = bez_length(V.co, V.hr, N.hl, N.co)
        u = _tangent_in(P, V, 1.0)       # direction arriving at V
        w = bez_tangent(V.co, V.hr, N.hl, N.co, 0.0)  # direction leaving V
        if u.length < 1e-9 or w.length < 1e-9:
            return
        u.normalize()
        w.normalize()
        phi = u.angle(w)
        if phi < 1e-4:
            return
        if self.mode == 'FILLET':
            d = amount * math.tan(phi / 2)
        else:
            d = amount
        d = min(d, len_in * 0.5, len_out * 0.5)
        if d <= 1e-9:
            return
        # split incoming segment at distance d from V, outgoing at d from V
        t_in = t_at_distance_from_end(P.co, P.hr, V.hl, V.co, d, from_end=True)
        t_out = t_at_distance_from_end(V.co, V.hr, N.hl, N.co, d, from_end=False)
        (_, ph, ah_l, a_co), _unused = bez_split(P.co, P.hr, V.hl, V.co, t_in)
        _unused2, (b_co, bh_r, nh, _) = bez_split(V.co, V.hr, N.hl, N.co, t_out)
        straight_in = P.hrt == 'VECTOR' and V.hlt == 'VECTOR'
        straight_out = V.hrt == 'VECTOR' and N.hlt == 'VECTOR'
        A = PT(a_co, ah_l, a_co, 'VECTOR' if straight_in else 'FREE', 'FREE', V.radius, V.tilt, True)
        B = PT(b_co, b_co, bh_r, 'FREE', 'VECTOR' if straight_out else 'FREE', V.radius, V.tilt, True)
        if self.mode == 'CHAMFER':
            A.hrt = B.hlt = 'VECTOR'
        if self.mode == 'FILLET':
            ta = _tangent_in(P, V, t_in).normalized()
            tb = bez_tangent(V.co, V.hr, N.hl, N.co, t_out).normalized()
            R = d / math.tan(phi / 2)
            L = 4.0 / 3.0 * math.tan(phi / 4) * R
            A.hr = a_co + ta * L
            B.hl = b_co - tb * L
        else:
            A.hr = a_co + (b_co - a_co) / 3
            B.hl = b_co + (a_co - b_co) / 3
        if not straight_in:
            P.hrt = 'FREE'
            P.hr = ph
        if not straight_out:
            N.hlt = 'FREE'
            N.hl = nh
        # replace V by A, B (handle wraparound for cyclic spline when i == 0 or n-1)
        sd.pts[i:i + 1] = [A, B]


class MAXSPLINE_OT_fillet(_CornerCutBase, bpy.types.Operator):
    bl_idname = "maxspline.fillet"
    bl_label = "Fillet"
    bl_description = "Round the selected corner vertices with a circular fillet of the given radius"
    mode = 'FILLET'
    amount: FloatProperty(name="Radius", default=0.2, min=0.0, unit='LENGTH')


class MAXSPLINE_OT_chamfer(_CornerCutBase, bpy.types.Operator):
    bl_idname = "maxspline.chamfer"
    bl_label = "Chamfer"
    bl_description = "Cut the selected corner vertices with a straight bevel of the given distance"
    mode = 'CHAMFER'
    amount: FloatProperty(name="Distance", default=0.2, min=0.0, unit='LENGTH')


# -- Outline ---------------------------------------------------------------

def _seg_curv_start(a, b, nrm):
    d1, d2 = a.hr - a.co, b.hl - a.hr
    l = d1.length
    if l < 1e-9:
        return 0.0
    return (2.0 / 3.0) * d1.cross(d2).dot(nrm) / (l ** 3)


def _seg_curv_end(a, b, nrm):
    d1, d2 = b.co - b.hl, a.hr - b.hl
    l = d1.length
    if l < 1e-9:
        return 0.0
    return (2.0 / 3.0) * d1.cross(d2).dot(nrm) / (l ** 3)


def outline_spline(sd, dist):
    """Offset a spline to its left (relative to its plane normal) by `dist`."""
    n = len(sd.pts)
    nrm = spline_normal(sd)
    if sd.cyclic is False and n > 1:
        pass
    new = []
    for i, p in enumerate(sd.pts):
        has_prev = sd.cyclic or i > 0
        has_next = sd.cyclic or i < n - 1
        prev_seg = (sd.pts[(i - 1) % n], p) if has_prev else None
        next_seg = (p, sd.pts[(i + 1) % n]) if has_next else None
        t_out = bez_tangent(p.co, p.hr, next_seg[1].hl, next_seg[1].co, 0.0) if next_seg else None
        t_in = bez_tangent(prev_seg[0].co, prev_seg[0].hr, p.hl, p.co, 1.0) if prev_seg else None
        if t_out is not None and t_out.length < 1e-9:
            t_out = (next_seg[1].co - p.co)
        if t_in is not None and t_in.length < 1e-9:
            t_in = (p.co - prev_seg[0].co)
        t_in = t_in.normalized() if t_in is not None and t_in.length > 1e-9 else None
        t_out = t_out.normalized() if t_out is not None and t_out.length > 1e-9 else None
        n_in = nrm.cross(t_in) if t_in is not None else None
        n_out = nrm.cross(t_out) if t_out is not None else None
        ns = [x for x in (n_in, n_out) if x is not None]
        if not ns:
            new.append(p.copy())
            continue
        if len(ns) == 2:
            mid = ns[0] + ns[1]
            dot = ns[0].dot(ns[1])
            if mid.length < 1e-6:
                off = ns[0] * dist
            else:
                off = mid.normalized() * dist / max(math.sqrt((1 + dot) / 2), 0.2)
        else:
            off = ns[0] * dist
        q = p.copy()
        q.co = p.co + off
        # handle length scaling by curvature so curved segments offset correctly
        s_l = s_r = 1.0
        if prev_seg:
            s_l = 1.0 - dist * _seg_curv_end(prev_seg[0], prev_seg[1], nrm)
        if next_seg:
            s_r = 1.0 - dist * _seg_curv_start(next_seg[0], next_seg[1], nrm)
        if p.hlt == 'VECTOR' or p.hrt == 'VECTOR':
            pass
        q.hl = q.co + (p.hl - p.co) * max(s_l, 0.01)
        q.hr = q.co + (p.hr - p.co) * max(s_r, 0.01)
        q.sel = False
        new.append(q)
    # Straight (vector) sides: recompute exact handles at 1/3 along the edge
    return SP(new, sd.cyclic, sd.res, sd.smooth, sd.mat)


class MAXSPLINE_OT_outline(_EditSnapshotOp, bpy.types.Operator):
    bl_idname = "maxspline.outline"
    bl_label = "Outline"
    bl_description = "Create a copy of the selected splines offset by a distance (positive = left of the path)"
    distance: FloatProperty(name="Distance", default=0.1, unit='LENGTH')
    center: BoolProperty(name="Center", description="Offset both sides by half the distance", default=False)
    keep_original: BoolProperty(name="Keep Original", default=True)

    def transform(self, context, sps):
        out = []
        for sd in sps:
            has_sel = any(p.sel for p in sd.pts)
            if not has_sel:
                out.append(sd)
                continue
            if self.center:
                a = outline_spline(sd, self.distance / 2)
                b = outline_spline(sd, -self.distance / 2)
                out += [a, b]
            else:
                if self.keep_original:
                    out.append(sd)
                out.append(outline_spline(sd, self.distance))
        return out


# -- Explode / Attach / Detach etc. ---------------------------------------

class MAXSPLINE_OT_explode(bpy.types.Operator):
    bl_idname = "maxspline.explode"
    bl_label = "Explode"
    bl_description = "Split each spline of the selected curve objects into its own object"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and any(o.type == 'CURVE' for o in context.selected_objects)

    def execute(self, context):
        made = 0
        for obj in [o for o in context.selected_objects if o.type == 'CURVE']:
            try:
                sps = snapshot(obj.data)
            except ValueError as e:
                self.report({'ERROR'}, str(e))
                return {'CANCELLED'}
            if len(sps) < 2:
                continue
            for k, sd in enumerate(sps[1:], start=1):
                data = obj.data.copy()
                restore(data, [sd])
                new = obj.copy()
                new.data = data
                new.name = "%s.%03d" % (obj.name, k)
                for c in obj.users_collection:
                    c.objects.link(new)
                made += 1
            restore(obj.data, [sps[0]])
        self.report({'INFO'}, "Created %d new spline objects" % made)
        return {'FINISHED'}


class MAXSPLINE_OT_attach(bpy.types.Operator):
    bl_idname = "maxspline.attach"
    bl_label = "Attach"
    bl_description = "Join the selected curve objects into the active one"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'OBJECT' and context.active_object is not None \
            and context.active_object.type == 'CURVE' \
            and len([o for o in context.selected_objects if o.type == 'CURVE']) > 1

    def execute(self, context):
        return bpy.ops.object.join()


class MAXSPLINE_OT_convert(bpy.types.Operator):
    bl_idname = "maxspline.convert"
    bl_label = "Convert To Spline"
    bl_description = "Convert the active mesh edges / curve (poly, NURBS) to an editable Bezier spline"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type in {'MESH', 'CURVE'} and context.mode == 'OBJECT'

    def execute(self, context):
        obj = context.active_object
        if obj.type == 'MESH':
            bpy.ops.object.convert(target='CURVE')
            obj = context.active_object
        sps = snapshot(obj.data, convert=True)
        for sd in sps:
            for p in sd.pts:
                p.sel = False
        restore(obj.data, sps)
        obj.data.dimensions = '3D'
        return {'FINISHED'}


_EDIT_OP_DESC = {
    'CONNECT': "Join the two selected end vertices with a new segment",
    'CLOSE': "Toggle the closed state of the selected splines",
    'REVERSE': "Reverse the direction of the selected splines",
    'MAKE_FIRST': "Make the selected vertex the first vertex of its spline",
    'DETACH': "Move the selected vertices to a new curve object",
    'DELETE_VERT': "Delete the selected vertices",
    'DELETE_SEG': "Delete the selected segments",
    'SELECT_SPLINE': "Select all vertices of the splines that are touched by the selection",
}


class MAXSPLINE_OT_edit_op(bpy.types.Operator):
    """Thin wrapper over native curve edit operators so they show up with Max names."""
    bl_idname = "maxspline.edit_op"
    bl_label = "Spline Op"
    bl_options = {'REGISTER', 'UNDO'}
    op: EnumProperty(items=[
        ('CONNECT', "Connect", "Join the two selected end vertices with a new segment"),
        ('CLOSE', "Close/Open", "Toggle the closed state of the selected splines"),
        ('REVERSE', "Reverse", "Reverse the direction of the selected splines"),
        ('MAKE_FIRST', "Make First", "Make the selected vertex the first vertex of its spline"),
        ('DETACH', "Detach", "Move the selected vertices to a new curve object"),
        ('DELETE_VERT', "Delete Vertex", "Delete selected vertices"),
        ('DELETE_SEG', "Delete Segment", "Delete selected segments"),
        ('SELECT_SPLINE', "Select Spline", "Select all vertices of the touched splines"),
    ])

    @classmethod
    def poll(cls, context):
        return _edit_curve_poll(context)

    @classmethod
    def description(cls, context, properties):
        return _EDIT_OP_DESC.get(properties.op, "")

    def execute(self, context):
        o = self.op
        try:
            if o == 'CONNECT':
                bpy.ops.curve.make_segment()
            elif o == 'CLOSE':
                bpy.ops.curve.cyclic_toggle()
            elif o == 'REVERSE':
                bpy.ops.curve.switch_direction()
            elif o == 'MAKE_FIRST':
                bpy.ops.curve.make_first()
            elif o == 'DETACH':
                bpy.ops.curve.separate()
            elif o == 'DELETE_VERT':
                bpy.ops.curve.delete(type='VERT')
            elif o == 'DELETE_SEG':
                bpy.ops.curve.delete(type='SEGMENT')
            elif o == 'SELECT_SPLINE':
                bpy.ops.curve.select_linked()
        except RuntimeError as e:
            self.report({'WARNING'}, str(e).strip().split("\n")[-1])
            return {'CANCELLED'}
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------------

class SPLINES_PT_main(bpy.types.Panel):
    bl_label = "Max Splines"
    bl_idname = "MAXSPLINE_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_modeling"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.label(text="Object Type")
        col = layout.column(align=True)
        col.operator("maxspline.line", icon='IPO_LINEAR')
        row = col.row(align=True)
        row.operator("maxspline.rectangle", icon='MESH_PLANE')
        row.operator("maxspline.circle", icon='MESH_CIRCLE')
        row = col.row(align=True)
        row.operator("maxspline.ellipse")
        row.operator("maxspline.arc")
        row = col.row(align=True)
        row.operator("maxspline.donut")
        row.operator("maxspline.ngon")
        row = col.row(align=True)
        row.operator("maxspline.star")
        row.operator("maxspline.helix")


class SPLINES_PT_object(bpy.types.Panel):
    bl_label = "Object Tools"
    bl_idname = "MAXSPLINE_PT_object"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "MAXSPLINE_PT_main"

    def draw(self, context):
        col = self.layout.column(align=True)
        col.operator("maxspline.convert", icon='CURVE_DATA')
        col.operator("maxspline.attach")
        col.operator("maxspline.explode")


class SPLINES_PT_vertex(bpy.types.Panel):
    bl_label = "Editable Spline"
    bl_idname = "MAXSPLINE_PT_vertex"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "MAXSPLINE_PT_main"

    @classmethod
    def poll(cls, context):
        return _edit_curve_poll(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Vertex Type")
        grid = layout.grid_flow(row_major=True, columns=2, align=True)
        for k, v in _VTYPES.items():
            grid.operator("maxspline.vertex_type", text=v[1]).kind = k

        layout.label(text="Geometry")
        col = layout.column(align=True)
        col.operator("maxspline.refine", icon='ADD')
        row = col.row(align=True)
        row.operator("maxspline.divide")
        row.operator("maxspline.break_vertex")
        row = col.row(align=True)
        row.operator("maxspline.weld")
        row.operator("maxspline.edit_op", text="Connect").op = 'CONNECT'
        row = col.row(align=True)
        row.operator("maxspline.fillet")
        row.operator("maxspline.chamfer")
        col.operator("maxspline.outline")

        layout.label(text="Spline")
        col = layout.column(align=True)
        row = col.row(align=True)
        row.operator("maxspline.edit_op", text="Close / Open").op = 'CLOSE'
        row.operator("maxspline.edit_op", text="Reverse").op = 'REVERSE'
        row = col.row(align=True)
        row.operator("maxspline.edit_op", text="Make First").op = 'MAKE_FIRST'
        row.operator("maxspline.edit_op", text="Detach").op = 'DETACH'
        row = col.row(align=True)
        row.operator("maxspline.edit_op", text="Delete Vertex").op = 'DELETE_VERT'
        row.operator("maxspline.edit_op", text="Delete Segment").op = 'DELETE_SEG'
        col.operator("maxspline.edit_op", text="Select Spline").op = 'SELECT_SPLINE'


class SPLINES_PT_rendering(bpy.types.Panel):
    bl_label = "Rendering"
    bl_idname = "MAXSPLINE_PT_rendering"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "MAXSPLINE_PT_main"

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.type == 'CURVE'

    def draw(self, context):
        cu = context.active_object.data
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(cu, "bevel_depth", text="Thickness (radius)")
        layout.prop(cu, "bevel_resolution", text="Sides (extra)")
        layout.prop(cu, "extrude", text="Extrude")
        layout.prop(cu, "offset")
        layout.prop(cu, "use_fill_caps", text="Cap Ends")
        layout.separator()
        layout.prop(cu, "resolution_u", text="Interpolation Steps")
        layout.prop(cu, "render_resolution_u", text="Render Steps")
        layout.prop(cu, "dimensions", text="Mode")
        layout.prop(cu, "fill_mode", text="Fill")
        layout.prop(cu, "twist_mode", text="Twist")


def menu_add(self, context):
    layout = self.layout
    layout.separator()
    layout.label(text="Max Splines")
    layout.operator("maxspline.line", icon='IPO_LINEAR')
    layout.operator("maxspline.rectangle")
    layout.operator("maxspline.circle")
    layout.operator("maxspline.ellipse")
    layout.operator("maxspline.arc")
    layout.operator("maxspline.donut")
    layout.operator("maxspline.ngon")
    layout.operator("maxspline.star")
    layout.operator("maxspline.helix")


classes = (
    MAXSPLINE_OT_rectangle, MAXSPLINE_OT_circle, MAXSPLINE_OT_ellipse, MAXSPLINE_OT_arc,
    MAXSPLINE_OT_donut, MAXSPLINE_OT_ngon, MAXSPLINE_OT_star, MAXSPLINE_OT_helix,
    MAXSPLINE_OT_line,
    MAXSPLINE_OT_vertex_type, MAXSPLINE_OT_refine, MAXSPLINE_OT_divide, MAXSPLINE_OT_break,
    MAXSPLINE_OT_weld, MAXSPLINE_OT_fillet, MAXSPLINE_OT_chamfer, MAXSPLINE_OT_outline,
    MAXSPLINE_OT_explode, MAXSPLINE_OT_attach, MAXSPLINE_OT_convert, MAXSPLINE_OT_edit_op,
    SPLINES_PT_main, SPLINES_PT_object, SPLINES_PT_vertex, SPLINES_PT_rendering,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.VIEW3D_MT_curve_add.append(menu_add)


def unregister():
    bpy.types.VIEW3D_MT_curve_add.remove(menu_add)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
