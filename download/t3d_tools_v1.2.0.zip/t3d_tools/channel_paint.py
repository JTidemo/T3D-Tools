import bpy
import numpy as np
from bpy.props import EnumProperty, FloatProperty, IntProperty, StringProperty
from mathutils import Vector
from mathutils.bvhtree import BVHTree
from bpy.types import Operator, Panel

VIEW_NAME = "_VCI_View"   # temporary grayscale attribute you paint on
CHANNELS = {"R": 0, "G": 1, "B": 2, "A": 3}

CHANNEL_ITEMS = [
    ("R", "R", "Red channel"),
    ("G", "G", "Green channel"),
    ("B", "B", "Blue channel"),
    ("A", "A", "Alpha channel"),
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _key(attr):
    """Byte colors are read/written in sRGB so 0.5 painted == raw byte 128.
    Float colors have no sRGB accessor, so use the raw linear float."""
    return "color_srgb" if attr.data_type == 'BYTE_COLOR' else "color"


def _read(attr):
    n = len(attr.data)
    arr = np.empty(n * 4, dtype=np.float32)
    attr.data.foreach_get(_key(attr), arr)
    return arr.reshape(n, 4)


def _write(attr, arr):
    attr.data.foreach_set(_key(attr), arr.astype(np.float32).ravel())


def _attrs(mesh):
    return mesh.color_attributes


def _is_isolating(mesh):
    return VIEW_NAME in _attrs(mesh)


def _ensure_object_mode(ctx):
    """Return the previous mode and switch to Object mode so mesh data is flushed."""
    obj = ctx.active_object
    mode = obj.mode
    if mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')
    return mode


def _restore_mode(ctx, mode):
    if mode != 'OBJECT' and ctx.active_object and ctx.active_object.mode != mode:
        try:
            bpy.ops.object.mode_set(mode=mode)
        except RuntimeError:
            pass


def _set_active(mesh, name):
    attr = _attrs(mesh).get(name)
    if attr is not None:
        _attrs(mesh).active_color = attr


def _apply_view(obj):
    """Write the painted grayscale back into the stored channel and delete the temp attribute."""
    mesh = obj.data
    view = _attrs(mesh).get(VIEW_NAME)
    if view is None:
        return None
    target_name = obj.get("vci_target", "")
    channel = obj.get("vci_channel", "R")
    target = _attrs(mesh).get(target_name)
    if target is None:
        _attrs(mesh).remove(view)
        return "Target attribute '%s' no longer exists; discarded the painted channel" % target_name

    vdata = _read(view)
    gray = vdata[:, :3].mean(axis=1)
    tdata = _read(target)
    if len(tdata) != len(gray):
        return "Attribute size changed (mesh edited?); could not apply"
    tdata[:, CHANNELS[channel]] = np.clip(gray, 0.0, 1.0)
    _write(target, tdata)

    _attrs(mesh).remove(view)
    _set_active(mesh, target_name)
    mesh.update()
    return None


def _discard_view(obj):
    mesh = obj.data
    view = _attrs(mesh).get(VIEW_NAME)
    if view is not None:
        _attrs(mesh).remove(view)
    name = obj.get("vci_target", "")
    if name:
        _set_active(mesh, name)
    mesh.update()


def _make_view(obj, target_name, channel):
    mesh = obj.data
    target = _attrs(mesh).get(target_name)
    data = _read(target)
    domain = target.domain

    view = _attrs(mesh).new(VIEW_NAME, 'BYTE_COLOR', domain)
    # re-fetch: adding an attribute can invalidate older references
    target = _attrs(mesh).get(target_name)
    view = _attrs(mesh).get(VIEW_NAME)

    out = np.ones((len(data), 4), dtype=np.float32)
    out[:, :3] = np.clip(data[:, CHANNELS[channel]], 0.0, 1.0)[:, None]
    _write(view, out)
    _attrs(mesh).active_color = view
    mesh.update()


# ---------------------------------------------------------------------------
# Operators
# ---------------------------------------------------------------------------

class VCI_OT_isolate(Operator):
    bl_idname = "vci.isolate"
    bl_label = "Isolate Channel"
    bl_description = "Show this channel as grayscale and paint it (white = full, black = zero)"
    bl_options = {'REGISTER', 'UNDO'}

    channel: EnumProperty(name="Channel", items=CHANNEL_ITEMS, default="R")

    @classmethod
    def poll(cls, ctx):
        o = ctx.active_object
        return o is not None and o.type == 'MESH'

    def execute(self, ctx):
        obj = ctx.active_object
        mesh = obj.data
        prev_mode = _ensure_object_mode(ctx)

        # Switching channels while isolating: commit the previous one first
        if _is_isolating(mesh):
            if obj.get("vci_channel") == self.channel:
                bpy.ops.object.mode_set(mode='VERTEX_PAINT')
                return {'FINISHED'}
            err = _apply_view(obj)
            if err:
                self.report({'WARNING'}, err)
            target_name = obj.get("vci_target", "")
        else:
            active = _attrs(mesh).active_color
            if active is None:
                self.report({'ERROR'}, "No active color attribute. Create one first.")
                _restore_mode(ctx, prev_mode)
                return {'CANCELLED'}
            target_name = active.name

        if target_name not in _attrs(mesh):
            self.report({'ERROR'}, "Target color attribute not found")
            _restore_mode(ctx, prev_mode)
            return {'CANCELLED'}

        obj["vci_target"] = target_name
        obj["vci_channel"] = self.channel
        _make_view(obj, target_name, self.channel)

        bpy.ops.object.mode_set(mode='VERTEX_PAINT')
        # Paint white by default (best effort; brush API differs between versions)
        try:
            ctx.tool_settings.unified_paint_settings.color = (1.0, 1.0, 1.0)
        except Exception:
            try:
                ctx.tool_settings.vertex_paint.brush.color = (1.0, 1.0, 1.0)
            except Exception:
                pass
        return {'FINISHED'}


class VCI_OT_apply(Operator):
    bl_idname = "vci.apply"
    bl_label = "Apply & Exit"
    bl_description = "Write the painted grayscale into the isolated channel and go back to the full color attribute"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, ctx):
        o = ctx.active_object
        return o is not None and o.type == 'MESH' and _is_isolating(o.data)

    def execute(self, ctx):
        obj = ctx.active_object
        mode = _ensure_object_mode(ctx)
        err = _apply_view(obj)
        if err:
            self.report({'ERROR'}, err)
            _restore_mode(ctx, mode)
            return {'CANCELLED'}
        _restore_mode(ctx, mode)
        return {'FINISHED'}


class VCI_OT_discard(Operator):
    bl_idname = "vci.discard"
    bl_label = "Discard"
    bl_description = "Throw away what you painted in the isolated view and leave the original untouched"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, ctx):
        o = ctx.active_object
        return o is not None and o.type == 'MESH' and _is_isolating(o.data)

    def execute(self, ctx):
        obj = ctx.active_object
        mode = _ensure_object_mode(ctx)
        _discard_view(obj)
        _restore_mode(ctx, mode)
        return {'FINISHED'}


class VCI_OT_fill(Operator):
    bl_idname = "vci.fill"
    bl_label = "Fill Channel"
    bl_description = "Fill a whole channel of the active color attribute with a value"
    bl_options = {'REGISTER', 'UNDO'}

    channel: EnumProperty(name="Channel", items=CHANNEL_ITEMS, default="R")
    value: FloatProperty(name="Value", default=1.0, min=0.0, max=1.0)

    @classmethod
    def poll(cls, ctx):
        o = ctx.active_object
        return o is not None and o.type == 'MESH' and not _is_isolating(o.data)

    def execute(self, ctx):
        obj = ctx.active_object
        mesh = obj.data
        active = _attrs(mesh).active_color
        if active is None:
            self.report({'ERROR'}, "No active color attribute")
            return {'CANCELLED'}
        mode = _ensure_object_mode(ctx)
        name = active.name
        data = _read(_attrs(mesh)[name])
        data[:, CHANNELS[self.channel]] = self.value
        _write(_attrs(mesh)[name], data)
        mesh.update()
        _restore_mode(ctx, mode)
        return {'FINISHED'}


class VCI_OT_create(Operator):
    bl_idname = "vci.create_attribute"
    bl_label = "Create Color Attribute"
    bl_description = "Create a Face Corner / Byte Color attribute filled with white"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, ctx):
        o = ctx.active_object
        return o is not None and o.type == 'MESH'

    def execute(self, ctx):
        obj = ctx.active_object
        mesh = obj.data
        mode = _ensure_object_mode(ctx)
        attr = _attrs(mesh).new("Color", 'BYTE_COLOR', 'CORNER')
        name = attr.name
        _write(_attrs(mesh)[name], np.ones((len(_attrs(mesh)[name].data), 4), dtype=np.float32))
        _set_active(mesh, name)
        mesh.update()
        _restore_mode(ctx, mode)
        return {'FINISHED'}


SMOOTH_ITEMS = [
    ("RGBA", "All (RGBA)", "Smooth all four channels"),
    ("RGB", "RGB", "Smooth color only, leave alpha alone"),
    ("R", "R", "Red only"),
    ("G", "G", "Green only"),
    ("B", "B", "Blue only"),
    ("A", "A", "Alpha only"),
]


def _corner_verts(mesh):
    n = len(mesh.loops)
    arr = np.empty(n, dtype=np.int32)
    try:
        mesh.loops.foreach_get("vertex_index", arr)
    except Exception:
        mesh.attributes[".corner_vert"].data.foreach_get("value", arr)
    return arr


def _edge_verts(mesh):
    n = len(mesh.edges)
    arr = np.empty(n * 2, dtype=np.int32)
    try:
        mesh.edges.foreach_get("vertices", arr)
    except Exception:
        mesh.attributes[".edge_verts"].data.foreach_get("value", arr)
    return arr.reshape(n, 2)


def _smooth_mesh(mesh, attr_name, chans, iterations, factor):
    """Neighbor-average the chosen channels across mesh edges. Returns True on success."""
    attr = _attrs(mesh)[attr_name]
    data = _read(attr)
    nv = len(mesh.vertices)
    cols = [CHANNELS[c] for c in chans]
    if nv == 0 or len(data) == 0:
        return False

    # Per-vertex color (average of corners that touch the vertex)
    if attr.domain == 'CORNER':
        cv = _corner_verts(mesh)
        if len(cv) != len(data):
            return False
        cnt = np.bincount(cv, minlength=nv).astype(np.float32)
        vcol = np.zeros((nv, 4), dtype=np.float32)
        for c in cols:
            vcol[:, c] = np.bincount(cv, weights=data[:, c], minlength=nv)
        has = cnt > 0
        vcol[has] /= cnt[has, None]
    else:
        if len(data) != nv:
            return False
        cv = None
        vcol = data.copy()

    ev = _edge_verts(mesh)
    if len(ev) == 0:
        return False
    a, b = ev[:, 0], ev[:, 1]
    deg = (np.bincount(a, minlength=nv) + np.bincount(b, minlength=nv)).astype(np.float32)
    has_nb = deg > 0

    sm = vcol.copy()
    for _ in range(iterations):
        for c in cols:
            nsum = (np.bincount(a, weights=sm[b, c], minlength=nv)
                    + np.bincount(b, weights=sm[a, c], minlength=nv)).astype(np.float32)
            avg = sm[:, c].copy()
            avg[has_nb] = nsum[has_nb] / deg[has_nb]
            sm[:, c] = sm[:, c] + (avg - sm[:, c]) * factor

    out = data.copy()
    for c in cols:
        out[:, c] = sm[cv, c] if cv is not None else sm[:, c]
    _write(attr, np.clip(out, 0.0, 1.0))
    mesh.update()
    return True


class VCI_OT_smooth(Operator):
    bl_idname = "vci.smooth"
    bl_label = "Smooth Vertex Colors"
    bl_description = "Smooth the active color attribute on every selected mesh object (works on all LODs at once)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, ctx):
        return any(o.type == 'MESH' for o in ctx.selected_objects)

    def execute(self, ctx):
        sc = ctx.scene
        iterations = sc.vci_smooth_iterations
        factor = sc.vci_smooth_factor
        chans = sc.vci_smooth_channels

        prev_mode = 'OBJECT'
        if ctx.active_object and ctx.active_object.mode != 'OBJECT':
            prev_mode = _ensure_object_mode(ctx)

        # De-duplicate objects that share the same mesh data
        meshes = {}
        for o in ctx.selected_objects:
            if o.type == 'MESH':
                meshes.setdefault(o.data.name, o)

        done = skipped = 0
        for o in meshes.values():
            mesh = o.data
            active = _attrs(mesh).active_color
            if _is_isolating(mesh) or active is None:
                skipped += 1
                continue
            try:
                ok = _smooth_mesh(mesh, active.name, chans, iterations, factor)
            except Exception as e:
                self.report({'WARNING'}, "%s: %s" % (o.name, e))
                ok = False
            if ok:
                done += 1
            else:
                skipped += 1

        _restore_mode(ctx, prev_mode)
        msg = "Smoothed %d mesh%s" % (done, "" if done == 1 else "es")
        if skipped:
            msg += " (%d skipped: no color attribute, isolating, or no edges)" % skipped
        self.report({'INFO'} if done else {'WARNING'}, msg)
        return {'FINISHED'} if done else {'CANCELLED'}


# ---------------------------------------------------------------------------
# Data transfer from a predefined source object
# ---------------------------------------------------------------------------

DEFAULT_TRANSFER_SOURCE = "Vertex Plane"   # object the colors are copied from
TRANSFER_CHANNELS = "GB"                   # channels that get copied (R and A are left alone)


def _build_source(src_obj):
    """Triangulate the source the same way Blender displays it, so the interpolated
    values match what you see in the viewport (quads are NOT bilinear in Blender)."""
    mesh = src_obj.data
    attr = _attrs(mesh).active_color
    if attr is None or len(mesh.polygons) == 0:
        return None
    try:
        mesh.calc_loop_triangles()
    except AttributeError:
        pass
    nt = len(mesh.loop_triangles)
    if nt == 0:
        return None

    nv = len(mesh.vertices)
    co = np.empty(nv * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", co)
    verts = co.reshape(nv, 3).astype(np.float64)

    tv = np.empty(nt * 3, dtype=np.int32)
    mesh.loop_triangles.foreach_get("vertices", tv)
    tv = tv.reshape(nt, 3)
    tl = np.empty(nt * 3, dtype=np.int32)
    mesh.loop_triangles.foreach_get("loops", tl)
    tl = tl.reshape(nt, 3)

    return {
        "data": _read(attr).astype(np.float64),
        "domain": attr.domain,
        "verts": verts,
        "tv": tv,
        "tl": tl,
        "bvh": BVHTree.FromPolygons(verts.tolist(), tv.tolist()),
    }


def _sample_source(src, point):
    """Nearest face (triangle) to `point`, then barycentric interpolation of its corner colors."""
    hit = src["bvh"].find_nearest(Vector(point))
    if hit[0] is None:
        return None
    loc, _normal, idx, _dist = hit
    ids = src["tl"][idx] if src["domain"] == 'CORNER' else src["tv"][idx]
    cols = src["data"][ids]

    a, b, c = src["verts"][src["tv"][idx]]
    p = np.array(loc, dtype=np.float64)
    v0, v1, v2 = b - a, c - a, p - a
    d00, d01, d11 = v0 @ v0, v0 @ v1, v1 @ v1
    d20, d21 = v2 @ v0, v2 @ v1
    den = d00 * d11 - d01 * d01
    if abs(den) < 1e-20:
        w = np.array([1 / 3, 1 / 3, 1 / 3])
    else:
        v = (d11 * d20 - d01 * d21) / den
        wt = (d00 * d21 - d01 * d20) / den
        w = np.clip(np.array([1.0 - v - wt, v, wt]), 0.0, None)
        w /= w.sum()
    return (cols * w[:, None]).sum(axis=0)


def _transfer_to_mesh(tgt_obj, src_obj, src, chans):
    mesh = tgt_obj.data
    attr = _attrs(mesh).active_color
    if attr is None:
        return False
    name = attr.name
    nv = len(mesh.vertices)
    if nv == 0:
        return False

    co = np.empty(nv * 3, dtype=np.float32)
    mesh.vertices.foreach_get("co", co)
    co = co.reshape(nv, 3)

    # target local -> source local
    m = np.array(src_obj.matrix_world.inverted() @ tgt_obj.matrix_world, dtype=np.float64)
    pts = co.astype(np.float64) @ m[:3, :3].T + m[:3, 3]

    cols = [CHANNELS[c] for c in chans]
    vcol = np.zeros((nv, 4), dtype=np.float32)
    for i in range(nv):
        s = _sample_source(src, pts[i])
        if s is not None:
            vcol[i] = s

    data = _read(attr)
    if attr.domain == 'CORNER':
        cv = _corner_verts(mesh)
        if len(cv) != len(data):
            return False
        for c in cols:
            data[:, c] = vcol[cv, c]
    else:
        if len(data) != nv:
            return False
        for c in cols:
            data[:, c] = vcol[:, c]

    _write(_attrs(mesh)[name], np.clip(data, 0.0, 1.0))
    mesh.update()
    return True



# ---------------------------------------------------------------------------
# Live (non-destructive) G + B transfer: a Geometry Nodes modifier on the target
# ---------------------------------------------------------------------------

LIVE_GROUP = ".VCI_LiveTransfer"
LIVE_VERSION = 1
LIVE_MOD = "VCI Live G+B"


def _build_live_group():
    old = bpy.data.node_groups.get(LIVE_GROUP)
    if old is not None:
        bpy.data.node_groups.remove(old)
    ng = bpy.data.node_groups.new(LIVE_GROUP, 'GeometryNodeTree')
    ng["vci_live_version"] = LIVE_VERSION
    iface = ng.interface
    iface.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    iface.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    iface.new_socket("Source", in_out='INPUT', socket_type='NodeSocketObject')
    iface.new_socket("Source Attribute", in_out='INPUT', socket_type='NodeSocketString')
    iface.new_socket("Target Attribute", in_out='INPUT', socket_type='NodeSocketString')

    n = ng.nodes
    link = ng.links.new
    gin = n.new('NodeGroupInput')
    gin.location = (-900, 0)
    gout = n.new('NodeGroupOutput')
    gout.location = (900, 0)

    objinfo = n.new('GeometryNodeObjectInfo')
    objinfo.transform_space = 'RELATIVE'          # source geometry in the target's own space
    objinfo.location = (-650, 250)

    src_attr = n.new('GeometryNodeInputNamedAttribute')
    src_attr.data_type = 'FLOAT_COLOR'
    src_attr.location = (-650, 50)

    pos = n.new('GeometryNodeInputPosition')
    pos.location = (-650, -100)

    sample = n.new('GeometryNodeSampleNearestSurface')
    sample.data_type = 'FLOAT_COLOR'
    sample.location = (-350, 150)

    dst_attr = n.new('GeometryNodeInputNamedAttribute')
    dst_attr.data_type = 'FLOAT_COLOR'
    dst_attr.location = (-650, -300)

    sep_dst = n.new('FunctionNodeSeparateColor')
    sep_dst.location = (-100, -250)
    sep_src = n.new('FunctionNodeSeparateColor')
    sep_src.location = (-100, 100)
    comb = n.new('FunctionNodeCombineColor')
    comb.location = (150, -50)

    store = n.new('GeometryNodeStoreNamedAttribute')
    store.data_type = 'FLOAT_COLOR'
    store.domain = 'CORNER'
    store.location = (550, 0)

    link(gin.outputs["Source"], objinfo.inputs["Object"])
    link(gin.outputs["Source Attribute"], src_attr.inputs["Name"])
    link(gin.outputs["Target Attribute"], dst_attr.inputs["Name"])
    link(objinfo.outputs["Geometry"], sample.inputs["Mesh"])
    link(src_attr.outputs["Attribute"], _pick(sample.inputs, "Value"))
    link(pos.outputs["Position"], sample.inputs["Sample Position"])
    link(_pick(sample.outputs, "Value"), sep_src.inputs["Color"])
    link(dst_attr.outputs["Attribute"], sep_dst.inputs["Color"])
    link(sep_dst.outputs["Red"], comb.inputs["Red"])
    link(sep_src.outputs["Green"], comb.inputs["Green"])
    link(sep_src.outputs["Blue"], comb.inputs["Blue"])
    link(sep_dst.outputs["Alpha"], comb.inputs["Alpha"])
    link(gin.outputs["Geometry"], store.inputs["Geometry"])
    link(gin.outputs["Target Attribute"], store.inputs["Name"])
    link(comb.outputs["Color"], _pick(store.inputs, "Value"))
    link(store.outputs["Geometry"], gout.inputs["Geometry"])
    return ng


def _live_group():
    ng = bpy.data.node_groups.get(LIVE_GROUP)
    if ng is None or ng.get("vci_live_version") != LIVE_VERSION:
        ng = _build_live_group()
    return ng


def _pick(sockets, name):
    for s_ in sockets:
        if s_.name == name and s_.enabled:
            return s_
    raise KeyError(name)


def _live_ids(ng):
    return {it.name: it.identifier for it in ng.interface.items_tree
            if it.item_type == 'SOCKET' and it.in_out == 'INPUT'}


def _mod_set(mod, key, value):
    props = getattr(mod, "properties", None)        # Blender 5.2+
    if props is not None:
        props.inputs[key]["value"] = value
    else:
        mod[key] = value


def _live_apply(ob, src_obj, src_attr, dst_attr):
    mod = ob.modifiers.get(LIVE_MOD)
    if mod is None:
        mod = ob.modifiers.new(LIVE_MOD, 'NODES')
        mod.show_expanded = False
    ng = _live_group()
    if mod.node_group != ng:
        mod.node_group = ng
    if hasattr(mod, "use_pin_to_last"):
        mod.use_pin_to_last = True              # runs after Mirror etc.
    ids = _live_ids(ng)
    _mod_set(mod, ids["Source"], src_obj)
    _mod_set(mod, ids["Source Attribute"], src_attr)
    _mod_set(mod, ids["Target Attribute"], dst_attr)
    ob["vci_live_source"] = src_obj.name
    ob.update_tag()


class VCI_OT_transfer(Operator):
    bl_idname = "vci.transfer_gb"
    bl_label = "Transfer G + B"
    bl_description = "Copy the G and B channels from the source object (default: 'Vertex Plane') onto every selected mesh, matching by nearest face, interpolated"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, ctx):
        return any(o.type == 'MESH' for o in ctx.selected_objects)

    def _live(self, ctx, src_obj, prev_mode):
        src_attr = _attrs(src_obj.data).active_color
        done = skipped = 0
        for o in {o.data.name: o for o in ctx.selected_objects
                  if o.type == 'MESH' and o.data.name != src_obj.data.name}.values():
            dst = _attrs(o.data).active_color
            if dst is None:
                dst = _attrs(o.data).new("Color", 'BYTE_COLOR', 'CORNER')
                _write(_attrs(o.data)[dst.name], np.ones((len(_attrs(o.data)[dst.name].data), 4), dtype=np.float32))
                dst = _attrs(o.data)[dst.name]
            if dst.domain != 'CORNER' or _is_isolating(o.data):
                skipped += 1
                continue
            _live_apply(o, src_obj, src_attr.name, dst.name)
            done += 1
        _restore_mode(ctx, prev_mode)
        msg = "Live G+B transfer from '%s' set on %d mesh%s" % (src_obj.name, done, "" if done == 1 else "es")
        if skipped:
            msg += " (%d skipped: needs a Face Corner color attribute)" % skipped
        self.report({'INFO'} if done else {'WARNING'}, msg)
        return {'FINISHED'} if done else {'CANCELLED'}

    def execute(self, ctx):
        src_name = ctx.scene.vci_transfer_source or DEFAULT_TRANSFER_SOURCE
        src_obj = bpy.data.objects.get(src_name)
        if src_obj is None or src_obj.type != 'MESH':
            self.report({'ERROR'}, "Source mesh object '%s' not found" % src_name)
            return {'CANCELLED'}

        prev_mode = 'OBJECT'
        if ctx.active_object and ctx.active_object.mode != 'OBJECT':
            prev_mode = _ensure_object_mode(ctx)

        if _is_isolating(src_obj.data):
            self.report({'ERROR'}, "'%s' is isolating a channel. Apply or discard it first." % src_name)
            _restore_mode(ctx, prev_mode)
            return {'CANCELLED'}

        src = _build_source(src_obj)
        if src is None:
            self.report({'ERROR'}, "'%s' has no color attribute or no faces" % src_name)
            _restore_mode(ctx, prev_mode)
            return {'CANCELLED'}

        if ctx.scene.vci_transfer_live:
            return self._live(ctx, src_obj, prev_mode)

        targets = {}
        for o in ctx.selected_objects:
            if o.type == 'MESH' and o.data.name != src_obj.data.name:
                targets.setdefault(o.data.name, o)

        done = skipped = 0
        for o in targets.values():
            if _is_isolating(o.data):
                skipped += 1
                continue
            try:
                ok = _transfer_to_mesh(o, src_obj, src, TRANSFER_CHANNELS)
            except Exception as e:
                self.report({'WARNING'}, "%s: %s" % (o.name, e))
                ok = False
            if ok:
                done += 1
            else:
                skipped += 1

        _restore_mode(ctx, prev_mode)
        msg = "Transferred %s from '%s' to %d mesh%s" % (
            "+".join(TRANSFER_CHANNELS), src_name, done, "" if done == 1 else "es")
        if skipped:
            msg += " (%d skipped: no color attribute or isolating)" % skipped
        self.report({'INFO'} if done else {'WARNING'}, msg)
        return {'FINISHED'} if done else {'CANCELLED'}


class VCI_OT_live_remove(Operator):
    bl_idname = "vci.transfer_live_remove"
    bl_label = "Remove Live Transfer"
    bl_description = "Remove the live G + B modifier from the selected meshes (the mesh data is left as it was)"
    bl_options = {'REGISTER', 'UNDO'}

    bake: bpy.props.BoolProperty(default=False, options={'SKIP_SAVE', 'HIDDEN'})

    @classmethod
    def poll(cls, ctx):
        return any(o.type == 'MESH' and LIVE_MOD in o.modifiers for o in ctx.selected_objects)

    def execute(self, ctx):
        prev_mode = 'OBJECT'
        if ctx.active_object and ctx.active_object.mode != 'OBJECT':
            prev_mode = _ensure_object_mode(ctx)
        n = 0
        for o in ctx.selected_objects:
            if o.type != 'MESH' or LIVE_MOD not in o.modifiers:
                continue
            src_obj = bpy.data.objects.get(o.get("vci_live_source", ""))
            o.modifiers.remove(o.modifiers[LIVE_MOD])
            if self.bake and src_obj is not None:
                src = _build_source(src_obj)
                if src is not None:
                    _transfer_to_mesh(o, src_obj, src, TRANSFER_CHANNELS)
            n += 1
        _restore_mode(ctx, prev_mode)
        self.report({'INFO'}, "%s on %d mesh%s" % ("Baked into the mesh" if self.bake else "Removed live transfer",
                                                   n, "" if n == 1 else "es"))
        return {'FINISHED'}


# ---------------------------------------------------------------------------
# AO bake into a color attribute (GTA keeps AO in the R channel)
# ---------------------------------------------------------------------------

class VCI_OT_bake_ao(Operator):
    bl_idname = "vci.bake_ao"
    bl_label = "Bake AO"
    bl_description = ("Bake ambient occlusion of the selected meshes into a new Face Corner / Byte Color attribute "
                      "(made active, so you can tweak it in Vertex Paint). Objects hidden in the viewport "
                      "do not take part in the bake")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, ctx):
        return any(o.type == 'MESH' for o in ctx.selected_objects)

    def execute(self, ctx):
        sc = ctx.scene
        name = sc.vci_ao_name or "AO"
        targets = {}
        for o in ctx.selected_objects:
            if o.type == 'MESH':
                targets.setdefault(o.data.name, o)
        objs = list(targets.values())
        if not objs:
            return {'CANCELLED'}

        prev_mode = 'OBJECT'
        if ctx.active_object and ctx.active_object.mode != 'OBJECT':
            prev_mode = _ensure_object_mode(ctx)
        if ctx.active_object is None or ctx.active_object not in objs:
            ctx.view_layer.objects.active = objs[0]

        # a fresh white attribute on every mesh; the bake writes into the active one
        prev_active = {}
        for o in objs:
            mesh = o.data
            act = _attrs(mesh).active_color
            prev_active[o.name] = act.name if act is not None else ""
            old = _attrs(mesh).get(name)
            if old is not None:
                _attrs(mesh).remove(old)
            a = _attrs(mesh).new(name, 'BYTE_COLOR', 'CORNER')
            _write(_attrs(mesh)[a.name], np.ones((len(_attrs(mesh)[a.name].data), 4), dtype=np.float32))
            _attrs(mesh).active_color = _attrs(mesh)[a.name]

        render = sc.render
        saved = {
            "engine": render.engine,
            "samples": sc.cycles.samples if hasattr(sc, "cycles") else None,
            "target": render.bake.target,
        }
        world = sc.world
        saved_dist = world.light_settings.distance if world is not None else None
        hidden = []
        err = None
        try:
            render.engine = 'CYCLES'
            sc.cycles.samples = sc.vci_ao_samples
            render.bake.target = 'VERTEX_COLORS'
            if world is not None and sc.vci_ao_distance > 0.0:
                world.light_settings.distance = sc.vci_ao_distance
            if sc.vci_ao_visible_only:
                # the bake sees everything that is renderable; hide what you can't see
                for ob in sc.objects:
                    if ob in objs or ob.hide_render:
                        continue
                    if ob.type in {'MESH', 'CURVE', 'SURFACE', 'META', 'FONT', 'CURVES', 'POINTCLOUD', 'VOLUME'} \
                            and not ob.visible_get():
                        ob.hide_render = True
                        hidden.append(ob)
            bpy.ops.object.bake(type='AO')
        except Exception as e:                      # keep the restore below running
            err = e
        finally:
            for ob in hidden:
                ob.hide_render = False
            render.engine = saved["engine"]
            if saved["samples"] is not None:
                sc.cycles.samples = saved["samples"]
            render.bake.target = saved["target"]
            if world is not None and saved_dist is not None:
                world.light_settings.distance = saved_dist
        for o in objs:
            _attrs(o.data).active_color = _attrs(o.data)[name]
            o.data.update()
        sc.vci_copy_src = name
        sc.vci_copy_src_ch = "R"
        _restore_mode(ctx, prev_mode)
        if err is not None:
            self.report({'ERROR'}, "Bake failed: %s" % err)
            return {'CANCELLED'}
        self.report({'INFO'}, "Baked AO into '%s' on %d mesh%s%s" % (
            name, len(objs), "" if len(objs) == 1 else "es",
            " (%d hidden object%s left out)" % (len(hidden), "" if len(hidden) == 1 else "s") if hidden else ""))
        return {'FINISHED'}


BLEND_ITEMS = [
    ("REPLACE", "Replace", "Write the source value"),
    ("ADD", "Add", "Destination + source"),
    ("SUBTRACT", "Subtract", "Destination - source"),
    ("MULTIPLY", "Multiply", "Destination x source"),
    ("DIVIDE", "Divide", "Destination / source"),
    ("LIGHTEN", "Lighten", "The larger of the two"),
    ("DARKEN", "Darken", "The smaller of the two"),
    ("MIX", "Mix", "Average of the two"),
]


def _blend(dst, src, mode):
    if mode == "ADD":
        return dst + src
    if mode == "SUBTRACT":
        return dst - src
    if mode == "MULTIPLY":
        return dst * src
    if mode == "DIVIDE":
        return np.where(src > 1e-6, dst / np.maximum(src, 1e-6), dst)
    if mode == "LIGHTEN":
        return np.maximum(dst, src)
    if mode == "DARKEN":
        return np.minimum(dst, src)
    if mode == "MIX":
        return (dst + src) * 0.5
    return src


class VCI_OT_copy_channel(Operator):
    bl_idname = "vci.copy_channel"
    bl_label = "Copy Channel"
    bl_description = ("Copy one channel of a color attribute into a channel of another (for example the baked AO "
                      "into R of the main attribute), on every selected mesh")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, ctx):
        return any(o.type == 'MESH' for o in ctx.selected_objects)

    def execute(self, ctx):
        sc = ctx.scene
        sname, dname = sc.vci_copy_src, sc.vci_copy_dst
        if not sname or not dname:
            self.report({'ERROR'}, "Pick the source and destination attributes")
            return {'CANCELLED'}
        prev_mode = 'OBJECT'
        if ctx.active_object and ctx.active_object.mode != 'OBJECT':
            prev_mode = _ensure_object_mode(ctx)
        sc_i, dc_i = CHANNELS[sc.vci_copy_src_ch], CHANNELS[sc.vci_copy_dst_ch]
        done = removed = 0
        seen = set()
        for o in ctx.selected_objects:
            if o.type != 'MESH' or o.data.name in seen:
                continue
            seen.add(o.data.name)
            a, b = _attrs(o.data).get(sname), _attrs(o.data).get(dname)
            if a is None or b is None or len(a.data) != len(b.data):
                continue
            src, dst = _read(a), _read(b)
            blended = _blend(dst[:, dc_i], src[:, sc_i], sc.vci_copy_mode)
            dst[:, dc_i] = np.clip(dst[:, dc_i] + (blended - dst[:, dc_i]) * sc.vci_copy_factor, 0.0, 1.0)
            _write(_attrs(o.data)[dname], dst)
            if sc.vci_copy_delete and sname != dname:
                _attrs(o.data).remove(_attrs(o.data)[sname])
                removed += 1
            o.data.update()
            done += 1
        _restore_mode(ctx, prev_mode)
        if not done:
            self.report({'ERROR'}, "No selected mesh has both '%s' and '%s' (same domain)" % (sname, dname))
            return {'CANCELLED'}
        self.report({'INFO'}, "Copied %s.%s -> %s.%s on %d mesh%s%s" % (
            sname, sc.vci_copy_src_ch, dname, sc.vci_copy_dst_ch, done, "" if done == 1 else "es",
            " (deleted '%s')" % sname if removed else ""))
        return {'FINISHED'}



# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

class VCI_PT_panel(Panel):
    bl_label = "Channel Paint"
    bl_idname = "VCI_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_vehicle"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, ctx):
        o = ctx.active_object
        return o is not None and o.type == 'MESH'

    def draw(self, ctx):
        layout = self.layout
        obj = ctx.active_object
        mesh = obj.data
        isolating = _is_isolating(mesh)
        current = obj.get("vci_channel", "") if isolating else ""

        if isolating:
            layout.label(text="Target: %s" % obj.get("vci_target", "?"), icon='GROUP_VCOL')
        else:
            active = _attrs(mesh).active_color
            if active is None:
                layout.label(text="No color attribute", icon='ERROR')
                layout.operator("vci.create_attribute", icon='ADD')
                return
            layout.label(text="Target: %s" % active.name, icon='GROUP_VCOL')
            layout.label(text="%s / %s" % (active.domain.title(), active.data_type.replace("_", " ").title()))

        layout.label(text="Isolate & paint channel:")
        row = layout.row(align=True)
        row.scale_y = 1.4
        for ch in "RGBA":
            op = row.operator("vci.isolate", text=ch, depress=(current == ch))
            op.channel = ch

        if isolating:
            layout.label(text="Paint white = full, black = zero", icon='INFO')
            row = layout.row(align=True)
            row.scale_y = 1.3
            row.operator("vci.apply", icon='CHECKMARK')
            row.operator("vci.discard", icon='X')
        else:
            box = layout.box()
            box.label(text="Fill channel:")
            for label, val in (("0", 0.0), ("1", 1.0)):
                row = box.row(align=True)
                for ch in "RGBA":
                    op = row.operator("vci.fill", text="%s=%s" % (ch, label))
                    op.channel = ch
                    op.value = val


class VCI_PT_smooth(Panel):
    bl_label = "Smooth Colors"
    bl_idname = "VCI_PT_smooth"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "VCI_PT_panel"

    def draw(self, ctx):
        layout = self.layout
        sc = ctx.scene
        n = len({o.data.name for o in ctx.selected_objects if o.type == 'MESH'})
        layout.label(text="%d mesh%s selected" % (n, "" if n == 1 else "es"), icon='RESTRICT_SELECT_OFF')
        layout.prop(sc, "vci_smooth_channels", text="Channels")
        layout.prop(sc, "vci_smooth_iterations", text="Iterations")
        layout.prop(sc, "vci_smooth_factor", text="Factor")
        layout.operator("vci.smooth", icon='MOD_SMOOTH')


class VCI_PT_transfer(Panel):
    bl_label = "Transfer G + B"
    bl_idname = "VCI_PT_transfer"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "VCI_PT_panel"

    def draw(self, ctx):
        layout = self.layout
        sc = ctx.scene
        layout.prop_search(sc, "vci_transfer_source", bpy.data, "objects", text="Source")
        exists = bpy.data.objects.get(sc.vci_transfer_source) is not None
        if not exists:
            layout.label(text="Source object not found", icon='ERROR')
        layout.label(text="Copies G and B onto selected meshes")
        layout.prop(sc, "vci_transfer_live")
        layout.operator("vci.transfer_gb", icon='MOD_DATA_TRANSFER',
                        text="Update Live" if sc.vci_transfer_live else "Transfer G + B")
        if any(o.type == 'MESH' and LIVE_MOD in o.modifiers for o in ctx.selected_objects):
            row = layout.row(align=True)
            op = row.operator("vci.transfer_live_remove", text="Bake Into Mesh", icon='CHECKMARK')
            op.bake = True
            op = row.operator("vci.transfer_live_remove", text="Remove", icon='X')
            op.bake = False


class VCI_PT_ao(Panel):
    bl_label = "AO Bake"
    bl_idname = "VCI_PT_ao"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "VCI_PT_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, ctx):
        layout = self.layout
        sc = ctx.scene
        n = len({o.data.name for o in ctx.selected_objects if o.type == 'MESH'})
        layout.label(text="%d mesh%s selected" % (n, "" if n == 1 else "es"), icon='RESTRICT_SELECT_OFF')
        layout.prop(sc, "vci_ao_name", text="Attribute")
        layout.prop(sc, "vci_ao_samples")
        layout.prop(sc, "vci_ao_distance")
        layout.prop(sc, "vci_ao_visible_only")
        layout.operator("vci.bake_ao", icon='SHADING_RENDERED')
        layout.label(text="Then tweak it in Vertex Paint and use")
        layout.label(text="Copy Channel to put it in R of your main one.")


class VCI_PT_copy(Panel):
    bl_label = "Copy Channel"
    bl_idname = "VCI_PT_copy"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "VCI_PT_panel"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, ctx):
        layout = self.layout
        sc = ctx.scene
        ob = ctx.active_object
        mesh = ob.data if ob is not None and ob.type == 'MESH' else None
        for label, ap, cp in (("Src", "vci_copy_src", "vci_copy_src_ch"), ("Dst", "vci_copy_dst", "vci_copy_dst_ch")):
            row = layout.row(align=True)
            row.label(text=label + ":")
            if mesh is not None:
                row.prop_search(sc, ap, mesh, "color_attributes", text="")
            else:
                row.prop(sc, ap, text="")
            row.prop(sc, cp, text="")
        row = layout.row(align=True)
        row.prop(sc, "vci_copy_mode", text="")
        row.prop(sc, "vci_copy_factor", text="Factor")
        layout.prop(sc, "vci_copy_delete")
        layout.operator("vci.copy_channel", icon='COPYDOWN')


classes = (
    VCI_OT_isolate,
    VCI_OT_apply,
    VCI_OT_discard,
    VCI_OT_fill,
    VCI_OT_create,
    VCI_OT_smooth,
    VCI_OT_transfer,
    VCI_OT_live_remove,
    VCI_OT_bake_ao,
    VCI_OT_copy_channel,
    VCI_PT_panel,
    VCI_PT_smooth,
    VCI_PT_transfer,
    VCI_PT_ao,
    VCI_PT_copy,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.vci_transfer_source = StringProperty(
        name="Source", default=DEFAULT_TRANSFER_SOURCE,
        description="Object the G and B channels are copied from")
    bpy.types.Scene.vci_transfer_live = bpy.props.BoolProperty(
        name="Update Live", default=False,
        description="Instead of writing the colors into the mesh, add a modifier that keeps G and B "
                    "following the source object (non-destructive). Bake Into Mesh makes it permanent")
    bpy.types.Scene.vci_ao_name = StringProperty(name="Attribute", default="AO",
                                                 description="Name of the Face Corner / Byte Color attribute the AO is baked into")
    bpy.types.Scene.vci_ao_samples = IntProperty(name="Samples", default=64, min=1, max=4096,
                                                 description="Cycles samples for the bake")
    bpy.types.Scene.vci_ao_distance = FloatProperty(name="Distance", default=1.0, min=0.0, unit='LENGTH',
                                                    description="How far occluders are looked for (the world's AO "
                                                                "distance while baking). 0 keeps the world's value")
    bpy.types.Scene.vci_ao_visible_only = bpy.props.BoolProperty(
        name="Only Visible Objects", default=True,
        description="Objects hidden in the viewport are left out of the bake (Blender normally still "
                    "bakes against everything that is renderable)")
    bpy.types.Scene.vci_copy_src = StringProperty(name="Source", description="Source color attribute")
    bpy.types.Scene.vci_copy_dst = StringProperty(name="Destination", description="Destination color attribute")
    bpy.types.Scene.vci_copy_src_ch = EnumProperty(name="Source Channel", items=CHANNEL_ITEMS, default="R")
    bpy.types.Scene.vci_copy_dst_ch = EnumProperty(name="Destination Channel", items=CHANNEL_ITEMS, default="R")
    bpy.types.Scene.vci_copy_mode = EnumProperty(name="Blend", items=BLEND_ITEMS, default="REPLACE")
    bpy.types.Scene.vci_copy_delete = bpy.props.BoolProperty(
        name="Delete Source After Copy", default=True,
        description="Remove the source attribute from the mesh once it has been copied (for the baked AO)")
    bpy.types.Scene.vci_copy_factor = FloatProperty(name="Factor", default=1.0, min=0.0, max=1.0,
                                                    description="How much of the blended result is applied")
    bpy.types.Scene.vci_smooth_channels = EnumProperty(
        name="Channels", items=SMOOTH_ITEMS, default="RGBA")
    bpy.types.Scene.vci_smooth_iterations = IntProperty(
        name="Iterations", default=5, min=1, max=200,
        description="How many smoothing passes to run")
    bpy.types.Scene.vci_smooth_factor = FloatProperty(
        name="Factor", default=0.5, min=0.0, max=1.0,
        description="How far each vertex moves toward its neighbors' average per pass")


def unregister():
    for n_ in ("vci_transfer_live", "vci_ao_name", "vci_ao_samples", "vci_ao_distance", "vci_ao_visible_only",
               "vci_copy_src", "vci_copy_dst", "vci_copy_src_ch", "vci_copy_dst_ch", "vci_copy_mode",
               "vci_copy_factor", "vci_copy_delete"):
        delattr(bpy.types.Scene, n_)
    del bpy.types.Scene.vci_transfer_source
    del bpy.types.Scene.vci_smooth_factor
    del bpy.types.Scene.vci_smooth_iterations
    del bpy.types.Scene.vci_smooth_channels
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
