"""Even Bevel: bevel the selected edges, but place the new vertices along the loop's
own direction instead of along each edge's miter. Editable list of bevels, each with
its own edges and settings (like the UV / Normal transfers).

How it stays editable: the original mesh is kept (hidden, on the object) together with
the edges of every bevel. Changing any setting rebuilds the mesh from that copy by
applying the bevels in list order. Manual edits made to the mesh after the first bevel
are lost on the next rebuild; remove all bevels to get the original back.

Blender's bevel measures the width perpendicular to every edge and lets the corner
vertices slide out to w / cos(angle / 2). On a coarse oval the bevel therefore
stays a polygon that follows the old edges. Here each new outer vertex is put
exactly `width` away from its source vertex, pointing sideways out of the loop
(perpendicular to the loop tangent, inside the plane of the neighbouring face), so
the offset loop is a sampled offset of the oval, not a copy of its polygon.

Modes:
  EVEN   - offset by exactly `width` along the vertex-based direction
  MITER  - the plain Blender result (to compare)
Smooth Direction averages the loop before the tangents are measured, so a lumpy
rim gives a calmer offset.
"""

import bmesh
import bpy
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty,
                       IntProperty, PointerProperty, StringProperty)
from mathutils import kdtree
from mathutils.geometry import intersect_point_line


def even_bevel(bm, width, segments, profile, loop_slide, mode, smooth):
    """Bevel the selected edges of bm. Returns the number of vertices that were re-placed."""
    sel_edges = [e for e in bm.edges if e.select]
    if not sel_edges:
        return -1

    bm.normal_update()

    # ---- snapshot the parent loop (the bevel destroys these vertices) ----
    parents = {v for e in sel_edges for v in e.verts}
    adj = {v: [e.other_vert(v) for e in v.link_edges if e.select] for v in parents}
    smoothed = {v: v.co.copy() for v in parents}
    for _ in range(smooth):
        nxt = {}
        for v in parents:
            nb = adj[v]
            if len(nb) == 2:
                nxt[v] = smoothed[v] * 0.5 + (smoothed[nb[0]] + smoothed[nb[1]]) * 0.25
            else:
                nxt[v] = smoothed[v]
        smoothed = nxt

    snap = []        # (position, tangent, normal) per usable parent
    for v in parents:
        nb = adj[v]
        if len(nb) == 2:
            t = smoothed[nb[1]] - smoothed[nb[0]]
        elif len(nb) == 1:
            t = smoothed[nb[0]] - smoothed[v]
        else:
            continue            # junction: leave Blender's result
        if t.length < 1e-9:
            continue
        snap.append((v.co.copy(), t.normalized(), v.normal.copy()))

    res = bmesh.ops.bevel(
        bm, geom=sel_edges, offset=width, offset_type='OFFSET', profile=profile,
        segments=segments, affect='EDGES', clamp_overlap=False, loop_slide=loop_slide,
        material=-1, harden_normals=False, mark_seam=False, mark_sharp=False,
        miter_outer='SHARP', miter_inner='SHARP', face_strength_mode='NONE',
        vmesh_method='ADJ')

    if mode == 'MITER' or not snap:
        return 0

    bm.normal_update()
    new_faces = set(res["faces"])
    strip = set()
    for f in new_faces:
        strip.update(f.verts)

    kd = kdtree.KDTree(len(snap))
    for i, (p, _t, _n) in enumerate(snap):
        kd.insert(p, i)
    kd.balance()

    outer = {}                      # (parent, side) -> (vertex, original co, new co)
    inner_of = {}                   # parent -> [vertices that are not on the outer loops]
    for u in strip:
        p_i = kd.find(u.co)[1]
        p, t, n = snap[p_i]
        ring = [f for f in u.link_faces if f not in new_faces]
        if not ring:
            inner_of.setdefault(p_i, []).append(u)
            continue
        f = ring[0]
        d = f.normal.cross(t)
        if d.length < 1e-9:
            continue
        d.normalize()
        ref = n.cross(t)
        side = 1 if (u.co - p).dot(ref) >= 0.0 else -1
        # point away from the loop, into the face
        if (u.co - p).dot(d) < 0.0:
            d = -d
        outer[(p_i, side)] = (u, u.co.copy(), p + d * width)

    moved = 0
    new_co = {}
    for (p_i, side), (u, old, new) in outer.items():
        new_co[u] = new
        moved += 1
    for p_i, verts in inner_of.items():
        a = outer.get((p_i, 1))
        b = outer.get((p_i, -1))
        if a is None or b is None:
            continue
        span = b[1] - a[1]
        L2 = span.length_squared
        da, db = a[2] - a[1], b[2] - b[1]
        for m in verts:
            lam = 0.5 if L2 < 1e-12 else max(0.0, min(1.0, (m.co - a[1]).dot(span) / L2))
            new_co[m] = m.co + da * (1.0 - lam) + db * lam
            moved += 1
    for v, co in new_co.items():
        v.co = co
    bm.normal_update()
    return moved


def unbevel(bm, mark_sharp=True):
    """Collapse the selected bevel strip (selected faces) back into a single edge.

    Returns (merged cross sections, skipped faces) or None when nothing is selected.
    The two side faces' planes are intersected so the new edge sits on the original
    corner, not on the middle of the strip."""
    region = {f for f in bm.faces if f.select}
    if not region:
        return None
    cross = set()
    skipped = 0
    for f in region:
        if len(f.verts) != 4:
            skipped += 1
            continue
        es = list(f.edges)
        len_a = es[0].calc_length() + es[2].calc_length()
        len_b = es[1].calc_length() + es[3].calc_length()
        # the strip is long and narrow: the shorter pair spans it
        cross.update((es[0], es[2]) if len_a < len_b else (es[1], es[3]))
    if not cross:
        return 0, skipped

    parent = {}

    def find(v):
        while parent.setdefault(v, v) is not v:
            parent[v] = parent[parent[v]]
            v = parent[v]
        return v

    for e in cross:
        a, b = find(e.verts[0]), find(e.verts[1])
        if a is not b:
            parent[a] = b
    groups = {}
    for v in list(parent):
        groups.setdefault(find(v), []).append(v)

    targets = {}
    for root, verts in groups.items():
        outer = [v for v in verts if any(f not in region for f in v.link_faces)]
        mid = sum((v.co for v in verts), verts[0].co * 0) / len(verts)
        pos = mid
        if len(outer) == 2:
            a, b = outer
            na = sum((f.normal for f in a.link_faces if f not in region), a.co * 0)
            nb = sum((f.normal for f in b.link_faces if f not in region), a.co * 0)
            if na.length > 1e-9 and nb.length > 1e-9:
                na.normalize()
                nb.normalize()
                m2 = (a.co + b.co) * 0.5
                c = na.dot(nb)
                det = 1.0 - c * c
                if det > 1e-6:
                    u = (m2 - a.co).dot(na)
                    w = (m2 - b.co).dot(nb)
                    al = (-u + c * w) / det
                    be = (-w + c * u) / det
                    pos = m2 + na * al + nb * be
        targets[root] = pos

    target_map = {}
    survivor = {}
    for root, verts in groups.items():
        keep = verts[0]
        keep.co = targets[root]
        for v in verts:
            survivor[v] = keep
        for v in verts[1:]:
            target_map[v] = keep
    # the edges that will remain where the strip was: lengthwise edges between cross sections
    seam_pairs = set()
    if mark_sharp:
        for f in region:
            for e in f.edges:
                if e in cross:
                    continue
                a, b = survivor.get(e.verts[0]), survivor.get(e.verts[1])
                if a is not None and b is not None and a is not b:
                    seam_pairs.add((a, b))
    bmesh.ops.weld_verts(bm, targetmap=target_map)
    for a, b in seam_pairs:
        if a.is_valid and b.is_valid:
            e = bm.edges.get((a, b))
            if e is not None:
                e.smooth = False
    # faces of the strip that collapsed
    dead = [f for f in region if f.is_valid and len(set(f.verts)) < 3]
    if dead:
        bmesh.ops.delete(bm, geom=dead, context='FACES')
    bm.normal_update()
    return len(groups), skipped


SET_PREFIX = "eb_set_"
EPS = 1e-4

MODE_ITEMS = (
    ('EVEN', "Even", "Offset every new vertex by exactly the width, sideways out of the loop"),
    ('MITER', "Blender", "Plain Blender bevel (width measured per edge)"),
)


# ----------------------------------------------------------------------------
# Matching edges by position (the mesh changes shape between rebuilds)
# ----------------------------------------------------------------------------

def _on_segment(pt, p, q):
    _cp, f = intersect_point_line(pt, p, q)
    f = max(0.0, min(1.0, f))
    return (p + (q - p) * f - pt).length <= EPS


def _edges_on_segments(edges, segs):
    """Indices of edges (any container with .verts) that lie on one of the segments."""
    n = len(edges)
    if not n or not segs:
        return set()
    kd = kdtree.KDTree(n)
    for i, e in enumerate(edges):
        kd.insert((e.verts[0].co + e.verts[1].co) * 0.5, i)
    kd.balance()
    out = set()
    for p, q in segs:
        radius = (q - p).length * 0.5 + EPS * 4
        for _co, i, _d in kd.find_range((p + q) * 0.5, radius):
            e = edges[i]
            if _on_segment(e.verts[0].co, p, q) and _on_segment(e.verts[1].co, p, q):
                out.add(i)
    return out


def _segments_of(bm, attr):
    layer = bm.edges.layers.bool.get(attr)
    if layer is None:
        return []
    return [(e.verts[0].co.copy(), e.verts[1].co.copy()) for e in bm.edges if e[layer]]


def _select_matching(bm, segs):
    bm.edges.ensure_lookup_table()
    for v in bm.verts:
        v.select_set(False)
    for e in bm.edges:
        e.select_set(False)
    hit = _edges_on_segments(bm.edges, segs)
    for i in hit:
        bm.edges[i].select_set(True)
    return len(hit)


# ----------------------------------------------------------------------------
# Rebuild
# ----------------------------------------------------------------------------

_suspend = 0


def _write_mesh(ob, bm):
    if ob.mode == 'EDIT':
        tmp = bpy.data.meshes.new("_eb_tmp")
        bm.to_mesh(tmp)
        edit = bmesh.from_edit_mesh(ob.data)
        edit.clear()
        edit.from_mesh(tmp)
        bmesh.update_edit_mesh(ob.data, loop_triangles=True, destructive=True)
        bpy.data.meshes.remove(tmp)
    else:
        bm.to_mesh(ob.data)
        ob.data.update()


def rebuild(ob):
    src = ob.eb_source
    if src is None:
        return
    sbm = bmesh.new()
    sbm.from_mesh(src)
    seg_sets = {it.set_attr: _segments_of(sbm, it.set_attr) for it in ob.eb_items}
    for lay in [l for l in sbm.edges.layers.bool if l.name.startswith(SET_PREFIX)]:
        sbm.edges.layers.bool.remove(lay)
    for it in ob.eb_items:
        if not it.enabled:
            continue
        segs = seg_sets.get(it.set_attr)
        if not segs:
            continue
        if _select_matching(sbm, segs) == 0:
            continue
        even_bevel(sbm, it.width, it.segments, it.profile, it.loop_slide, it.mode, it.smooth)
        for v in sbm.verts:
            v.select_set(False)
    _write_mesh(ob, sbm)
    sbm.free()


def _on_change(self, context):
    if _suspend:
        return
    ob = self.id_data
    if isinstance(ob, bpy.types.Object) and ob.eb_auto:
        rebuild(ob)


class EB_Item(bpy.types.PropertyGroup):
    name: StringProperty(name="Name", default="Bevel")
    set_attr: StringProperty(default="")
    enabled: BoolProperty(
        name="Enabled", default=True, update=_on_change,
        description="Turn off to see this bevel's seam edges again (then Apply Selection to change them)")
    width: FloatProperty(name="Width", default=0.02, min=0.0, precision=4,
                         subtype='DISTANCE', update=_on_change)
    segments: IntProperty(name="Segments", default=2, min=1, max=16, update=_on_change)
    profile: FloatProperty(name="Profile", default=0.5, min=0.0, max=1.0,
                           subtype='FACTOR', update=_on_change)
    loop_slide: BoolProperty(name="Loop Slide", default=True, update=_on_change)
    mode: EnumProperty(name="Mode", items=MODE_ITEMS, default='EVEN', update=_on_change)
    smooth: IntProperty(
        name="Smooth Direction", default=0, min=0, max=20, update=_on_change,
        description="Average the loop this many times before measuring directions (calms a lumpy rim)")


def _entry(ob, i):
    if ob is None or not (0 <= i < len(ob.eb_items)):
        return None
    return ob.eb_items[i]


def _mapped_flags(ob, bm_edit, attr):
    """Mark, in the stored copy, the edges that the selected edges of bm_edit lie on."""
    sel = [(e.verts[0].co.copy(), e.verts[1].co.copy()) for e in bm_edit.edges if e.select]
    sbm = bmesh.new()
    sbm.from_mesh(ob.eb_source)
    sbm.edges.ensure_lookup_table()
    layer = sbm.edges.layers.bool.get(attr)
    if layer is None:
        layer = sbm.edges.layers.bool.new(attr)
    for e in sbm.edges:
        e[layer] = False
    count = 0
    if sel:
        # an edge of the copy is a seam when a selected piece lies on it
        kd = kdtree.KDTree(len(sbm.edges))
        longest = 0.0
        for i, e in enumerate(sbm.edges):
            a, b = e.verts[0].co, e.verts[1].co
            kd.insert((a + b) * 0.5, i)
            longest = max(longest, (a - b).length)
        kd.balance()
        for a, b in sel:
            for _co, i, _d in kd.find_range((a + b) * 0.5, longest * 0.5 + EPS * 4):
                se = sbm.edges[i]
                p, q = se.verts[0].co, se.verts[1].co
                if _on_segment(a, p, q) and _on_segment(b, p, q):
                    if not se[layer]:
                        count += 1
                    se[layer] = True
    if count:
        sbm.to_mesh(ob.eb_source)
    sbm.free()
    return count


def _ensure_source(ob):
    if ob.eb_source is not None:
        return
    if ob.mode == 'EDIT':
        bm = bmesh.from_edit_mesh(ob.data).copy()
    else:
        bm = bmesh.new()
        bm.from_mesh(ob.data)
    me = bpy.data.meshes.new(ob.name + "_EB_Source")
    bm.to_mesh(me)
    bm.free()
    me.use_fake_user = False
    ob.eb_source = me


def _drop_source(ob):
    me = ob.eb_source
    ob.eb_source = None
    if me is not None and me.users == 0:
        bpy.data.meshes.remove(me)


def _add_item(ob):
    """Create a bevel entry from the edges selected in the edit mesh and rebuild.
    Returns (item, message)."""
    global _suspend
    bm = bmesh.from_edit_mesh(ob.data)
    if not any(e.select for e in bm.edges):
        return None, "Select the edges to bevel first"
    _ensure_source(ob)
    _suspend += 1
    try:
        ob.eb_counter += 1
        it = ob.eb_items.add()
        it.set_attr = "%s%d" % (SET_PREFIX, ob.eb_counter)
        it.name = "Bevel %d" % ob.eb_counter
        if len(ob.eb_items) > 1:                  # start from the previous settings
            prev = ob.eb_items[len(ob.eb_items) - 2]
            it.width, it.segments, it.profile = prev.width, prev.segments, prev.profile
            it.loop_slide, it.mode, it.smooth = prev.loop_slide, prev.mode, prev.smooth
    finally:
        _suspend -= 1
    if _mapped_flags(ob, bm, it.set_attr) == 0:
        ob.eb_items.remove(len(ob.eb_items) - 1)
        if not len(ob.eb_items):
            _drop_source(ob)
        return None, "Those edges are already part of a bevel"
    rebuild(ob)
    return it, ""


def _cancel_item(ob, index):
    """Remove an entry again (modal cancel) and re-select its seam edges."""
    segs = []
    if 0 <= index < len(ob.eb_items) and ob.eb_source is not None:
        sbm = bmesh.new()
        sbm.from_mesh(ob.eb_source)
        segs = _segments_of(sbm, ob.eb_items[index].set_attr)
        sbm.free()
        ob.eb_items.remove(index)
    rebuild(ob)
    if not len(ob.eb_items):
        _drop_source(ob)
    if ob.mode == 'EDIT' and segs:
        bm = bmesh.from_edit_mesh(ob.data)
        _select_matching(bm, segs)
        bm.select_flush_mode()
        bmesh.update_edit_mesh(ob.data, loop_triangles=False, destructive=False)


def _apply_upto(ob, last):
    """Bake bevels 0..last into the stored original; the rest stay editable."""
    src = ob.eb_source
    sbm = bmesh.new()
    sbm.from_mesh(src)
    seg_sets = {it.set_attr: _segments_of(sbm, it.set_attr) for it in ob.eb_items}
    for lay in [l for l in sbm.edges.layers.bool if l.name.startswith(SET_PREFIX)]:
        sbm.edges.layers.bool.remove(lay)
    for it in list(ob.eb_items)[:last + 1]:
        if not it.enabled or not seg_sets.get(it.set_attr):
            continue
        if _select_matching(sbm, seg_sets[it.set_attr]) == 0:
            continue
        even_bevel(sbm, it.width, it.segments, it.profile, it.loop_slide, it.mode, it.smooth)
        for v in sbm.verts:
            v.select_set(False)
    rest = list(ob.eb_items)[last + 1:]
    sbm.edges.ensure_lookup_table()
    for it in rest:
        layer = sbm.edges.layers.bool.new(it.set_attr)
        for i in _edges_on_segments(sbm.edges, seg_sets.get(it.set_attr, [])):
            sbm.edges[i][layer] = True
    sbm.to_mesh(src)
    sbm.free()
    for i in range(last, -1, -1):
        ob.eb_items.remove(i)
    rebuild(ob)
    if not len(ob.eb_items):
        _drop_source(ob)


# ----------------------------------------------------------------------------
# Operators
# ----------------------------------------------------------------------------

class EB_OT_add(bpy.types.Operator):
    bl_idname = "object.eb_add"
    bl_label = "Add Bevel"
    bl_description = ("Add a bevel on the edges selected in Edit Mode. Each bevel has its own edges "
                      "and settings. The mesh is rebuilt from the stored original, so manual edits "
                      "made after the first bevel are lost")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and ob.mode == 'EDIT'

    def execute(self, context):
        ob = context.active_object
        it, msg = _add_item(ob)
        if it is None:
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}
        return {'FINISHED'}


class EB_OT_bevel_modal(bpy.types.Operator):
    bl_idname = "mesh.even_bevel_modal"
    bl_label = "Even Bevel"
    bl_description = ("Interactive even bevel: move the mouse for the width, wheel for "
                      "segments, M for the mode, click to confirm. Creates an entry in the Even Bevel "
                      "list you can edit later")
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING', 'GRAB_CURSOR'}

    @classmethod
    def poll(cls, context):
        ob = context.edit_object
        return ob is not None and ob.type == 'MESH'

    def _header(self, context):
        ob = self._ob
        it = ob.eb_items[self._index]
        if context.area:
            context.area.header_text_set(
                "Even Bevel   Width: %.4f   Segments: %d   Mode: %s   |   mouse: width, wheel: segments, "
                "M: mode, click/Enter: confirm, Esc/RMB: cancel" % (it.width, it.segments, it.mode))

    def _set(self, context, **vals):
        global _suspend
        ob = self._ob
        it = ob.eb_items[self._index]
        _suspend += 1
        try:
            for k, v in vals.items():
                setattr(it, k, v)
        finally:
            _suspend -= 1
        rebuild(ob)
        self._header(context)

    def invoke(self, context, event):
        ob = context.edit_object
        it, msg = _add_item(ob)
        if it is None:
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}
        self._ob = ob
        self._index = len(ob.eb_items) - 1
        self._x0 = event.mouse_x
        self._w0 = it.width
        dims = ob.dimensions
        self._k = max(dims.length, 1e-3) * 0.0005
        self._header(context)
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _end(self, context):
        if context.area:
            context.area.header_text_set(None)

    def modal(self, context, event):
        ob = self._ob
        if event.type == 'MOUSEMOVE':
            w = max(0.0, self._w0 + (event.mouse_x - self._x0) * self._k)
            self._set(context, width=w)
        elif event.type in {'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'NUMPAD_PLUS', 'NUMPAD_MINUS'} \
                and event.value in {'PRESS', 'NOTHING'}:
            it = ob.eb_items[self._index]
            up = event.type in {'WHEELUPMOUSE', 'NUMPAD_PLUS'}
            self._set(context, segments=max(1, min(16, it.segments + (1 if up else -1))))
        elif event.type == 'M' and event.value == 'PRESS':
            it = ob.eb_items[self._index]
            self._set(context, mode='MITER' if it.mode == 'EVEN' else 'EVEN')
        elif event.type in {'LEFTMOUSE', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            self._end(context)
            return {'FINISHED'}
        elif event.type in {'ESC', 'RIGHTMOUSE'} and event.value == 'PRESS':
            _cancel_item(ob, self._index)
            self._end(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}


class EB_OT_remove(bpy.types.Operator):
    bl_idname = "object.eb_remove"
    bl_label = "Remove Bevel"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        if _entry(ob, self.index) is None:
            return {'CANCELLED'}
        ob.eb_items.remove(self.index)
        rebuild(ob)
        if not len(ob.eb_items):
            _drop_source(ob)
        return {'FINISHED'}


class EB_OT_apply_sel(bpy.types.Operator):
    bl_idname = "object.eb_apply_sel"
    bl_label = "Apply Selection"
    bl_description = ("Use the edges currently selected in Edit Mode as this bevel's edges. "
                      "Turn the bevel off first to see its seam edges again")
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and ob.mode == 'EDIT'

    def execute(self, context):
        ob = context.active_object
        it = _entry(ob, self.index)
        if it is None:
            return {'CANCELLED'}
        bm = bmesh.from_edit_mesh(ob.data)
        if not any(e.select for e in bm.edges):
            self.report({'WARNING'}, "No edges selected")
            return {'CANCELLED'}
        n = _mapped_flags(ob, bm, it.set_attr)
        if n == 0:
            self.report({'WARNING'}, "Selected edges don't lie on the original mesh's edges "
                                     "(select the seam edges, with this bevel turned off)")
            return {'CANCELLED'}
        global _suspend
        _suspend += 1
        try:
            it.enabled = True
        finally:
            _suspend -= 1
        rebuild(ob)
        self.report({'INFO'}, "Stored %d seam edge(s)" % n)
        return {'FINISHED'}


class EB_OT_get_sel(bpy.types.Operator):
    bl_idname = "object.eb_get_sel"
    bl_label = "Get Selection"
    bl_description = ("Select this bevel's seam edges. They only exist while the bevel is turned off "
                      "(otherwise the bevel has replaced them)")
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and ob.mode == 'EDIT'

    def execute(self, context):
        ob = context.active_object
        it = _entry(ob, self.index)
        if it is None or ob.eb_source is None:
            return {'CANCELLED'}
        sbm = bmesh.new()
        sbm.from_mesh(ob.eb_source)
        segs = _segments_of(sbm, it.set_attr)
        sbm.free()
        bm = bmesh.from_edit_mesh(ob.data)
        n = _select_matching(bm, segs)
        bm.select_flush_mode()
        bmesh.update_edit_mesh(ob.data, loop_triangles=False, destructive=False)
        if n == 0:
            self.report({'WARNING'}, "No seam edges found: turn this bevel off to see them")
            return {'CANCELLED'}
        self.report({'INFO'}, "Selected %d edge(s)" % n)
        return {'FINISHED'}


class EB_OT_apply(bpy.types.Operator):
    bl_idname = "object.eb_apply"
    bl_label = "Apply Bevel"
    bl_description = ("Bake this bevel (and every bevel above it in the list) into the mesh. "
                      "Disabled bevels among them are dropped. Later bevels stay editable")
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()
    all: BoolProperty(default=False)

    def execute(self, context):
        ob = context.active_object
        if ob is None or ob.eb_source is None or not len(ob.eb_items):
            return {'CANCELLED'}
        last = len(ob.eb_items) - 1 if self.all else self.index
        if not (0 <= last < len(ob.eb_items)):
            return {'CANCELLED'}
        _apply_upto(ob, last)
        return {'FINISHED'}


class EB_OT_unbevel(bpy.types.Operator):
    bl_idname = "mesh.eb_unbevel"
    bl_label = "Unbevel"
    bl_description = ("Collapse an existing bevel back into one edge and mark it sharp. Select the bevel's faces "
                      "(Alt+click on the strip in face mode selects a whole row; Shift+Alt+click adds "
                      "more rows), then press this. Works on any mesh")
    bl_options = {'REGISTER', 'UNDO'}

    mark_sharp: BoolProperty(
        name="Mark Sharp", default=True,
        description="Mark the collapsed edge as sharp so the corner keeps its hard shading")

    @classmethod
    def poll(cls, context):
        ob = context.edit_object
        return ob is not None and ob.type == 'MESH'

    def execute(self, context):
        ob = context.edit_object
        bm = bmesh.from_edit_mesh(ob.data)
        res = unbevel(bm, self.mark_sharp)
        if res is None:
            self.report({'WARNING'}, "Select the bevel's faces first")
            return {'CANCELLED'}
        merged, skipped = res
        bmesh.update_edit_mesh(ob.data, loop_triangles=True, destructive=True)
        if merged == 0:
            self.report({'WARNING'}, "No quads selected")
            return {'CANCELLED'}
        msg = "Collapsed %d cross section(s)" % merged
        if skipped:
            msg += "; %d non-quad face(s) left alone" % skipped
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class EB_OT_rebuild(bpy.types.Operator):
    bl_idname = "object.eb_rebuild"
    bl_label = "Rebuild"
    bl_description = "Rebuild the mesh from the stored original with the current bevels"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        ob = context.active_object
        if ob is None or ob.eb_source is None:
            return {'CANCELLED'}
        rebuild(ob)
        return {'FINISHED'}


class EB_OT_clear(bpy.types.Operator):
    bl_idname = "object.eb_clear"
    bl_label = "Remove All"
    bl_description = "Remove every bevel and restore the original mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        ob = context.active_object
        if ob is None or ob.eb_source is None:
            return {'CANCELLED'}
        ob.eb_items.clear()
        rebuild(ob)
        _drop_source(ob)
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------------

class VIEW3D_PT_even_bevel(bpy.types.Panel):
    bl_label = "Even Bevel"
    bl_idname = "VIEW3D_PT_even_bevel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_modeling"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH'

    def draw(self, context):
        ob = context.active_object
        layout = self.layout

        for i, it in enumerate(ob.eb_items):
            box = layout.box()
            row = box.row(align=True)
            row.prop(it, "enabled", text="")
            row.prop(it, "name", text="")
            op = row.operator("object.eb_apply", text="", icon='CHECKMARK')
            op.index, op.all = i, False
            row.operator("object.eb_remove", text="", icon='X').index = i
            if not it.enabled:
                row = box.row(align=True)
                row.operator("object.eb_apply_sel", text="Apply Selection",
                             icon='CHECKMARK').index = i
                row.operator("object.eb_get_sel", text="Get Selection",
                             icon='RESTRICT_SELECT_OFF').index = i
                continue
            box.row(align=True).prop(it, "mode", expand=True)
            col = box.column(align=True)
            col.prop(it, "width")
            col.prop(it, "segments")
            col.prop(it, "profile", slider=True)
            row = box.row(align=True)
            row.prop(it, "loop_slide")
            if it.mode == 'EVEN':
                box.prop(it, "smooth")

        if ob.mode == 'EDIT':
            layout.operator("mesh.even_bevel_modal", text="Even Bevel (interactive)", icon='MOD_BEVEL')
            layout.operator("object.eb_add", icon='ADD')
        else:
            layout.label(text="Edit Mode: select edges, Add Bevel", icon='INFO')
        if ob.eb_source is not None and len(ob.eb_items) > 1:
            op = layout.operator("object.eb_apply", text="Apply All", icon='CHECKMARK')
            op.all = True
        if ob.mode == 'EDIT':
            layout.operator("mesh.eb_unbevel", icon='LOOP_BACK')
        row = layout.row(align=True)
        row.prop(ob, "eb_auto", text="Auto Update")
        if ob.eb_source is not None:
            row.operator("object.eb_rebuild", text="", icon='FILE_REFRESH')
            row.operator("object.eb_clear", text="", icon='TRASH')
            layout.label(text="Mesh edits are lost on rebuild", icon='ERROR')


classes = (
    EB_Item,
    EB_OT_add,
    EB_OT_bevel_modal,
    EB_OT_remove,
    EB_OT_apply_sel,
    EB_OT_get_sel,
    EB_OT_apply,
    EB_OT_unbevel,
    EB_OT_rebuild,
    EB_OT_clear,
    VIEW3D_PT_even_bevel,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    Ob = bpy.types.Object
    Ob.eb_items = CollectionProperty(type=EB_Item)
    Ob.eb_counter = IntProperty(default=0, options={'HIDDEN'})
    Ob.eb_source = PointerProperty(type=bpy.types.Mesh, options={'HIDDEN'})
    Ob.eb_auto = BoolProperty(
        name="Auto Update", default=True,
        description="Rebuild the mesh whenever a setting changes (turn off on heavy meshes, "
                    "then use the refresh button)")


def unregister():
    Ob = bpy.types.Object
    del Ob.eb_auto
    del Ob.eb_source
    del Ob.eb_counter
    del Ob.eb_items
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
