"""Light Baker: bake a light housing (and its point lights) onto a separate light mesh.

Workflow: the housing is the source, the light mesh (slightly extruded from the housing, with
its own UVs) is the target. Cycles "Selected to Active" projects the housing shading onto the
light mesh's UVs.

  Bake Lit    Combined pass: housing shading lit by the chosen point lights only.
  Bake Glass  Diffuse colour only: the housing's own colours, no lighting at all.

Everything the bake changes (render engine, other lights, world, the light mesh's materials,
modifiers, visibility, active UV map, selection) is put back afterwards.
"""
import bpy
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty,
                       FloatVectorProperty, IntProperty, PointerProperty, StringProperty)

RES_ITEMS = [(str(n), "%d" % n, "") for n in (256, 512, 1024, 2048, 4096)]


class LB_ObjRef(bpy.types.PropertyGroup):
    obj: PointerProperty(name="Object", type=bpy.types.Object)


ZONE_PRESETS = {
    'BRAKE': ("Brake light", (1.0, 0.0, 0.0)),
    'INDICATOR': ("Indicator", (1.0, 0.35, 0.0)),
    'HEADLIGHT': ("Headlight", (1.0, 1.0, 1.0)),
    'REVERSE': ("Reverse light", (1.0, 1.0, 1.0)),
    'CUSTOM': ("Custom", (1.0, 0.0, 0.0)),
}
ZONE_ITEMS = [(k, v[0], "") for k, v in ZONE_PRESETS.items()]


def _zone_kind_update(self, context):
    if self.kind != 'CUSTOM':
        self.color = ZONE_PRESETS[self.kind][1]


class LB_Zone(bpy.types.PropertyGroup):
    """A part of the housing that gets one flat colour for the bake (stored as a face attribute)."""
    kind: EnumProperty(name="Type", items=ZONE_ITEMS, default='BRAKE', update=_zone_kind_update)
    color: FloatVectorProperty(name="Color", subtype='COLOR', size=3, min=0.0, max=1.0,
                               default=(1.0, 0.0, 0.0))
    attr: StringProperty(default="")


class LightBakeSettings(bpy.types.PropertyGroup):
    zones: CollectionProperty(type=LB_Zone)
    zone_counter: IntProperty(default=0)
    use_zones: BoolProperty(name="Recolor Housing by Parts", default=True,
                            description="During the bake the housing gets flat part colours "
                                        "(its normal maps are kept). Your materials are restored afterwards")
    other_color: FloatVectorProperty(name="Other Parts", subtype='COLOR', size=3, min=0.0, max=1.0,
                                     default=(0.02, 0.02, 0.02),
                                     description="Colour of housing faces that are not in any part")
    roughness_mode: EnumProperty(
        name="Roughness",
        items=[('MAP', "Housing Map", "Use the housing's own roughness textures and values, "
                                      "multiplied by the scale below"),
               ('FLAT', "Flat Value", "One roughness value for the whole housing")],
        default='MAP')
    roughness: FloatProperty(name="Value", default=0.5, min=0.0, max=1.0,
                             description="Flat roughness for the whole housing. 1 = fully matte, no shine")
    roughness_scale: FloatProperty(name="Scale", default=1.0, min=0.0, max=3.0,
                                   description="Multiplies the housing's roughness (textures included). "
                                               "Above 1 = more matte, below 1 = shinier")
    use_bulb: BoolProperty(name="Glass Bulb", default=False,
                           description="Cover each point light in a frosted glass bulb for the lit bake. "
                                       "The light then comes from the bulb's surface (soft, and visible "
                                       "in the housing's reflections) instead of from a single point")
    bulb_radius: FloatProperty(name="Bulb Radius", default=0.01, min=0.0005, max=1.0, unit='LENGTH',
                               description="Radius of the bulb around each light. Keep it small enough "
                                           "to fit inside the housing")
    bulb_strength: FloatProperty(name="Bulb Brightness", default=1.0, min=0.01, max=50.0,
                                 description="Multiplies the bulb's brightness. 1 = the same total "
                                             "light as the point light")
    bulb_tint: FloatVectorProperty(name="Glass Tint", subtype='COLOR', size=3, default=(1.0, 1.0, 1.0),
                                   min=0.0, max=1.0,
                                   description="Colour of the glass, multiplied with the light's colour")
    reflections: BoolProperty(name="Reflections", default=True,
                              description="Include glossy reflections in the lit bake. Turn off for "
                                          "no shine at all, from the point lights or anything else")
    contrast: FloatProperty(name="Contrast", default=1.0, min=0.0, max=3.0,
                            description="1 = unchanged. Above 1 pushes brights brighter and darks "
                                        "darker, below 1 flattens the image (applied in sRGB, "
                                        "around mid grey)")
    apply_material: BoolProperty(name="Apply to Light Mesh", default=False,
                                 description="After the bake, give the light mesh a material using "
                                             "the baked image (replaces its current materials)")
    emit_strength: FloatProperty(name="Emission", default=1.0, min=0.0, max=50.0,
                                 description="Glow of the applied material for the lit bake "
                                             "(0 = no emission)")
    alpha_from_light: BoolProperty(name="Opacity from Light", default=False,
                                   description="Make dark (unlit) areas transparent and lit areas "
                                               "opaque, so the light fades out where it gets weak")
    light_alpha_min: FloatProperty(name="Min Opacity", default=0.0, min=0.0, max=1.0,
                                   description="Opacity of the darkest areas")
    light_alpha_curve: FloatProperty(name="Curve", default=1.0, min=0.1, max=5.0,
                                     description="Above 1 only the strongest light stays opaque, "
                                                 "below 1 even weak light stays visible")
    denoise: BoolProperty(name="Denoise", default=True,
                          description="Run Blender's denoiser (OpenImageDenoise) over the lit bake")
    save_alpha_map: BoolProperty(name="Save Alpha Map", default=True,
                                 description="Also write the alpha as its own grayscale PNG "
                                             "(same name + _alpha). White = opaque")
    base_image: PointerProperty(type=bpy.types.Image, name="Base Texture",
                                description="An existing texture (in the light mesh's UV layout) to "
                                            "blend the bake with. Empty = bake only")
    base_mode: EnumProperty(name="Blend", default='MIX', items=[
        ('MIX', "Mix", "The bake covers the texture, where the bake is opaque"),
        ('ADD', "Add", "Bake light added on top of the texture"),
        ('MULTIPLY', "Multiply", "Texture tinted and darkened by the bake"),
        ('SCREEN', "Screen", "Soft add that never goes past white")])
    base_fac: FloatProperty(name="Bake Strength", default=1.0, min=0.0, max=1.0, subtype='FACTOR',
                            description="How strongly the bake is blended onto the texture")
    fade_black: BoolProperty(name="Fade to Black", default=True,
                             description="The edge fade also darkens the colour to black, so the "
                                         "border never shows a colour shift")
    fade: FloatProperty(name="Edge Fade", default=4.0, min=0.0, max=50.0, subtype='PERCENTAGE',
                        description="Width of the soft border where the light fades to transparent, "
                                    "as a percent of the image width (0 = hard edge). It follows "
                                    "the resolution, so 4% looks the same at 1024 and 4096. Works "
                                    "per UV island, so keep the light mesh as one island")
    lens_alpha: FloatProperty(name="Lens Opacity", default=1.0, min=0.0, max=1.0,
                              description="Alpha of the baked texture. Below 1 the lens is slightly "
                                          "transparent, so it shows what is behind it in the game")
    target: PointerProperty(name="Light Mesh", type=bpy.types.Object,
                            poll=lambda self, o: o.type == 'MESH',
                            description="The light mesh that receives the bake (needs UVs)")
    sources: CollectionProperty(type=LB_ObjRef)
    lights: CollectionProperty(type=LB_ObjRef)
    uv_slot: IntProperty(name="UV Map", default=1, min=1, max=8,
                         description="Which UV map of the light mesh to bake into (1 = first)")
    resolution: EnumProperty(name="Resolution", items=RES_ITEMS, default="1024")
    margin: IntProperty(name="Margin", default=16, min=0, max=64,
                        description="Pixels the bake is extended past the UV islands")
    extrusion: FloatProperty(name="Extrusion", default=0.02, min=0.0, soft_max=0.5, unit='LENGTH',
                             description="How far the rays start out from the light mesh "
                                         "(must be bigger than the gap to the housing)")
    max_ray: FloatProperty(name="Max Ray Distance", default=0.0, min=0.0, soft_max=1.0, unit='LENGTH',
                           description="0 = unlimited. Limits how far the rays reach into the housing")
    auto_expose: BoolProperty(name="Auto Exposure", default=True,
                              description="Lit bake: scale the result so its bright areas reach "
                                          "full brightness, whatever the light strength is")
    exposure: FloatProperty(name="Exposure", default=0.0, min=-10.0, max=10.0,
                            description="Extra brightness in stops (EV) on top of Auto Exposure")
    samples: IntProperty(name="Samples", default=128, min=1, max=4096)
    ignore_world: BoolProperty(name="Ignore World Light", default=True,
                               description="Only your point lights light the housing")
    path_lit: StringProperty(name="Lit", subtype='FILE_PATH', default="//light_lit.png")
    path_glass: StringProperty(name="Glass", subtype='FILE_PATH', default="//light_glass.png")


# ----------------------------------------------------------------------------
# Helpers
# ----------------------------------------------------------------------------

def _refs(coll):
    return [r.obj for r in coll if r.obj is not None]


def _add_selected(coll, objs, types):
    have = {r.obj for r in coll if r.obj is not None}
    n = 0
    for o in objs:
        if o.type in types and o not in have:
            coll.add().obj = o
            n += 1
    return n


def _temp_material(image):
    mat = bpy.data.materials.new("_LightBake_tmp")
    mat.use_nodes = True
    nt = mat.node_tree
    node = nt.nodes.new('ShaderNodeTexImage')
    node.image = image
    nt.nodes.active = node
    for n in nt.nodes:
        n.select = (n == node)
    return mat


def _set_in(node, name, value):
    sock = node.inputs.get(name)
    if sock is None:
        return
    for l in list(sock.links):
        sock.id_data.links.remove(l)
    try:
        sock.default_value = value
    except Exception:
        pass


def _scale_input(node, name, k):
    """Multiply a socket's value, or whatever texture feeds it, by k (clamped 0..1)."""
    sock = node.inputs.get(name)
    if sock is None or k == 1.0:
        return
    nt = sock.id_data
    if sock.links:
        src = sock.links[0].from_socket
        mul = nt.nodes.new('ShaderNodeMath')
        mul.operation = 'MULTIPLY'
        mul.use_clamp = True
        mul.inputs[1].default_value = k
        nt.links.new(src, mul.inputs[0])
        nt.links.new(mul.outputs[0], sock)
    else:
        try:
            sock.default_value = min(max(sock.default_value * k, 0.0), 1.0)
        except Exception:
            pass


def _recolor_tree(nt, color, rough, spec, groups, depth=0):
    """Flat colour (if given) and roughness (if given) on every Principled BSDF in the tree, and
    in copies of its node groups. Everything else, normal maps and bump included, stays as it was.
    Returns how many Principled nodes were changed."""
    n_done = 0
    for node in list(nt.nodes):
        if node.bl_idname == 'ShaderNodeBsdfPrincipled':
            if color is not None:
                _set_in(node, "Base Color", (color[0], color[1], color[2], 1.0))
                _set_in(node, "Metallic", 0.0)
                _set_in(node, "Alpha", 1.0)
                _set_in(node, "Transmission Weight", 0.0)
                _set_in(node, "Subsurface Weight", 0.0)
                _set_in(node, "Emission Strength", 0.0)
                _set_in(node, "Emission Color", (0.0, 0.0, 0.0, 1.0))
            if rough is not None:
                mode, val = rough
                if mode == 'FLAT':
                    _set_in(node, "Roughness", val)
                    _set_in(node, "Coat Weight", 0.0)
                else:
                    _scale_input(node, "Roughness", val)
            n_done += 1
        elif node.bl_idname == 'ShaderNodeGroup' and node.node_tree is not None and depth < 4:
            g = node.node_tree.copy()
            groups.append(g)
            node.node_tree = g
            n_done += _recolor_tree(g, color, rough, spec, groups, depth + 1)
    return n_done


def _zone_material(orig, color, rough, spec, groups):
    """Copy of the housing material with a flat colour and/or roughness, keeping its normal/bump
    setup. color / rough None = leave that alone."""
    mat = orig.copy() if orig is not None else bpy.data.materials.new("_LB_zone")
    mat.name = "_LB_zone"
    mat.use_nodes = True
    nt = mat.node_tree
    if orig is not None and _recolor_tree(nt, color, rough, spec, groups):
        return mat
    # no Principled to change (custom shader): build one and keep any normal/bump node
    col = color if color is not None else (0.5, 0.5, 0.5)
    normal = None
    for n in nt.nodes:
        if n.bl_idname in ('ShaderNodeNormalMap', 'ShaderNodeBump'):
            normal = n.outputs["Normal"] if "Normal" in n.outputs else n.outputs[0]
            break
    for n in nt.nodes:
        if n.bl_idname == 'ShaderNodeOutputMaterial':
            n.is_active_output = False
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    out.is_active_output = True
    pr = nt.nodes.new('ShaderNodeBsdfPrincipled')
    pr.inputs["Base Color"].default_value = (col[0], col[1], col[2], 1.0)
    pr.inputs["Metallic"].default_value = 0.0
    pr.inputs["Roughness"].default_value = (rough[1] if rough[0] == 'FLAT' else 0.5) if rough else 0.6
    nt.links.new(pr.outputs[0], out.inputs["Surface"])
    if normal is not None:
        nt.links.new(normal, pr.inputs["Normal"])
    return mat


def _override_housing(sources, s):
    """Give every housing face its part colour. Returns a function that undoes it."""
    import numpy as np
    colorize = bool(s.use_zones and len(s.zones))
    rough = (('FLAT', s.roughness) if s.roughness_mode == 'FLAT'
             else (('MAP', s.roughness_scale) if s.roughness_scale != 1.0 else None))
    spec = None
    saved, temps, groups, seen = [], [], [], set()
    for o in sources:
        me = o.data
        if me.name in seen:
            continue
        seen.add(me.name)
        n = len(me.polygons)
        idx = np.empty(n, dtype=np.int32)
        me.polygons.foreach_get("material_index", idx)
        orig = list(me.materials)
        state = np.zeros(n, dtype=np.int32)
        for zi, z in enumerate(s.zones if colorize else []):
            a = me.attributes.get(z.attr)
            if a is not None and a.domain == 'FACE' and len(a.data) == n:
                v = np.zeros(n, dtype=np.int32)
                a.data.foreach_get("value", v)
                state[v != 0] = zi + 1
        combos, new_mats = {}, []
        for key in sorted(set(zip(idx.tolist(), state.tolist()))):
            mi, zs = key
            om = orig[mi] if mi < len(orig) else None
            col = None
            if colorize:
                col = tuple(s.other_color) if zs == 0 else tuple(s.zones[zs - 1].color)
            new_mats.append(_zone_material(om, col, rough, spec, groups))
            combos[key] = len(new_mats) - 1
        new_idx = np.array([combos[k] for k in zip(idx.tolist(), state.tolist())], dtype=np.int32)
        saved.append((me, orig, idx))
        temps += new_mats
        me.materials.clear()
        for m in new_mats:
            me.materials.append(m)
        me.polygons.foreach_set("material_index", new_idx)
        me.update()

    def undo():
        for me, orig, idx in saved:
            me.materials.clear()
            for m in orig:
                me.materials.append(m)
            me.polygons.foreach_set("material_index", idx)
            me.update()
        for m in temps:
            try:
                bpy.data.materials.remove(m)
            except Exception:
                pass
        for g in groups:
            try:
                bpy.data.node_groups.remove(g)
            except Exception:
                pass
    return undo


def _box(a, r, axis):
    """Box blur of radius r along one axis (zero outside)."""
    import numpy as np
    if r <= 0:
        return a
    a = np.moveaxis(a, axis, 0)
    pad = np.zeros((a.shape[0] + 2 * r + 1,) + a.shape[1:], dtype=np.float64)
    pad[r + 1:r + 1 + a.shape[0]] = a
    c = np.cumsum(pad, axis=0)
    out = (c[2 * r + 1:2 * r + 1 + a.shape[0]] - c[:a.shape[0]]) / float(2 * r + 1)
    return np.moveaxis(out.astype(np.float32), 0, axis)


def _finish_alpha(image, cover, alpha, fade, s=None, linear=True):
    """Alpha from where the rays actually hit the housing (cover), with the soft edge, lens
    opacity and opacity-from-light. Straight alpha, colours untouched. Returns the alpha (h, w)."""
    import numpy as np
    w, h = image.size
    px = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(px)
    px = px.reshape(h, w, 4)
    m = cover.astype(np.float32)
    if fade > 0:
        b = m
        for _ in range(2):                           # two box passes = a smooth ramp
            b = _box(_box(b, fade, 0), fade, 1)
        f = np.clip((b - 0.5) * 2.0, 0.0, 1.0)
        f = f * f * (3.0 - 2.0 * f)                  # smoothstep
        m = f * m
        if s is not None and s.fade_black:
            px[..., :3] *= f[..., None]
    a = m * alpha
    if s is not None and s.alpha_from_light:
        rgb = px[..., :3] if linear else _srgb_decode(px[..., :3])
        v = np.clip(rgb.max(axis=2), 0.0, 1.0) ** s.light_alpha_curve
        a = a * (s.light_alpha_min + (1.0 - s.light_alpha_min) * v)
    px[..., 3] = a
    image.alpha_mode = 'STRAIGHT'
    image.pixels.foreach_set(px.ravel())
    image.update()
    return a


def _blend_base(image, tex, mode, fac, linear):
    """Blend the finished bake (straight alpha) with an existing texture. Returns the new alpha."""
    import numpy as np
    w, h = image.size
    tw, th = tex.size
    if tw == 0 or th == 0:
        raise RuntimeError("Base texture has no pixels")
    t = np.empty(tw * th * 4, dtype=np.float32)
    tex.pixels.foreach_get(t)
    t = t.reshape(th, tw, 4)
    is_float = tex.is_float
    cs = tex.colorspace_settings.name
    if (tw, th) != (w, h):                           # bilinear resize
        ys = (np.arange(h) + 0.5) * th / h - 0.5
        xs = (np.arange(w) + 0.5) * tw / w - 0.5
        y0 = np.clip(np.floor(ys).astype(int), 0, th - 1); y1 = np.clip(y0 + 1, 0, th - 1)
        x0 = np.clip(np.floor(xs).astype(int), 0, tw - 1); x1 = np.clip(x0 + 1, 0, tw - 1)
        fy = np.clip(ys - y0, 0, 1)[:, None, None]; fx = np.clip(xs - x0, 0, 1)[None, :, None]
        top = t[y0][:, x0] * (1 - fx) + t[y0][:, x1] * fx
        bot = t[y1][:, x0] * (1 - fx) + t[y1][:, x1] * fx
        t = top * (1 - fy) + bot * fy
    trgb, ta = t[..., :3], t[..., 3]
    if not is_float and cs == 'sRGB':                # byte pixels are sRGB encoded
        trgb = _srgb_decode(trgb)
    if not linear:                                   # the glass bake is stored sRGB encoded
        trgb = _srgb_encode(trgb)
    px = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(px)
    px = px.reshape(h, w, 4)
    b, ab = px[..., :3], px[..., 3]
    if mode == 'ADD':
        c = trgb + b
        c = c / np.maximum(c.max(axis=2, keepdims=True), 1.0)
    elif mode == 'MULTIPLY':
        c = trgb * b
    elif mode == 'SCREEN':
        c = 1.0 - (1.0 - trgb) * (1.0 - b)
    else:
        c = b
    wgt = (ab * fac)[..., None]
    ta3 = ta[..., None]
    ao = wgt + ta3 * (1.0 - wgt)
    out = (c * wgt + trgb * ta3 * (1.0 - wgt)) / np.maximum(ao, 1e-6)
    px[..., :3] = np.where(ao > 1e-6, out, 0.0)
    px[..., 3] = ao[..., 0]
    image.alpha_mode = 'STRAIGHT'
    image.pixels.foreach_set(px.ravel())
    image.update()
    return ao[..., 0]


def _make_alpha_image(a, name, path):
    """Grayscale image of the alpha (white = opaque), plain data. Saved next to the bake as
    <name>_alpha.png when there is a path, else packed. Returns the image datablock."""
    import numpy as np, os
    h, w = a.shape
    old = bpy.data.images.get(name)
    if old is not None:
        bpy.data.images.remove(old)
    im = bpy.data.images.new(name, w, h, alpha=False)
    im.colorspace_settings.name = 'Non-Color'
    g = np.clip(a, 0.0, 1.0).astype(np.float32)
    px = np.stack([g, g, g, np.ones_like(g)], axis=2)
    im.pixels.foreach_set(px.ravel())
    im.update()
    if path:
        base, _ext = os.path.splitext(bpy.path.abspath(path))
        im.filepath_raw = base + "_alpha.png"
        im.file_format = 'PNG'
        im.save()
    else:
        im.pack()
    return im


def _denoise(image):
    """Denoise a linear float image with the compositor's OpenImageDenoise. RGB only."""
    import numpy as np, os, tempfile, shutil
    w, h = image.size
    px = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(px)
    px = px.reshape(h, w, 4)
    src = bpy.data.images.new("_LB_dn_in", w, h, alpha=True, float_buffer=True)
    sc = bpy.data.scenes.new("_LB_dn")
    cam_obj = cam_data = ng = out_im = None
    tmp = tempfile.mkdtemp()
    try:
        rgba = px.copy()
        rgba[..., 3] = 1.0
        src.colorspace_settings.name = 'Linear Rec.709'
        src.pixels.foreach_set(rgba.ravel())
        sc.render.resolution_x, sc.render.resolution_y = w, h
        sc.render.resolution_percentage = 100
        sc.render.engine = 'BLENDER_WORKBENCH'
        sc.render.use_compositing = True
        sc.view_settings.view_transform = 'Standard'
        cam_data = bpy.data.cameras.new("_LB_dn_cam")
        cam_obj = bpy.data.objects.new("_LB_dn_cam", cam_data)
        sc.collection.objects.link(cam_obj)
        sc.camera = cam_obj
        if hasattr(sc, "compositing_node_group"):
            ng = bpy.data.node_groups.new("_LB_dn_tree", 'CompositorNodeTree')
            sc.compositing_node_group = ng
            ng.interface.new_socket("Image", in_out='OUTPUT', socket_type='NodeSocketColor')
            out = ng.nodes.new('NodeGroupOutput')
        else:
            sc.use_nodes = True
            ng = sc.node_tree
            for n in list(ng.nodes):
                ng.nodes.remove(n)
            out = ng.nodes.new('CompositorNodeComposite')
        imn = ng.nodes.new('CompositorNodeImage')
        imn.image = src
        dn = ng.nodes.new('CompositorNodeDenoise')
        for name, val in (("HDR", True), ("Quality", 'High'), ("Prefilter", 'Accurate')):
            try:
                dn.inputs[name].default_value = val
            except Exception:
                pass
        ng.links.new(imn.outputs["Image"], dn.inputs["Image"])
        ng.links.new(dn.outputs["Image"], out.inputs[0])
        path = os.path.join(tmp, "dn.exr")
        sc.render.image_settings.file_format = 'OPEN_EXR'
        sc.render.image_settings.color_depth = '32'
        sc.render.filepath = path
        bpy.ops.render.render(write_still=True, scene=sc.name)
        out_im = bpy.data.images.load(path)
        res = np.empty(w * h * 4, dtype=np.float32)
        out_im.pixels.foreach_get(res)
        res = res.reshape(h, w, 4)
        px[..., :3] = res[..., :3]
        image.pixels.foreach_set(px.ravel())
        image.update()
        return True
    except Exception:
        return False
    finally:
        for img in (src, out_im):
            if img is not None:
                bpy.data.images.remove(img)
        if cam_obj is not None:
            bpy.data.objects.remove(cam_obj)
        if cam_data is not None:
            bpy.data.cameras.remove(cam_data)
        bpy.data.scenes.remove(sc)
        if ng is not None and ng.name in bpy.data.node_groups:
            bpy.data.node_groups.remove(ng)
        shutil.rmtree(tmp, ignore_errors=True)


def _srgb_encode(x):
    import numpy as np
    x = np.clip(x, 0.0, 1.0)
    return np.where(x <= 0.0031308, x * 12.92, 1.055 * np.power(x, 1.0 / 2.4) - 0.055)


def _srgb_decode(x):
    import numpy as np
    return np.where(x <= 0.04045, x / 12.92, np.power((x + 0.055) / 1.055, 2.4))


def _contrast(image, k, linear):
    """Contrast around mid grey in sRGB. linear=True: the image holds linear floats (lit bake)."""
    import numpy as np
    w, h = image.size
    px = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(px)
    px = px.reshape(-1, 4)
    rgb = _srgb_encode(px[:, :3]) if linear else px[:, :3]
    # contrast on brightness only, colours keep their hue (per-channel contrast turns orange yellow)
    y = rgb[:, 0] * 0.2126 + rgb[:, 1] * 0.7152 + rgb[:, 2] * 0.0722
    y2 = np.clip((y - 0.5) * k + 0.5, 0.0, 1.0)
    rgb = rgb * (y2 / np.maximum(y, 1e-6))[:, None]
    rgb = rgb / np.maximum(rgb.max(axis=1, keepdims=True), 1.0)
    px[:, :3] = _srgb_decode(rgb) if linear else rgb
    image.pixels.foreach_set(px.ravel())
    image.update()


def _apply_to_mesh(ob, image, alpha_img, s, mode, uv_name):
    """Material on the light mesh showing the baked image (emissive + alpha for the lit bake)."""
    name = "LightBake_Lit" if mode == 'LIT' else "LightBake_Glass"
    old = bpy.data.materials.get(name)
    if old is not None:
        bpy.data.materials.remove(old)
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nt = mat.node_tree
    for n in list(nt.nodes):
        nt.nodes.remove(n)
    out = nt.nodes.new('ShaderNodeOutputMaterial')
    pr = nt.nodes.new('ShaderNodeBsdfPrincipled')
    uvn = nt.nodes.new('ShaderNodeUVMap')
    uvn.uv_map = uv_name
    tex = nt.nodes.new('ShaderNodeTexImage')
    tex.image = image
    tex.interpolation = 'Linear'
    out.location = (600, 0)
    pr.location = (300, 0)
    tex.location = (0, 0)
    uvn.location = (-250, 0)
    nt.links.new(uvn.outputs["UV"], tex.inputs["Vector"])
    nt.links.new(tex.outputs["Color"], pr.inputs["Base Color"])
    if alpha_img is not None:                       # the generated alpha map drives the opacity
        atex = nt.nodes.new('ShaderNodeTexImage')
        atex.image = alpha_img
        atex.interpolation = 'Linear'
        atex.location = (0, -300)
        nt.links.new(uvn.outputs["UV"], atex.inputs["Vector"])
        nt.links.new(atex.outputs["Color"], pr.inputs["Alpha"])
    else:
        nt.links.new(tex.outputs["Alpha"], pr.inputs["Alpha"])
    if mode == 'LIT' and s.emit_strength > 0:
        nt.links.new(tex.outputs["Color"], pr.inputs["Emission Color"])
        pr.inputs["Emission Strength"].default_value = s.emit_strength
    nt.links.new(pr.outputs[0], out.inputs["Surface"])
    for attr, val in (("surface_render_method", 'BLENDED'), ("blend_method", 'BLEND')):
        try:
            setattr(mat, attr, val)
        except Exception:
            pass
    if ob.material_slots:
        for sl in ob.material_slots:
            sl.material = mat
    else:
        ob.data.materials.append(mat)
    return mat


def _expose(image, auto, ev):
    """Scale the (linear float) lit bake. Returns a short message about what happened."""
    import numpy as np
    w, h = image.size
    px = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(px)
    px = px.reshape(-1, 4)
    lum = px[:, :3].max(axis=1)          # brightest channel, so a saturated orange/red light
    lit = lum > 1e-4                      # is not pushed far past white on its strong channel
    msg = ""
    gain = 1.0
    if not lit.any():
        return " - nothing was lit: raise Extrusion / light power, or check the lights face the housing"
    if auto:
        p = float(np.percentile(lum[lit], 98))
        if p > 0:
            gain = min(0.8 / p, 10000.0)
    gain *= 2.0 ** ev
    if gain != 1.0:
        rgb = np.maximum(px[:, :3] * gain, 0.0)
        mx = rgb.max(axis=1, keepdims=True)
        # hue-preserving limit: scale all channels together instead of clipping each one,
        # otherwise a bright orange/red light clips red first and turns yellow-green
        px[:, :3] = rgb / np.maximum(mx, 1.0)
        image.pixels.foreach_set(px.ravel())
        image.update()
    msg = " (lit %.0f%% of the image, brightness x%.1f)" % (100.0 * lit.mean(), gain)
    return msg


def _save(image, path):
    image.filepath_raw = bpy.path.abspath(path)
    image.file_format = 'PNG'
    image.save()


def _make_bulbs(scene, lights, s):
    """Temporary emissive glass bulbs standing in for the point lights. Returns (objects, undo)."""
    import math
    objs, meshes, mats = [], [], []
    r = s.bulb_radius
    for L in lights:
        if L.type != 'LIGHT':
            continue
        ld = L.data
        power = ld.energy
        radiance = power / (4.0 * math.pi ** 3 * r * r) * s.bulb_strength
        m = bpy.data.materials.new("_LB_bulb")
        m.use_nodes = True
        nt = m.node_tree
        for n in list(nt.nodes):
            nt.nodes.remove(n)
        em = nt.nodes.new('ShaderNodeEmission')
        em.inputs["Color"].default_value = (ld.color[0] * s.bulb_tint[0], ld.color[1] * s.bulb_tint[1],
                                            ld.color[2] * s.bulb_tint[2], 1.0)
        em.inputs["Strength"].default_value = radiance
        out = nt.nodes.new('ShaderNodeOutputMaterial')
        nt.links.new(em.outputs[0], out.inputs["Surface"])
        me = bpy.data.meshes.new("_LB_bulb")
        import bmesh
        bm = bmesh.new()
        bmesh.ops.create_uvsphere(bm, u_segments=32, v_segments=16, radius=r)
        bm.to_mesh(me)
        bm.free()
        me.materials.append(m)
        o = bpy.data.objects.new("_LB_bulb", me)
        scene.collection.objects.link(o)
        o.matrix_world = L.matrix_world.copy()
        o.visible_shadow = False
        objs.append(o); meshes.append(me); mats.append(m)

    def undo():
        for o in objs:
            bpy.data.objects.remove(o)
        for me in meshes:
            bpy.data.meshes.remove(me)
        for m in mats:
            bpy.data.materials.remove(m)
    return objs, undo


class _State:
    """Remembers what the bake touches and puts it back."""

    def __init__(self):
        self.undo = []

    def set(self, obj, attr, value):
        try:
            old = getattr(obj, attr)
            self.undo.append((obj, attr, old))
            setattr(obj, attr, value)
        except Exception:
            pass

    def restore(self):
        for obj, attr, old in reversed(self.undo):
            try:
                setattr(obj, attr, old)
            except Exception:
                pass
        self.undo = []


# ----------------------------------------------------------------------------
# Operators
# ----------------------------------------------------------------------------

class LIGHTBAKE_OT_add(bpy.types.Operator):
    bl_idname = "lightbake.add"
    bl_label = "Add Selected"
    bl_options = {'REGISTER', 'UNDO'}

    kind: EnumProperty(items=[('SOURCES', "", ""), ('LIGHTS', "", ""), ('TARGET', "", "")])

    def execute(self, context):
        s = context.scene.lightbake
        if self.kind == 'TARGET':
            ob = context.active_object
            if ob is None or ob.type != 'MESH':
                self.report({'ERROR'}, "Make the light mesh the active object")
                return {'CANCELLED'}
            s.target = ob
            return {'FINISHED'}
        if self.kind == 'SOURCES':
            n = _add_selected(s.sources, [o for o in context.selected_objects if o != s.target], {'MESH'})
        else:
            n = _add_selected(s.lights, context.selected_objects, {'LIGHT'})
        self.report({'INFO'}, "Added %d" % n)
        return {'FINISHED'}


class LIGHTBAKE_OT_remove(bpy.types.Operator):
    bl_idname = "lightbake.remove"
    bl_label = "Remove"
    bl_options = {'REGISTER', 'UNDO'}

    kind: EnumProperty(items=[('SOURCES', "", ""), ('LIGHTS', "", "")])
    index: IntProperty()

    def execute(self, context):
        s = context.scene.lightbake
        coll = s.sources if self.kind == 'SOURCES' else s.lights
        if 0 <= self.index < len(coll):
            coll.remove(self.index)
        return {'FINISHED'}


class LIGHTBAKE_OT_zone_add(bpy.types.Operator):
    bl_idname = "lightbake.zone_add"
    bl_label = "Add Part"
    bl_description = "Add a housing part (brake light, indicator, headlight ...) with its own colour"
    bl_options = {'REGISTER', 'UNDO'}

    kind: EnumProperty(items=ZONE_ITEMS, default='BRAKE')

    def execute(self, context):
        s = context.scene.lightbake
        s.zone_counter += 1
        z = s.zones.add()
        z.attr = "lb_zone_%d" % s.zone_counter
        z.kind = self.kind
        z.color = ZONE_PRESETS[self.kind][1]
        return {'FINISHED'}


class LIGHTBAKE_OT_zone_remove(bpy.types.Operator):
    bl_idname = "lightbake.zone_remove"
    bl_label = "Remove Part"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    def execute(self, context):
        s = context.scene.lightbake
        if 0 <= self.index < len(s.zones):
            attr = s.zones[self.index].attr
            for o in bpy.data.objects:
                if o.type == 'MESH' and o.data.attributes.get(attr) is not None:
                    o.data.attributes.remove(o.data.attributes[attr])
            s.zones.remove(self.index)
        return {'FINISHED'}


class LIGHTBAKE_OT_zone_apply(bpy.types.Operator):
    bl_idname = "lightbake.zone_apply"
    bl_label = "Apply Selection"
    bl_description = "Edit Mode: store the selected faces (of every mesh in Edit Mode) as this part"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    def execute(self, context):
        import bmesh
        s = context.scene.lightbake
        if not (0 <= self.index < len(s.zones)):
            return {'CANCELLED'}
        objs = [o for o in context.objects_in_mode_unique_data if o.type == 'MESH']
        if not objs:
            self.report({'ERROR'}, "Select faces in Edit Mode first")
            return {'CANCELLED'}
        attr = s.zones[self.index].attr
        total = 0
        for o in objs:
            bm = bmesh.from_edit_mesh(o.data)
            lay = bm.faces.layers.int.get(attr)
            if lay is None:
                if not any(f.select for f in bm.faces):
                    continue
                lay = bm.faces.layers.int.new(attr)   # adding a layer invalidates old face refs
            sel = [f for f in bm.faces if f.select]
            for f in bm.faces:
                f[lay] = 0
            for f in sel:
                f[lay] = 1
            total += len(sel)
            bmesh.update_edit_mesh(o.data)
        self.report({'INFO'}, "Stored %d face(s)" % total)
        return {'FINISHED'}


class LIGHTBAKE_OT_zone_select(bpy.types.Operator):
    bl_idname = "lightbake.zone_select"
    bl_label = "Get Selection"
    bl_description = "Edit Mode: select the faces stored for this part"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    def execute(self, context):
        import bmesh
        s = context.scene.lightbake
        if not (0 <= self.index < len(s.zones)):
            return {'CANCELLED'}
        attr = s.zones[self.index].attr
        for o in [o for o in context.objects_in_mode_unique_data if o.type == 'MESH']:
            bm = bmesh.from_edit_mesh(o.data)
            lay = bm.faces.layers.int.get(attr)
            if lay is None:
                continue
            for f in bm.faces:
                f.select_set(bool(f[lay]))
            bm.select_flush_mode()
            bmesh.update_edit_mesh(o.data)
        return {'FINISHED'}


class LIGHTBAKE_OT_bake(bpy.types.Operator):
    bl_idname = "lightbake.bake"
    bl_label = "Bake"
    bl_description = "Bake the housing onto the light mesh with Cycles (Selected to Active)"
    bl_options = {'REGISTER'}

    mode: EnumProperty(items=[('LIT', "Lit", ""), ('GLASS', "Glass", "")], default='LIT')

    def execute(self, context):
        scene = context.scene
        s = scene.lightbake
        ob = s.target
        sources = [o for o in _refs(s.sources) if o != ob]
        lights = _refs(s.lights)
        if ob is None or ob.type != 'MESH':
            self.report({'ERROR'}, "Pick the light mesh first")
            return {'CANCELLED'}
        if not sources:
            self.report({'ERROR'}, "Add the housing objects first")
            return {'CANCELLED'}
        if self.mode == 'LIT' and not lights:
            self.report({'ERROR'}, "Add at least one point light for the lit bake")
            return {'CANCELLED'}
        me = ob.data
        if len(me.uv_layers) < s.uv_slot:
            self.report({'ERROR'}, "%s has no UV map %d" % (ob.name, s.uv_slot))
            return {'CANCELLED'}
        vl = context.view_layer
        for o in sources + [ob]:
            if o.name not in vl.objects or not o.visible_get():
                self.report({'ERROR'}, "%s is hidden. Show it for the bake" % o.name)
                return {'CANCELLED'}
        if context.object is not None and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        path = s.path_lit if self.mode == 'LIT' else s.path_glass
        size = int(s.resolution)
        name = "LightBake_Lit" if self.mode == 'LIT' else "LightBake_Glass"
        old = bpy.data.images.get(name)
        if old is not None:
            bpy.data.images.remove(old)
        image = bpy.data.images.new(name, size, size, alpha=True, float_buffer=(self.mode == 'LIT'))
        image.generated_color = (0.0, 0.0, 0.0, 0.0)
        image.colorspace_settings.name = 'sRGB'
        mat = _temp_material(image)

        st = _State()
        prev_sel = list(context.selected_objects)
        prev_active = context.view_layer.objects.active
        slot_mats = [sl.material for sl in ob.material_slots]
        added_slot = False
        undo_housing = None
        undo_bulbs = None
        try:
            st.set(scene.render, "engine", 'CYCLES')
            st.set(scene.cycles, "samples", s.samples)
            # lights: only the chosen ones, and only for the lit bake
            keep = set(lights) if self.mode == 'LIT' else set()
            if self.mode == 'LIT' and s.use_bulb:
                _bulb_objs, undo_bulbs = _make_bulbs(scene, lights, s)
                keep = set()                      # the bulbs replace the bare point lights
            for o in scene.objects:
                if o.type == 'LIGHT':
                    st.set(o, "hide_render", o not in keep)
            if s.ignore_world or self.mode == 'GLASS':
                st.set(scene, "world", None)
            # the light mesh must not block light or show up in the housing's shading
            for attr in ("visible_shadow", "visible_diffuse", "visible_glossy",
                         "visible_transmission", "visible_volume_scatter"):
                st.set(ob, attr, False)
            if (s.use_zones and len(s.zones)) or s.roughness_mode == 'FLAT' or s.roughness_scale != 1.0:
                undo_housing = _override_housing(sources, s)
            # a Mirror on the light mesh bakes onto overlapping UVs (black image)
            for m in ob.modifiers:
                if m.type == 'MIRROR':
                    st.set(m, "show_viewport", False)
                    st.set(m, "show_render", False)
            st.set(me.uv_layers, "active_index", s.uv_slot - 1)
            # every face of the light mesh bakes into the temp material's image
            if ob.material_slots:
                for sl in ob.material_slots:
                    sl.material = mat
            else:
                me.materials.append(mat)
                added_slot = True

            for o in context.selected_objects:
                o.select_set(False)
            for o in sources:
                o.select_set(True)
            ob.select_set(True)
            vl.objects.active = ob

            kw = dict(target='IMAGE_TEXTURES', use_selected_to_active=True, use_clear=True,
                      margin=s.margin, cage_extrusion=s.extrusion, max_ray_distance=s.max_ray)
            if self.mode == 'LIT':
                if s.reflections:
                    result = bpy.ops.object.bake(type='COMBINED', **kw)
                else:                                    # no glossy / transmission = no shine at all
                    result = bpy.ops.object.bake(
                        type='COMBINED', pass_filter={'DIRECT', 'INDIRECT', 'COLOR', 'EMIT', 'DIFFUSE'}, **kw)
            else:
                result = bpy.ops.object.bake(type='DIFFUSE', pass_filter={'COLOR'}, **kw)
            if 'FINISHED' not in result:
                self.report({'ERROR'}, "Bake did not finish")
                return {'CANCELLED'}
            # where the rays really hit the housing: a quick margin-less pass, alpha = hit
            mask_img = bpy.data.images.new("_LB_mask", size, size, alpha=True)
            mask_img.generated_color = (0.0, 0.0, 0.0, 0.0)
            try:
                mat.node_tree.nodes.active.image = mask_img
                st.set(scene.cycles, "samples", 1)
                kw_mask = dict(kw)
                kw_mask["margin"] = 0
                bpy.ops.object.bake(type='DIFFUSE', pass_filter={'COLOR'}, **kw_mask)
                import numpy as np
                mpx = np.empty(size * size * 4, dtype=np.float32)
                mask_img.pixels.foreach_get(mpx)
                cover = mpx.reshape(size, size, 4)[..., 3] > 0.5
            finally:
                bpy.data.images.remove(mask_img)
            info = ""
            if self.mode == 'LIT':
                if s.denoise and not _denoise(image):
                    info += " - denoiser unavailable"
                info += _expose(image, s.auto_expose, s.exposure)
            if s.contrast != 1.0:
                _contrast(image, s.contrast, linear=(self.mode == 'LIT'))
            fade_px = int(round(s.fade / 100.0 * size)) if s.fade > 0 else 0
            alpha_arr = _finish_alpha(image, cover, s.lens_alpha, fade_px, s,
                                      linear=(self.mode == 'LIT'))
            if s.base_image is not None:
                alpha_arr = _blend_base(image, s.base_image, s.base_mode, s.base_fac,
                                        linear=(self.mode == 'LIT'))
            if path:
                _save(image, path)
            alpha_img = None
            if (s.save_alpha_map and path) or s.apply_material:
                alpha_img = _make_alpha_image(
                    alpha_arr, "LightBake_Lit_Alpha" if self.mode == 'LIT' else "LightBake_Glass_Alpha",
                    path if s.save_alpha_map else "")
        except RuntimeError as e:
            self.report({'ERROR'}, str(e).strip().splitlines()[-1][:200])
            return {'CANCELLED'}
        finally:
            if undo_bulbs is not None:
                undo_bulbs()
            if undo_housing is not None:
                undo_housing()
            for sl, m in zip(ob.material_slots, slot_mats):
                sl.material = m
            if added_slot:
                me.materials.pop(index=len(me.materials) - 1)
            st.restore()
            bpy.data.materials.remove(mat)
            for o in context.selected_objects:
                o.select_set(False)
            for o in prev_sel:
                if o.name in vl.objects:
                    o.select_set(True)
            vl.objects.active = prev_active
        if s.apply_material:
            try:
                if not path:
                    image.pack()
                _apply_to_mesh(ob, image, alpha_img, s, self.mode, me.uv_layers[s.uv_slot - 1].name)
                info += " - material applied to %s" % ob.name
            except Exception as e:
                info += " - could not apply material: %s" % e
        self.report({'INFO'}, "Baked %s: %s%s" % (self.mode.lower(),
                    bpy.path.abspath(path) if path else name, info))
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------------

class LIGHTBAKE_PT_main(bpy.types.Panel):
    bl_label = "Light Baker"
    bl_idname = "LIGHTBAKE_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_vehicle"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        s = context.scene.lightbake
        layout = self.layout

        box = layout.box()
        box.label(text="Light mesh (target)")
        row = box.row(align=True)
        row.prop(s, "target", text="")
        op = row.operator("lightbake.add", text="", icon='EYEDROPPER')
        op.kind = 'TARGET'

        box = layout.box()
        box.label(text="Housing (source)")
        for i, r in enumerate(s.sources):
            row = box.row(align=True)
            row.prop(r, "obj", text="")
            op = row.operator("lightbake.remove", text="", icon='X')
            op.kind = 'SOURCES'
            op.index = i
        box.operator("lightbake.add", text="Add Selected Meshes", icon='ADD').kind = 'SOURCES'

        box = layout.box()
        box.prop(s, "use_zones")
        if s.use_zones:
            box.label(text="Housing parts (Edit Mode: select faces):")
            for i, z in enumerate(s.zones):
                row = box.row(align=True)
                row.prop(z, "kind", text="")
                row.prop(z, "color", text="")
                op = row.operator("lightbake.zone_apply", text="", icon='CHECKMARK')
                op.index = i
                op = row.operator("lightbake.zone_select", text="", icon='RESTRICT_SELECT_OFF')
                op.index = i
                op = row.operator("lightbake.zone_remove", text="", icon='X')
                op.index = i
            row = box.row(align=True)
            for k, v in ZONE_PRESETS.items():
                row.operator("lightbake.zone_add", text=v[0].split()[0]).kind = k
            box.prop(s, "other_color")

        box = layout.box()
        box.label(text="Point lights (lit bake)")
        for i, r in enumerate(s.lights):
            row = box.row(align=True)
            row.prop(r, "obj", text="")
            op = row.operator("lightbake.remove", text="", icon='X')
            op.kind = 'LIGHTS'
            op.index = i
        box.operator("lightbake.add", text="Add Selected Lights", icon='LIGHT_POINT').kind = 'LIGHTS'
        box.prop(s, "use_bulb")
        if s.use_bulb:
            col = box.column(align=True)
            col.prop(s, "bulb_radius")
            col.prop(s, "bulb_strength")
            col.prop(s, "bulb_tint")
        box.prop(s, "ignore_world")
        box.prop(s, "reflections")
        box.row(align=True).prop(s, "roughness_mode", expand=True)
        if s.roughness_mode == 'FLAT':
            box.prop(s, "roughness")
        else:
            box.prop(s, "roughness_scale")

        box = layout.box()
        box.prop(s, "uv_slot")
        box.prop(s, "resolution")
        box.prop(s, "samples")
        box.prop(s, "denoise")
        box.prop(s, "auto_expose")
        box.prop(s, "exposure")
        box.prop(s, "contrast")
        box.prop(s, "lens_alpha")
        box.prop(s, "base_image")
        if s.base_image is not None:
            box.prop(s, "base_mode")
            box.prop(s, "base_fac")
        box.prop(s, "fade")
        if s.fade > 0:
            box.prop(s, "fade_black")
        box.prop(s, "save_alpha_map")
        box.prop(s, "alpha_from_light")
        if s.alpha_from_light:
            box.prop(s, "light_alpha_min")
            box.prop(s, "light_alpha_curve")
        box.prop(s, "margin")
        box.prop(s, "extrusion")
        box.prop(s, "max_ray")

        box = layout.box()
        box.prop(s, "apply_material")
        if s.apply_material:
            box.prop(s, "emit_strength")
        box = layout.box()
        box.prop(s, "path_lit", text="Lit")
        box.operator("lightbake.bake", text="Bake Lit", icon='LIGHT').mode = 'LIT'
        box.prop(s, "path_glass", text="Glass")
        box.operator("lightbake.bake", text="Bake Glass (no light)", icon='MATERIAL').mode = 'GLASS'


classes = (
    LB_ObjRef,
    LB_Zone,
    LightBakeSettings,
    LIGHTBAKE_OT_add,
    LIGHTBAKE_OT_remove,
    LIGHTBAKE_OT_zone_add,
    LIGHTBAKE_OT_zone_remove,
    LIGHTBAKE_OT_zone_apply,
    LIGHTBAKE_OT_zone_select,
    LIGHTBAKE_OT_bake,
    LIGHTBAKE_PT_main,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.lightbake = PointerProperty(type=LightBakeSettings)


def unregister():
    del bpy.types.Scene.lightbake
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
