bl_info = {
    "name": "T3D Tools",
    "author": "Tidemo and Claude",
    "version": (1, 2, 0),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Sidebar (N) > T3D Tools",
    "description": "Modeling, vehicle and mapping tools in one addon: Max Splines, Edit Constraints, Even Bevel, Object Utilities, Rivet Generator, Extrude (No Border Walls), Normal Transfer, Panel Gap Generator, "
                   "UV Transfer, Livery Template, Channel Paint, Wheel Instancer, Light Baker, UV Pin, Floor Trim Generator",
    "category": "3D View",
}

if "bpy" in locals():
    import importlib
    for _m in ("ui", "object_utils", "max_splines", "edit_constraints", "even_bevel", "uv_transfer", "normal_transfer", "panel_gap", "livery_template", "channel_paint",
               "wheel_instancer", "light_baker", "uv_pin", "floor_trim", "rivet_gen", "extrude_clean"):
        if _m in locals():
            importlib.reload(locals()[_m])

import bpy

from . import ui
# Modeling Tools
from . import max_splines, edit_constraints, even_bevel, object_utils, rivet_gen, extrude_clean
# Vehicle Tools
from . import uv_transfer, normal_transfer, panel_gap, livery_template, channel_paint, wheel_instancer, light_baker, uv_pin
# Mapping Tools
from . import floor_trim

# ui must come first: the category panels are the parents of every tool panel.
# Order here is also the order the sections appear in the sidebar.
_modules = (
    ui,
    max_splines, edit_constraints, even_bevel, object_utils, rivet_gen, extrude_clean,
    uv_transfer, normal_transfer, panel_gap, livery_template, channel_paint, wheel_instancer, light_baker, uv_pin,
    floor_trim,
)


def register():
    done = []
    try:
        for m in _modules:
            m.register()
            done.append(m)
    except Exception:
        for m in reversed(done):
            try:
                m.unregister()
            except Exception:
                pass
        raise


def unregister():
    for m in reversed(_modules):
        try:
            m.unregister()
        except Exception as e:
            print("T3D Tools: error unregistering %s: %s" % (m.__name__, e))
