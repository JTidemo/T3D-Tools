"""Livery Template: render the UV layout to a PNG, colored by material or by side.

Color by Material: every face using material A is filled with one color and every face using
material B with another. Color by Side: faces right of the object's origin (+X) get one color,
faces left of it another (optionally limited to the chosen materials). UV edges are drawn on
top. The UVs are read from the *evaluated* mesh, so channels written by modifiers (UV Transfer)
are included.

Preview on Car temporarily swaps the chosen materials for an unlit material that shows the
template on UV2 so you can check it on the model. Restore Materials puts the originals back.
"""

import os
import re

import bmesh
import bpy
import numpy as np
from mathutils import Vector, kdtree
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty, FloatVectorProperty,
                       IntProperty, PointerProperty, StringProperty)

UV_ITEMS = (
    ("0", "UV1", "First UV map"),
    ("1", "UV2", "Second UV map"),
    ("2", "UV3", "Third UV map"),
    ("3", "UV4", "Fourth UV map"),
)

L0_RE = re.compile(r"_L0(\.\d+)?$")     # "body_L0", "body_L0.001"

RES_ITEMS = (
    ("512", "512", ""),
    ("1024", "1024", ""),
    ("2048", "2048", ""),
    ("4096", "4096", ""),
    ("8192", "8192", ""),
)

BG_ITEMS = (
    ("TRANSPARENT", "Transparent", "Empty areas are fully transparent"),
    ("WHITE", "White", ""),
    ("BLACK", "Black", ""),
)


# ----------------------------------------------------------------------------
# Pure numpy core (no bpy) - testable outside Blender
# ----------------------------------------------------------------------------

def fill_triangles(img, tri_uv, rgba, size):
    """Alpha-blend filled triangles into img (H, W, 4 float32, straight alpha).

    tri_uv: (N, 3, 2) UV coordinates, 0..1.
    """
    w = h = size
    px = tri_uv[:, :, 0] * w
    py = tri_uv[:, :, 1] * h
    col = np.asarray(rgba[:3], dtype=np.float32)
    alpha = float(rgba[3])

    for k in range(len(tri_uv)):
        x0, x1, x2 = px[k]
        y0, y1, y2 = py[k]
        den = (y1 - y2) * (x0 - x2) + (x2 - x1) * (y0 - y2)
        if abs(den) < 1e-12:
            continue
        xmin = max(int(np.floor(min(x0, x1, x2))), 0)
        xmax = min(int(np.ceil(max(x0, x1, x2))), w - 1)
        ymin = max(int(np.floor(min(y0, y1, y2))), 0)
        ymax = min(int(np.ceil(max(y0, y1, y2))), h - 1)
        if xmin > xmax or ymin > ymax:
            continue
        xs = np.arange(xmin, xmax + 1, dtype=np.float32) + 0.5
        ys = np.arange(ymin, ymax + 1, dtype=np.float32) + 0.5
        gx, gy = np.meshgrid(xs, ys)
        a = ((y1 - y2) * (gx - x2) + (x2 - x1) * (gy - y2)) / den
        b = ((y2 - y0) * (gx - x2) + (x0 - x2) * (gy - y2)) / den
        c = 1.0 - a - b
        inside = (a >= -1e-6) & (b >= -1e-6) & (c >= -1e-6)
        if not inside.any():
            # sliver thinner than a pixel: still mark the pixel under its centroid
            cx = int(np.clip((x0 + x1 + x2) / 3.0, 0, w - 1))
            cy = int(np.clip((y0 + y1 + y2) / 3.0, 0, h - 1))
            _blend(img, np.array([cy]), np.array([cx]), col, alpha)
            continue
        iy, ix = np.nonzero(inside)
        _blend(img, iy + ymin, ix + xmin, col, alpha)


def _blend(img, iy, ix, col, alpha):
    dst = img[iy, ix]                      # (n, 4)
    da = dst[:, 3:4]
    out_a = alpha + da * (1.0 - alpha)
    safe = np.where(out_a > 0, out_a, 1.0)
    out_rgb = (col * alpha + dst[:, :3] * da * (1.0 - alpha)) / safe
    img[iy, ix, :3] = out_rgb
    img[iy, ix, 3] = out_a[:, 0]


def draw_edges(img, edges_uv, rgba, size, width=1):
    """Draw 1px (or `width` px) lines. edges_uv: (M, 2, 2) UV coordinates."""
    if len(edges_uv) == 0:
        return
    w = h = size
    p0 = edges_uv[:, 0, :] * size
    p1 = edges_uv[:, 1, :] * size
    steps = np.maximum(np.abs(p1 - p0).max(axis=1), 1.0)
    counts = np.ceil(steps).astype(np.int64) + 1
    # process in chunks so a huge mesh cannot blow up memory
    total = int(counts.sum())
    chunk_edges = max(1, int(len(counts) * min(1.0, 4_000_000 / max(total, 1))))
    col = np.asarray(rgba, dtype=np.float32)
    for s in range(0, len(counts), chunk_edges):
        c = counts[s:s + chunk_edges]
        a = p0[s:s + chunk_edges]
        d = p1[s:s + chunk_edges] - a
        idx = np.repeat(np.arange(len(c)), c)
        starts = np.cumsum(c) - c
        t = (np.arange(len(idx)) - starts[idx]) / np.maximum(c[idx] - 1, 1)
        x = np.floor(a[idx, 0] + d[idx, 0] * t).astype(np.int64)
        y = np.floor(a[idx, 1] + d[idx, 1] * t).astype(np.int64)
        for oy in range(width):
            for ox in range(width):
                xx, yy = x + ox, y + oy
                m = (xx >= 0) & (xx < w) & (yy >= 0) & (yy < h)
                img[yy[m], xx[m]] = col


def make_image(size, bg, groups, edges, line_rgba, draw_fill, draw_wire, line_width):
    """groups: list of (tri_uv (N,3,2), rgba). edges: (M,2,2) or None."""
    if bg == "WHITE":
        img = np.ones((size, size, 4), dtype=np.float32)
    elif bg == "BLACK":
        img = np.zeros((size, size, 4), dtype=np.float32)
        img[..., 3] = 1.0
    else:
        img = np.zeros((size, size, 4), dtype=np.float32)
    if draw_fill:
        for tri_uv, rgba in groups:
            if len(tri_uv):
                fill_triangles(img, tri_uv, rgba, size)
    if draw_wire and edges is not None and len(edges):
        draw_edges(img, edges, line_rgba, size, line_width)
    return img


# ----------------------------------------------------------------------------
# Blender side
# ----------------------------------------------------------------------------

PREVIEW_IMAGE = "LiveryTemplate_Preview"
PREVIEW_MAT = "LiveryTemplate_Preview"
LATEST_IMAGE = "LiveryTemplate_Latest"      # copy of the last generated template (kept in the .blend)

MODE_ITEMS = (
    ("MATERIAL", "Material", "Color A / B by material"),
    ("SIDE", "Side", "Right of the origin / left of the origin"),
)


def _read_uvs(layer, n_loops):
    out = np.empty(n_loops * 2, dtype=np.float32)
    try:
        layer.uv.foreach_get("vector", out)          # 3.5+ attribute-backed access
    except Exception:
        layer.data.foreach_get("uv", out)            # older API
    return out.reshape(-1, 2)


def _collect(ob, depsgraph, uv_index, mat_a, mat_b, side=None, check=None):
    """Triangles per group and the polygon edges, from the evaluated mesh.

    side None: group 0 = material A, group 1 = material B.
    side False/True: faces whose material is A or B (any, if none given) are split by the
    X of their center in object space: group 0 = right (+X), group 1 = left; True flips that."""
    ev = ob.evaluated_get(depsgraph)
    me = ev.to_mesh()
    try:
        if uv_index >= len(me.uv_layers):
            return None
        limit = [m for m in (mat_a, mat_b) if m is not None]
        # while the preview is on, the slots hold the preview material: use the originals
        orig = {b.index: b.material for b in ob.lt_backup}
        slots = [orig.get(i, s.material) for i, s in enumerate(ob.material_slots)]
        if side is None:
            slot_group = [0 if (m is not None and m == mat_a) else
                          1 if (m is not None and m == mat_b) else -1 for m in slots]
        else:
            slot_group = [0 if (not limit or (m is not None and m in limit)) else -1
                          for m in slots]
            if not slots:
                slot_group = [0 if not limit else -1]
        empty = {"tris": [np.zeros((0, 3, 2), np.float32)] * 2,
                 "edges": np.zeros((0, 2, 2), np.float32), "faces": 0, "flag": None}
        if not slot_group or all(g < 0 for g in slot_group):
            return empty
        slot_group = np.array(slot_group + [-1], dtype=np.int64)

        n_poly, n_loop = len(me.polygons), len(me.loops)
        if n_poly == 0:
            return None
        uv = _read_uvs(me.uv_layers[uv_index], n_loop)

        mat_idx = np.empty(n_poly, dtype=np.int32)
        me.polygons.foreach_get("material_index", mat_idx)
        n_slots = max(len(slots), 1)
        mat_idx = np.clip(mat_idx, 0, n_slots - 1)
        poly_group = slot_group[mat_idx]
        if side is not None:
            cen = np.empty(n_poly * 3, dtype=np.float32)
            me.polygons.foreach_get("center", cen)
            right = cen.reshape(-1, 3)[:, 0] >= 0.0
            if side:
                right = ~right
            poly_group = np.where(poly_group >= 0, np.where(right, 0, 1), -1)

        try:
            me.calc_loop_triangles()
        except Exception:
            pass
        n_tri = len(me.loop_triangles)
        tri_loops = np.empty(n_tri * 3, dtype=np.int32)
        tri_poly = np.empty(n_tri, dtype=np.int32)
        me.loop_triangles.foreach_get("loops", tri_loops)
        me.loop_triangles.foreach_get("polygon_index", tri_poly)
        tri_loops = tri_loops.reshape(-1, 3)
        tri_group = poly_group[tri_poly]
        tris = []
        for g in (0, 1):
            sel = tri_group == g
            tris.append(uv[tri_loops[sel]].astype(np.float32))      # (n, 3, 2)

        loop_start = np.empty(n_poly, dtype=np.int32)
        loop_total = np.empty(n_poly, dtype=np.int32)
        me.polygons.foreach_get("loop_start", loop_start)
        me.polygons.foreach_get("loop_total", loop_total)
        loop_poly = np.repeat(np.arange(n_poly), loop_total)
        sel_loops = np.nonzero(poly_group[loop_poly] >= 0)[0]
        nxt = sel_loops + 1
        last = (sel_loops - loop_start[loop_poly[sel_loops]]) == (loop_total[loop_poly[sel_loops]] - 1)
        nxt[last] = loop_start[loop_poly[sel_loops]][last]
        edges = np.stack([uv[sel_loops], uv[nxt]], axis=1).astype(np.float32)

        flag = None
        if check is not None:
            edge_thr, ratio = check
            cen = np.empty(n_poly * 3, dtype=np.float32)
            me.polygons.foreach_get("center", cen)
            cen = cen.reshape(-1, 3)
            area3 = np.empty(n_poly, dtype=np.float32)
            me.polygons.foreach_get("area", area3)
            ta, tb, tc = uv[tri_loops[:, 0]], uv[tri_loops[:, 1]], uv[tri_loops[:, 2]]
            tri_area = 0.5 * np.abs((tb[:, 0] - ta[:, 0]) * (tc[:, 1] - ta[:, 1])
                                    - (tb[:, 1] - ta[:, 1]) * (tc[:, 0] - ta[:, 0]))
            uv_area = np.zeros(n_poly, dtype=np.float64)
            np.add.at(uv_area, tri_poly, tri_area)
            sel_poly = poly_group >= 0
            valid = sel_poly & (area3 > 1e-9) & (uv_area > 1e-9)
            bad = np.zeros(n_poly, dtype=bool)
            if valid.any():
                dens = np.zeros(n_poly, dtype=np.float64)
                dens[valid] = uv_area[valid] / area3[valid]
                med = float(np.median(dens[valid]))
                if med > 0:
                    bad |= valid & (dens > ratio * med)       # far more texture than surface
            elen = np.linalg.norm(uv[sel_loops] - uv[nxt], axis=1)
            longest = np.zeros(n_poly, dtype=np.float64)
            np.maximum.at(longest, loop_poly[sel_loops], elen)
            bad |= sel_poly & (longest > edge_thr)            # an edge spanning the layout
            flag = {"count": int(bad.sum()), "centers": cen[bad].copy(),
                    "tris": uv[tri_loops[bad[tri_poly]]].astype(np.float32)}
        return {"tris": tris, "edges": edges, "faces": int((poly_group >= 0).sum()), "flag": flag}
    finally:
        ev.to_mesh_clear()


def _targets(context):
    """Selected meshes win; with nothing selected, every mesh whose name ends in _L0."""
    objs = [o for o in context.selected_objects if o.type == 'MESH']
    used = "selection"
    if not objs:
        objs = [o for o in context.scene.objects if o.type == 'MESH' and L0_RE.search(o.name)]
        used = "_L0 objects"
    return objs, used


import contextlib


@contextlib.contextmanager
def _eval_depsgraph(context, objs):
    """Depsgraph in which every object is evaluated, hidden or not.

    Hidden / excluded objects are not in the active view layer's depsgraph, so their
    modifiers (Mirror, UV Transfer ...) would not run. They are evaluated in a throw-away
    scene instead; the real view layer and its visibility settings are never touched."""
    tmp = bpy.data.scenes.new("_lt_tmp")
    linked = []
    try:
        for ob in objs:
            try:
                tmp.collection.objects.link(ob)
                linked.append(ob)
            except RuntimeError:
                pass
        vl = tmp.view_layers[0]
        vl.update()
        dg = vl.depsgraph
        dg.update()
        yield dg
    finally:
        for ob in linked:
            try:
                tmp.collection.objects.unlink(ob)
            except Exception:
                pass
        try:
            bpy.data.scenes.remove(tmp)
        except Exception:
            pass


def _gather(context, s, uv_index, objs):
    with _eval_depsgraph(context, objs) as dg:
        return _gather_inner(context, s, uv_index, objs, dg)


def _gather_inner(context, s, uv_index, objs, depsgraph):
    side = None if s.color_mode == 'MATERIAL' else bool(s.flip_sides)
    tris = [[], []]
    edges = []
    faces = 0
    missing_uv = []
    stretched = []
    flag_tris = []
    check = (s.stretch_edge, s.stretch_ratio) if s.check_stretch else None
    for ob in objs:
        data = _collect(ob, depsgraph, uv_index, s.material_a, s.material_b, side, check)
        if data is None:
            missing_uv.append(ob.name)
            continue
        if data["flag"] is not None and data["flag"]["count"]:
            stretched.append((ob.name, data["flag"]["count"]))
            flag_tris.append(data["flag"]["tris"])
        for g in (0, 1):
            if len(data["tris"][g]):
                tris[g].append(data["tris"][g])
        if len(data["edges"]):
            edges.append(data["edges"])
        faces += data["faces"]
    cat = lambda lst: (np.concatenate(lst) if lst else np.zeros((0, 3, 2), np.float32))
    if s.color_mode == 'MATERIAL':
        cols = (s.color_a, s.color_b)
    else:
        cols = (s.color_right, s.color_left)
    groups = [(cat(tris[0]), (*cols[0], s.fill_alpha)),
              (cat(tris[1]), (*cols[1], s.fill_alpha))]
    if flag_tris and s.highlight_stretch:
        groups.append((cat(flag_tris), (*s.stretch_color, 0.95)))
    return {"groups": groups, "edges": np.concatenate(edges) if edges else None,
            "faces": faces, "missing_uv": missing_uv, "stretched": stretched}


def _store_report(s, g, report):
    """Remember which objects have stretched UVs (the panel lists them) and warn."""
    s.stretch_report.clear()
    for name, n in sorted(g["stretched"], key=lambda x: -x[1]):
        it = s.stretch_report.add()
        it.name, it.count = name, n
    if g["stretched"]:
        top = ", ".join("%s (%d)" % (n, c) for n, c in sorted(g["stretched"], key=lambda x: -x[1])[:4])
        more = len(g["stretched"]) - 4
        report({'WARNING'}, "Stretched UVs on: %s%s. See the list in the panel"
               % (top, " and %d more" % more if more > 0 else ""))


def _save_png(img, path, size):
    name = "__livery_template_tmp__"
    old = bpy.data.images.get(name)
    if old is not None:
        bpy.data.images.remove(old)
    im = bpy.data.images.new(name, size, size, alpha=True)
    try:
        im.colorspace_settings.name = 'sRGB'
        im.alpha_mode = 'STRAIGHT'
        im.pixels.foreach_set(np.ascontiguousarray(img, dtype=np.float32).ravel())
        im.filepath_raw = path
        im.file_format = 'PNG'
        im.save()
    finally:
        bpy.data.images.remove(im)


class LT_MatRef(bpy.types.PropertyGroup):
    material: PointerProperty(name="Material", type=bpy.types.Material)


class LT_StretchItem(bpy.types.PropertyGroup):
    name: StringProperty()
    count: IntProperty()


class LT_Backup(bpy.types.PropertyGroup):
    """Original material of a slot while the preview is on (kept on the object)."""
    index: IntProperty()
    material: PointerProperty(type=bpy.types.Material)


class LiveryTemplateSettings(bpy.types.PropertyGroup):
    color_mode: EnumProperty(name="Color By", items=MODE_ITEMS, default="SIDE",
                             description="Color the template per material, or per side of the origin")
    flip_sides: BoolProperty(name="Flip Sides", default=False,
                             description="Swap right and left (right = +X of the object origin)")
    material_a: PointerProperty(name="Material A", type=bpy.types.Material,
                                description="First livery material")
    material_b: PointerProperty(name="Material B", type=bpy.types.Material,
                                description="Second livery material")
    uv_channel: EnumProperty(name="UV Channel", items=UV_ITEMS, default="1",
                             description="UV map to read (the evaluated mesh is used, so UVs "
                                         "written by UV Transfer modifiers are included)")
    resolution: EnumProperty(name="Resolution", items=RES_ITEMS, default="2048")
    background: EnumProperty(name="Background", items=BG_ITEMS, default="TRANSPARENT")
    filepath: StringProperty(name="Output", subtype='FILE_PATH', default="//livery_template.png",
                             description="PNG file to write (relative to the .blend with //)")
    draw_fill: BoolProperty(name="Fill", default=True)
    fill_alpha: FloatProperty(name="Fill Opacity", default=0.55, min=0.0, max=1.0,
                              subtype='FACTOR')
    draw_wire: BoolProperty(name="UV Edges", default=True)
    line_width: IntProperty(name="Line Width", default=1, min=1, max=4)
    color_a: FloatVectorProperty(name="Color A", subtype='COLOR', size=3, min=0.0, max=1.0,
                                 default=(0.90, 0.25, 0.20))
    color_b: FloatVectorProperty(name="Color B", subtype='COLOR', size=3, min=0.0, max=1.0,
                                 default=(0.20, 0.50, 0.95))
    color_right: FloatVectorProperty(name="Right", subtype='COLOR', size=3, min=0.0, max=1.0,
                                     default=(0.90, 0.12, 0.12),
                                     description="Faces on the +X side of the origin")
    color_left: FloatVectorProperty(name="Left", subtype='COLOR', size=3, min=0.0, max=1.0,
                                    default=(0.66, 0.66, 0.66),
                                    description="Faces on the -X side of the origin")
    line_color: FloatVectorProperty(name="Line Color", subtype='COLOR', size=3, min=0.0, max=1.0,
                                    default=(0.0, 0.0, 0.0))
    override_mats: CollectionProperty(type=LT_MatRef)
    merge_name: StringProperty(name="Name", default="Livery_Merged",
                               description="Name of the merged copy (an existing object with this "
                                           "name is replaced)")
    merge_uv1: BoolProperty(name="Livery UV -> UV1", default=True,
                            description="In the merged copy, make the UV channel chosen above "
                                        "(UV2 by default) the only UV map, so it becomes UV1. "
                                        "Turn off to keep every UV map")
    check_stretch: BoolProperty(
        name="Check Stretching", default=True,
        description="Warn about objects with stretched UVs (very long UV edges, or far more texture than surface)")
    stretch_edge: FloatProperty(
        name="Max UV Edge", default=0.5, min=0.05, max=1.5,
        description="A face is flagged when one of its edges is longer than this in UV space "
                    "(1.0 = the whole texture)")
    stretch_ratio: FloatProperty(
        name="Density Ratio", default=25.0, min=2.0, max=500.0,
        description="A face is flagged when its UV area per surface area is this many times the object's median")
    highlight_stretch: BoolProperty(
        name="Highlight in Template", default=True,
        description="Draw the flagged faces in the highlight color so they are easy to spot")
    stretch_color: FloatVectorProperty(name="Highlight", subtype='COLOR', size=3, min=0.0, max=1.0,
                                       default=(1.0, 0.0, 0.85))
    stretch_report: CollectionProperty(type=LT_StretchItem)
    preview_source: EnumProperty(
        name="Preview", default="LATEST",
        items=(("LATEST", "Latest Generated", "The template from the last Generate (no file picking)"),
               ("LIVE", "Current Settings", "Render a fresh preview from the settings above")))


class LIVERYTPL_OT_generate(bpy.types.Operator):
    bl_idname = "livery_template.generate"
    bl_label = "Generate Livery Template"
    bl_description = "Write the UV layout to a PNG"

    def execute(self, context):
        s = context.scene.livery_tpl
        if s.color_mode == 'MATERIAL' and s.material_a is None and s.material_b is None:
            self.report({'ERROR'}, "Pick at least one material")
            return {'CANCELLED'}
        if not s.filepath.strip():
            self.report({'ERROR'}, "Set an output location")
            return {'CANCELLED'}
        objs, used = _targets(context)
        if not objs:
            self.report({'ERROR'}, "Nothing to render: select meshes, or name them ending in _L0")
            return {'CANCELLED'}

        uv_index = int(s.uv_channel)
        g = _gather(context, s, uv_index, objs)
        if g["faces"] == 0:
            msg = "No faces use the chosen material(s)"
            if g["missing_uv"]:
                msg += " (UV%d missing on: %s)" % (uv_index + 1, ", ".join(g["missing_uv"][:3]))
            self.report({'ERROR'}, msg)
            return {'CANCELLED'}

        size = int(s.resolution)
        img = make_image(size, s.background, g["groups"], g["edges"],
                         (*s.line_color, 1.0), s.draw_fill, s.draw_wire, s.line_width)
        _store_report(s, g, self.report)

        path = bpy.path.abspath(s.filepath)
        if os.path.isdir(path) or path.endswith(("/", "\\")):
            path = os.path.join(path, "livery_template.png")
        if not path.lower().endswith(".png"):
            path += ".png"
        folder = os.path.dirname(path)
        try:
            if folder:
                os.makedirs(folder, exist_ok=True)
            _save_png(img, path, size)
            _store_latest(size, img)
        except Exception as e:
            self.report({'ERROR'}, "Could not write %s: %s" % (path, e))
            return {'CANCELLED'}

        note = ""
        if g["missing_uv"]:
            note = " (skipped, no UV%d: %s)" % (uv_index + 1, ", ".join(g["missing_uv"][:3]))
        if not g["stretched"]:
            self.report({'INFO'}, "Saved %s - %d faces from %d object(s) (%s)%s"
                        % (path, g["faces"], len(objs), used, note))
        return {'FINISHED'}


# ---- temporary material override -------------------------------------------

def _preview_active():
    return any(len(ob.lt_backup) for ob in bpy.data.objects)


def _preview_material(uv_name, image):
    name = "%s %s" % (PREVIEW_MAT, uv_name)
    mat = bpy.data.materials.get(name)
    if mat is None:
        mat = bpy.data.materials.new(name)
        try:
            mat.use_nodes = True
        except Exception:
            pass
        nt = mat.node_tree
        nt.nodes.clear()
        uvn = nt.nodes.new('ShaderNodeUVMap')
        uvn.location = (-600, 0)
        tex = nt.nodes.new('ShaderNodeTexImage')
        tex.location = (-380, 0)
        tex.interpolation = 'Linear'
        mix = nt.nodes.new('ShaderNodeMix')           # template over white (transparent areas)
        mix.data_type = 'RGBA'
        mix.location = (-160, 0)
        mix.inputs["A"].default_value = (1.0, 1.0, 1.0, 1.0)
        emi = nt.nodes.new('ShaderNodeEmission')
        emi.location = (60, 0)
        out = nt.nodes.new('ShaderNodeOutputMaterial')
        out.location = (260, 0)
        nt.links.new(uvn.outputs["UV"], tex.inputs["Vector"])
        nt.links.new(tex.outputs["Alpha"], mix.inputs["Factor"])
        nt.links.new(tex.outputs["Color"], mix.inputs["B"])
        nt.links.new(mix.outputs["Result"], emi.inputs["Color"])
        nt.links.new(emi.outputs["Emission"], out.inputs["Surface"])
        nt.nodes.active = tex
    nt = mat.node_tree
    for n in nt.nodes:
        if n.bl_idname == 'ShaderNodeUVMap':
            n.uv_map = uv_name                 # always the object's 2nd UV map
        elif n.bl_idname == 'ShaderNodeTexImage':
            n.image = image
    return mat


def _preview_image(size, img):
    im = bpy.data.images.get(PREVIEW_IMAGE)
    if im is not None and (im.size[0] != size or im.size[1] != size):
        bpy.data.images.remove(im)
        im = None
    if im is None:
        im = bpy.data.images.new(PREVIEW_IMAGE, size, size, alpha=True)
        im.colorspace_settings.name = 'sRGB'
    im.pixels.foreach_set(np.ascontiguousarray(img, dtype=np.float32).ravel())
    im.update()
    try:
        im.pack()
    except Exception:
        pass
    return im


def _store_latest(size, img):
    """Keep the generated template as an image datablock so the preview can use it directly."""
    im = bpy.data.images.get(LATEST_IMAGE)
    if im is not None and (im.size[0] != size or im.size[1] != size):
        bpy.data.images.remove(im)
        im = None
    if im is None:
        im = bpy.data.images.new(LATEST_IMAGE, size, size, alpha=True)
        im.colorspace_settings.name = 'sRGB'
        im.alpha_mode = 'STRAIGHT'
    im.pixels.foreach_set(np.ascontiguousarray(img, dtype=np.float32).ravel())
    im.update()
    try:
        im.pack()
    except Exception:
        pass
    return im


def _latest_image(s):
    """The last generated template: the stored copy, else the PNG at the output path."""
    im = bpy.data.images.get(LATEST_IMAGE)
    if im is not None:
        return im
    path = bpy.path.abspath(s.filepath)
    if path.lower().endswith(".png") and os.path.isfile(path):
        try:
            im = bpy.data.images.load(path, check_existing=False)
            im.name = LATEST_IMAGE
            im.alpha_mode = 'STRAIGHT'
            try:
                im.pack()
            except Exception:
                pass
            return im
        except Exception:
            return None
    return None


def _is_preview_mat(m):
    return m is not None and m.name.startswith(PREVIEW_MAT)


class LIVERYTPL_OT_mat_add(bpy.types.Operator):
    bl_idname = "livery_template.mat_add"
    bl_label = "Add Material"
    bl_description = "Add a material to the list the preview is allowed to override"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        context.scene.livery_tpl.override_mats.add()
        return {'FINISHED'}


class LIVERYTPL_OT_mat_remove(bpy.types.Operator):
    bl_idname = "livery_template.mat_remove"
    bl_label = "Remove"
    bl_options = {'INTERNAL'}

    index: IntProperty()

    def execute(self, context):
        lst = context.scene.livery_tpl.override_mats
        if 0 <= self.index < len(lst):
            lst.remove(self.index)
        return {'FINISHED'}


class LIVERYTPL_OT_preview(bpy.types.Operator):
    bl_idname = "livery_template.preview"
    bl_label = "Preview on Car"
    bl_description = ("Temporarily replace the listed materials (or A/B if the list is empty) with an "
                      "unlit material showing the latest generated template on UV2, to check it on "
                      "the model. Applies to every mesh object that uses those materials (all LODs). "
                      "Press again to refresh it; Restore Materials puts the originals back")

    def execute(self, context):
        s = context.scene.livery_tpl
        limit = [r.material for r in s.override_mats if r.material is not None]
        if not limit:
            limit = [m for m in (s.material_a, s.material_b) if m is not None]
        if not limit:
            self.report({'ERROR'}, "Pick the materials to override (list, or Material A/B)")
            return {'CANCELLED'}
        objs, used = _targets(context)

        if s.preview_source == 'LATEST':
            im = _latest_image(s)
            if im is None:
                self.report({'ERROR'}, "No generated template yet: press Generate first "
                                       "(or switch the preview to Current Settings)")
                return {'CANCELLED'}
        else:
            if not objs:
                self.report({'ERROR'}, "Select the meshes, or name them ending in _L0 "
                                       "(Current Settings renders from those)")
                return {'CANCELLED'}
            g = _gather(context, s, 1, objs)               # always UV2
            if g["faces"] == 0:
                self.report({'ERROR'}, "No faces to show: check the materials / UV2")
                return {'CANCELLED'}
            size = int(s.resolution)
            img = make_image(size, "TRANSPARENT", g["groups"], g["edges"], (*s.line_color, 1.0),
                             s.draw_fill, s.draw_wire, s.line_width)
            im = _preview_image(size, img)
            _store_report(s, g, self.report)

        # the override covers EVERY mesh object that uses one of the materials (all LODs),
        # not just the selection the template was generated from
        swapped = 0
        no_uv2 = []
        for ob in [o for o in bpy.data.objects if o.type == 'MESH']:
            if not any(sl.material in limit for sl in ob.material_slots) and not len(ob.lt_backup):
                continue
            uvs = ob.data.uv_layers
            if len(uvs) < 2:
                no_uv2.append(ob.name)
                continue
            mat = _preview_material(uvs[1].name, im)
            have = {b.index for b in ob.lt_backup}
            for i, slot in enumerate(ob.material_slots):
                m = slot.material
                if _is_preview_mat(m):
                    if m != mat:
                        slot.material = mat
                    continue
                if m is not None and m in limit and i not in have:
                    b = ob.lt_backup.add()
                    b.index, b.material = i, m
                    slot.material = mat
                    swapped += 1
        for win in context.window_manager.windows:
            for area in win.screen.areas:
                area.tag_redraw()
        msg = "Preview on: %d slot(s) overridden on all objects using the material(s)" % swapped
        if no_uv2:
            msg += " (no UV2: %s)" % ", ".join(no_uv2[:3])
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class LIVERYTPL_OT_restore(bpy.types.Operator):
    bl_idname = "livery_template.restore"
    bl_label = "Restore Materials"
    bl_description = "Put the original materials back and remove the temporary preview material"

    def execute(self, context):
        n = 0
        for ob in bpy.data.objects:
            if not len(ob.lt_backup):
                continue
            for b in ob.lt_backup:
                if 0 <= b.index < len(ob.material_slots):
                    ob.material_slots[b.index].material = b.material
                    n += 1
            ob.lt_backup.clear()
        for m in [m for m in bpy.data.materials if m.name.startswith(PREVIEW_MAT)]:
            if m.users == 0:
                bpy.data.materials.remove(m)
        im = bpy.data.images.get(PREVIEW_IMAGE)
        if im is not None and im.users == 0:
            bpy.data.images.remove(im)
        self.report({'INFO'}, "Restored %d slot(s)" % n)
        return {'FINISHED'}


class LIVERYTPL_OT_select_stretched(bpy.types.Operator):
    bl_idname = "livery_template.select_stretched"
    bl_label = "Select Stretched Faces"
    bl_description = ("Make this object active, enter Edit Mode and select its stretched faces "
                      "(matched by position, so it also works through a Mirror modifier)")
    bl_options = {'REGISTER', 'UNDO'}

    name: StringProperty()

    def execute(self, context):
        s = context.scene.livery_tpl
        ob = bpy.data.objects.get(self.name)
        if ob is None or ob.type != 'MESH':
            self.report({'ERROR'}, "Object not found")
            return {'CANCELLED'}
        with _eval_depsgraph(context, [ob]) as dg:
            data = _collect(ob, dg, int(s.uv_channel),
                            s.material_a, s.material_b,
                            None if s.color_mode == 'MATERIAL' else bool(s.flip_sides),
                            (s.stretch_edge, s.stretch_ratio))
        if data is None or data["flag"] is None or not data["flag"]["count"]:
            self.report({'INFO'}, "No stretched faces found on %s any more" % ob.name)
            return {'CANCELLED'}
        centers = data["flag"]["centers"]

        if context.object is not None and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        for o in context.selected_objects:
            o.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='FACE')
        bm = bmesh.from_edit_mesh(ob.data)
        bm.faces.ensure_lookup_table()
        kd = kdtree.KDTree(len(bm.faces))
        for f in bm.faces:
            kd.insert(f.calc_center_median(), f.index)
        kd.balance()
        for v in bm.verts:
            v.select_set(False)
        for e in bm.edges:
            e.select_set(False)
        for f in bm.faces:
            f.select_set(False)
        mirror_axes = []
        for m in ob.modifiers:
            if m.type == 'MIRROR' and m.show_viewport:
                mirror_axes += [a for a in range(3) if m.use_axis[a]]
        hit = set()
        for c in centers:
            # exact position first; only when no face is there, try the mirrored position
            # (the evaluated mesh has Mirror copies that the original mesh does not)
            found = [i for _co, i, _d in kd.find_range(Vector(c), 1e-4)]
            if not found:
                for axis in mirror_axes:
                    p = Vector(c)
                    p[axis] = -p[axis]
                    found += [i for _co, i, _d in kd.find_range(p, 1e-4)]
            hit.update(found)
        for i in hit:
            bm.faces[i].select_set(True)
        bm.select_flush_mode()
        bmesh.update_edit_mesh(ob.data, loop_triangles=False, destructive=False)
        if not hit:
            self.report({'WARNING'}, "Could not match the faces: a modifier moves the geometry, "
                                     "so check the object's modifiers")
            return {'CANCELLED'}
        self.report({'INFO'}, "Selected %d face(s) on %s" % (len(hit), ob.name))
        return {'FINISHED'}


class LIVERYTPL_OT_merge_copy(bpy.types.Operator):
    bl_idname = "livery_template.merge_copy"
    bl_label = "Merge Copy for Export"
    bl_description = ("Make ONE new object from copies of the mapped parts (selected meshes, else "
                      "_L0 objects). Modifiers are applied, and only faces using the materials in "
                      "the override list (or Material A / B) are kept. The originals are untouched")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        import bmesh
        s = context.scene.livery_tpl
        keep = [r.material for r in s.override_mats if r.material is not None]
        if not keep:
            keep = [m for m in (s.material_a, s.material_b) if m is not None]
        if not keep:
            self.report({'ERROR'}, "Add the materials to keep to the override list first")
            return {'CANCELLED'}
        name = s.merge_name.strip() or "Livery_Merged"
        objs, used = _targets(context)
        objs = [o for o in objs if o.name != name]       # never merge a previous result
        if not objs:
            objs = [o for o in context.scene.objects
                    if o.type == 'MESH' and L0_RE.search(o.name) and o.name != name]
        if not objs:
            self.report({'ERROR'}, "Select the meshes, or name them ending in _L0")
            return {'CANCELLED'}
        if context.object is not None and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        old = bpy.data.objects.get(name)
        if old is not None:
            om = old.data
            bpy.data.objects.remove(old, do_unlink=True)
            if om is not None and om.users == 0:
                bpy.data.meshes.remove(om)

        parts, skipped, uv_names, no_uv = [], [], None, []
        with _eval_depsgraph(context, objs) as dg:
            for ob in objs:
                me = bpy.data.meshes.new_from_object(ob.evaluated_get(dg), preserve_all_data_layers=True,
                                                     depsgraph=dg)
                if me is None or not len(me.polygons):
                    skipped.append(ob.name)
                    continue
                orig = {b.index: b.material for b in ob.lt_backup}   # preview slots -> originals
                slot_mats = [orig.get(i, sl.material) for i, sl in enumerate(ob.material_slots)]
                keep_slot = [m is not None and m in keep for m in slot_mats]
                n = max(len(slot_mats), 1)
                bm = bmesh.new()
                bm.from_mesh(me)
                kill = [f for f in bm.faces
                        if not (f.material_index < len(keep_slot) and keep_slot[f.material_index])]
                if kill:
                    bmesh.ops.delete(bm, geom=kill, context='FACES')
                    loose = [e for e in bm.edges if not e.link_faces]
                    if loose:
                        bmesh.ops.delete(bm, geom=loose, context='EDGES')
                    lv = [v for v in bm.verts if not v.link_edges]
                    if lv:
                        bmesh.ops.delete(bm, geom=lv, context='VERTS')
                if not bm.faces:
                    bm.free(); bpy.data.meshes.remove(me); skipped.append(ob.name)
                    continue
                if s.merge_uv1:                                  # livery UV -> the only map (UV1)
                    uvl = list(bm.loops.layers.uv.values())
                    ui = int(s.uv_channel)
                    if ui >= len(uvl):
                        bm.free(); bpy.data.meshes.remove(me); no_uv.append(ob.name)
                        continue
                    for i, l in enumerate(uvl):
                        if i != ui:
                            bm.loops.layers.uv.remove(l)
                for f in bm.faces:                               # slot -> index in the keep list
                    m = slot_mats[f.material_index] if f.material_index < len(slot_mats) else None
                    f.material_index = keep.index(m) if m in keep else 0
                bm.to_mesh(me)
                bm.free()
                if len(me.uv_layers):
                    if s.merge_uv1:
                        me.uv_layers[0].name = "UVMap"
                    me.uv_layers.active_index = 0
                me.transform(ob.matrix_world)                    # merge in world space
                me.materials.clear()
                for m in keep:
                    me.materials.append(m)
                if uv_names is None:
                    uv_names = [l.name for l in me.uv_layers]
                else:                                           # same names, so the join lines up
                    for l, nm in zip(me.uv_layers, uv_names):
                        if l.name != nm:
                            l.name = nm
                part = bpy.data.objects.new(name, me)
                context.collection.objects.link(part)
                parts.append(part)
        if not parts:
            self.report({'ERROR'}, "No faces use the chosen materials")
            return {'CANCELLED'}

        first = parts[0]
        if len(parts) > 1:
            with context.temp_override(object=first, active_object=first,
                                       selected_objects=parts, selected_editable_objects=parts):
                bpy.ops.object.join()
        first.name = name
        first.data.name = name
        for o in list(context.selected_objects):
            o.select_set(False)
        first.select_set(True)
        context.view_layer.objects.active = first
        msg = "Merged %d object(s) into '%s' (%d faces)" % (len(parts), name, len(first.data.polygons))
        if skipped:
            msg += "; nothing to keep on: " + ", ".join(skipped[:6])
        if no_uv:
            msg += "; no UV%d on: %s (left out)" % (int(s.uv_channel) + 1, ", ".join(no_uv[:6]))
        self.report({'INFO'}, msg)
        return {'FINISHED'}


class LIVERYTPL_PT_main(bpy.types.Panel):
    bl_label = "Livery Template"
    bl_idname = "LIVERYTPL_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_vehicle"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        s = context.scene.livery_tpl
        layout = self.layout
        layout.use_property_split = False

        box = layout.box()
        box.row(align=True).prop(s, "color_mode", expand=True)
        if s.color_mode == 'MATERIAL':
            row = box.row(align=True)
            row.prop_search(s, "material_a", bpy.data, "materials", text="A")
            row.prop(s, "color_a", text="")
            row = box.row(align=True)
            row.prop_search(s, "material_b", bpy.data, "materials", text="B")
            row.prop(s, "color_b", text="")
        else:
            row = box.row(align=True)
            row.prop(s, "color_right", text="Right")
            row.prop(s, "color_left", text="Left")
            box.prop(s, "flip_sides")
            box.label(text="Limit to materials (optional):")
            box.prop_search(s, "material_a", bpy.data, "materials", text="")
            box.prop_search(s, "material_b", bpy.data, "materials", text="")
        row = box.row(align=True)
        row.label(text="UV")
        row.prop(s, "uv_channel", expand=True)
        box.label(text="Uses selected meshes, else all _L0 objects", icon='INFO')

        box = layout.box()
        box.prop(s, "resolution")
        box.prop(s, "background")
        row = box.row(align=True)
        row.prop(s, "draw_fill")
        sub = row.row(align=True)
        sub.active = s.draw_fill
        sub.prop(s, "fill_alpha", text="")
        row = box.row(align=True)
        row.prop(s, "draw_wire")
        sub = row.row(align=True)
        sub.active = s.draw_wire
        sub.prop(s, "line_color", text="")
        sub.prop(s, "line_width", text="")

        box = layout.box()
        row = box.row(align=True)
        row.prop(s, "check_stretch")
        sub = row.row(align=True)
        sub.active = s.check_stretch
        sub.prop(s, "stretch_color", text="")
        if s.check_stretch:
            box.prop(s, "stretch_edge")
            box.prop(s, "stretch_ratio")
            box.prop(s, "highlight_stretch")

        layout.prop(s, "filepath", text="")
        layout.operator("livery_template.generate", icon='IMAGE_DATA')

        if len(s.stretch_report):
            box = layout.box()
            box.label(text="Stretched UVs found", icon='ERROR')
            for r in s.stretch_report:
                row = box.row(align=True)
                row.label(text="%s: %d face(s)" % (r.name, r.count))
                row.operator("livery_template.select_stretched", text="", icon='RESTRICT_SELECT_OFF').name = r.name

        # ---- preview on the car
        box = layout.box()
        box.label(text="Preview on Car (UV2)")
        box.row(align=True).prop(s, "preview_source", expand=True)
        box.label(text="Materials to override:")
        for i, r in enumerate(s.override_mats):
            row = box.row(align=True)
            row.prop_search(r, "material", bpy.data, "materials", text="")
            row.operator("livery_template.mat_remove", text="", icon='X').index = i
        row = box.row(align=True)
        row.operator("livery_template.mat_add", text="Add Material", icon='ADD')
        if not len(s.override_mats):
            box.label(text="Empty: uses Material A / B", icon='INFO')
        active = _preview_active()
        row = box.row(align=True)
        row.operator("livery_template.preview",
                     text="Refresh Preview" if active else "Preview on Car", icon='SHADING_TEXTURE')
        sub = row.row(align=True)
        sub.enabled = active
        sub.operator("livery_template.restore", text="Restore", icon='LOOP_BACK')
        if active:
            box.label(text="Preview is ON - restore before export!", icon='ERROR')

        # ---- one merged copy for Substance Painter
        box = layout.box()
        box.label(text="Merged Copy (Substance Painter)")
        box.prop(s, "merge_name")
        box.prop(s, "merge_uv1", text="UV%d -> UV1 (only UV map)" % (int(s.uv_channel) + 1))
        box.label(text="Keeps only the override-list materials", icon='INFO')
        box.operator("livery_template.merge_copy", icon='AUTOMERGE_ON')


classes = (
    LT_MatRef,
    LT_StretchItem,
    LT_Backup,
    LiveryTemplateSettings,
    LIVERYTPL_OT_generate,
    LIVERYTPL_OT_select_stretched,
    LIVERYTPL_OT_mat_add,
    LIVERYTPL_OT_mat_remove,
    LIVERYTPL_OT_preview,
    LIVERYTPL_OT_restore,
    LIVERYTPL_OT_merge_copy,
    LIVERYTPL_PT_main,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.livery_tpl = PointerProperty(type=LiveryTemplateSettings)
    bpy.types.Object.lt_backup = CollectionProperty(type=LT_Backup, options={'HIDDEN'})


def unregister():
    del bpy.types.Object.lt_backup
    del bpy.types.Scene.livery_tpl
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
