"""Rivet Generator: floating rivets that sit on a surface and look like they are pressed into it.

Every rivet is a small flat disc (outer ring, inner ring, centre) made as real geometry.  The modifier
stack then does the rest, the same way as a hand built rivet:

    Mirror (optional) > Shrinkwrap on 'Rivet Inside'  (inner ring + centre sit ON the surface)
                      > Shrinkwrap on 'Rivet Outer Edge' (outer ring floats a little above it = the lip)
                      > Weighted Normal > Data Transfer (copies the target's normals, so the rivet shades
                        as if it were an indent in the material)

Rivets are placed by dragging over the surface, clicking, from selected vertices or along selected edges.
All placements are stored on the rivet object, so changing the size / shape and pressing Rebuild updates
every rivet at once.
"""

import math

import bmesh
import bpy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty)
from bpy_extras import view3d_utils
from mathutils import Vector

KEY = "t3d_rivets"            # flat list: px py pz nx ny nz ...
KEY_TARGET = "t3d_rivet_target"
STRIP = "t3d_strip"          # JSON: rows of crossing edges [[ [a, na, b, nb], ... ], ...]
GUIDE = "t3d_guide"          # name of the hidden guide curve object
G_INSIDE = "Rivet Inside"
G_OUTER = "Rivet Outer Edge"
MOD_NAMES = ("Rivet Mirror", "Rivet Shrink Inside", "Rivet Shrink Outer", "Rivet Weighted Normal",
             "Rivet Normals", "Rivet Attributes")


def _is_mesh(self, obj):
    return obj.type == 'MESH' and KEY not in obj


_LOADING = [False]
KEY_SET = "t3d_settings"      # JSON snapshot of the settings this rivet set was built with
SET_KEYS = ("style", "head_h", "radius", "sides", "inner", "lip", "inside_off", "center_h", "normals", "normal_mix", "copy_mat",
            "copy_attrs", "live_wrap", "mirror_x", "ao_strength", "ao_attr", "spacing", "count_mode", "count",
            "ends", "strip_start", "strip_end", "slide")


def _save_settings(obj, s):
    import json
    d = {k: getattr(s, k) for k in SET_KEYS}
    d["_target"] = s.target.name if s.target is not None else ""
    obj[KEY_SET] = json.dumps(d)


def _load_settings(obj, s):
    import json
    try:
        d = json.loads(obj[KEY_SET])
    except Exception:
        return
    _LOADING[0] = True
    try:
        for k in SET_KEYS:
            if k in d:
                try:
                    setattr(s, k, d[k])
                except Exception:
                    pass
        t = bpy.data.objects.get(d.get("_target", "")) if d.get("_target") else None
        s.target = t
    finally:
        _LOADING[0] = False


def _rivets_changed(self, context):
    ob = self.rivets
    if ob is not None and KEY_SET in ob:
        _load_settings(ob, self)


def _strip_changed(self, context):
    if _LOADING[0]:
        return
    ob = self.rivets
    if ob is not None and STRIP in ob:
        try:
            regen_strip(context, ob, self)
        except Exception as ex:           # never break the UI over a slider
            print("Rivet strip update failed:", ex)


class RivetSettings(bpy.types.PropertyGroup):
    target: PointerProperty(type=bpy.types.Object, name="Surface", poll=_is_mesh,
                            description="The mesh the rivets sit on. Empty = the active mesh")
    rivets: PointerProperty(type=bpy.types.Object, name="Rivet Set", update=_rivets_changed,
                            description="The rivet object new rivets are added to. Empty = a new one is made. "
                                        "Picking a set (or selecting it) loads the settings it was made with")
    style: EnumProperty(name="Style", default='DISH',
                        items=[('DISH', "Dished Rivet", "Floating rivet with a lip that looks pressed into the surface"),
                               ('SCREW', "Screw Head", "A round head sticking out of the surface: no lip, no AO")],
                        description="Shape of the rivet")
    head_h: FloatProperty(name="Head Height", default=0.0015, min=0.0, max=0.1, unit='LENGTH', precision=4,
                          description="Screw Head: how far the top of the head sticks out of the surface")
    radius: FloatProperty(name="Radius", default=0.006, min=0.0001, max=1.0, unit='LENGTH', precision=4,
                          description="Outer radius of a rivet")
    sides: IntProperty(name="Sides", default=8, min=3, max=64, description="Corners of the rivet outline")
    inner: FloatProperty(name="Inner Ratio", default=0.55, min=0.05, max=0.95,
                         description="Inner ring size compared with the outer ring")
    lip: FloatProperty(name="Lip Height", default=0.002, min=-0.1, max=0.1, unit='LENGTH', precision=4,
                       description="How far the outer edge floats above the surface")
    inside_off: FloatProperty(name="Inside Offset", default=0.0003, min=-0.1, max=0.1, unit='LENGTH', precision=4,
                              description="Distance of the inner ring from the surface. Keep it a hair above 0 so the "
                                          "surface underneath can't bleed through")
    center_h: FloatProperty(name="Centre Height", default=0.002, min=-0.1, max=0.1, unit='LENGTH', precision=4,
                            description="The centre point is lifted this far along the surface normal "
                                        "(it is not shrinkwrapped)")
    normal_mix: FloatProperty(name="Normal Strength", default=0.7, min=0.0, max=1.0,
                              description="How much of the surface's normals the rivet takes (1 = fully, so "
                                          "it shades exactly like the surface; lower keeps some of its own "
                                          "shape so the dish catches light and shadow)")
    copy_mat: BoolProperty(name="Use Surface Material", default=True,
                           description="Each rivet gets the material of the face it sits on")
    copy_attrs: BoolProperty(name="Copy UVs and Colors", default=True,
                             description="Give the rivets the surface's UV maps and color attributes "
                                         "(read from the face under each rivet when it is built)")
    live_wrap: BoolProperty(name="Live Shrinkwrap", default=False,
                            description="Also add Shrinkwrap modifiers (nearest surface point) like a hand built "
                                        "stack. They can pull the rivet edge down near the edge of a surface, "
                                        "so by default the rivets are placed by projecting along their normal")
    normals: BoolProperty(name="Copy Normals From Surface", default=True,
                          description="Data Transfer the surface's normals onto the rivets so they read as an indent")
    mirror_x: BoolProperty(name="Mirror X", default=False,
                           description="Also place a mirrored rivet across X = 0 (rivets on the centre line are not doubled)")
    spacing: FloatProperty(name="Spacing", default=0.04, min=0.001, max=10.0, unit='LENGTH', precision=4,
                           description="Distance between rivets", update=_strip_changed)
    strip_start: FloatProperty(name="Start Offset", default=0.0, min=-1.0, max=1.0, unit='LENGTH', precision=4,
                               description="Move the first rivet along the line: positive pulls it in, "
                                           "negative runs the line further out past the start",
                               update=_strip_changed)
    strip_end: FloatProperty(name="End Offset", default=0.0, min=-1.0, max=1.0, unit='LENGTH', precision=4,
                             description="Move the last rivet along the line: positive pulls it in, "
                                         "negative runs the line further out past the end",
                             update=_strip_changed)
    ao_strength: FloatProperty(name="Inner AO", default=0.5, min=0.0, max=1.0, subtype='FACTOR',
                               description="Fake depth: darkens the red channel of the color attribute on the "
                                           "inner ring of every rivet, not the centre (0 = off)")
    ao_attr: bpy.props.StringProperty(name="AO Attribute", default="",
                                      description="Color attribute that gets the AO. Empty = every copied one "
                                                  "(a 'Col' attribute is made if the surface has none)")
    slide: FloatProperty(name="Slide", default=0.5, min=0.0, max=1.0, subtype='FACTOR',
                         description="Slide the rivet line across the width of the selected faces",
                         update=_strip_changed)
    count_mode: EnumProperty(name="Along Edges", default='SPACING',
                             items=[('SPACING', "By Spacing", "Rivets every 'spacing' along the edges"),
                                    ('COUNT', "By Count", "A fixed number per edge chain")],
                             update=_strip_changed)
    count: IntProperty(name="Count", default=5, min=1, max=1000, description="Rivets per edge chain",
                       update=_strip_changed)
    ends: BoolProperty(name="Rivet On Ends", default=True,
                       description="Put a rivet on the very ends of an edge chain (otherwise they are centred)",
                       update=_strip_changed)


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _resolve_target(context, s):
    if s.target is not None:
        return s.target
    ob = context.active_object
    if ob is not None and ob.type == 'MESH' and KEY not in ob:
        return ob
    return None


def _get_points(obj):
    flat = list(obj.get(KEY, []))
    return [(Vector(flat[i:i + 3]), Vector(flat[i + 3:i + 6])) for i in range(0, len(flat) - 5, 6)]


def _set_points(obj, pts):
    flat = []
    for p, n in pts:
        flat.extend((p.x, p.y, p.z, n.x, n.y, n.z))
    obj[KEY] = flat


def _frame(n):
    n = n.normalized()
    ref = Vector((0.0, 0.0, 1.0)) if abs(n.z) < 0.95 else Vector((1.0, 0.0, 0.0))
    t = n.cross(ref).normalized()
    b = n.cross(t)
    return n, t, b


class _Surface:
    """Ray casts against the evaluated target mesh, in world space."""

    def __init__(self, target, depsgraph):
        self.te = target.evaluated_get(depsgraph)
        self.mw = self.te.matrix_world.copy()
        self.inv = self.mw.inverted()
        self.nm = self.mw.to_3x3().inverted().transposed()
        sc = self.mw.to_scale()
        self.k = max((abs(sc.x) + abs(sc.y) + abs(sc.z)) / 3.0, 1e-9)
        self.me = self.te.to_mesh()               # works in Edit Mode too, where te.data can be empty
        self.polys = self.me.polygons
        self.nmat = len(target.material_slots)

    def close(self):
        try:
            self.te.to_mesh_clear()
        except Exception:
            pass

    def sample(self, idx, world_loc, uv_names, col_attrs):
        """Interpolated UVs / colors of polygon idx at a world position."""
        from mathutils.interpolate import poly_3d_calc
        me = self.me
        poly = me.polygons[idx]
        loops = range(poly.loop_start, poly.loop_start + poly.loop_total)
        vi = [me.loops[i].vertex_index for i in loops]
        pt = self.inv @ world_loc
        w = poly_3d_calc([me.vertices[v].co for v in vi], pt)
        out = {}
        for name in uv_names:
            d = me.uv_layers[name].data
            u = sum(d[l].uv.x * wi for l, wi in zip(loops, w))
            v = sum(d[l].uv.y * wi for l, wi in zip(loops, w))
            out[("uv", name)] = (u, v)
        for name, dom in col_attrs:
            d = me.color_attributes[name].data
            acc = [0.0, 0.0, 0.0, 0.0]
            for l, v, wi in zip(loops, vi, w):
                c = d[l].color if dom == 'CORNER' else d[v].color
                for k in range(4):
                    acc[k] += c[k] * wi
            out[("col", name)] = tuple(acc)
        return out

    def nearest(self, p):
        ok, loc, nrm, idx = self.te.closest_point_on_mesh(self.inv @ p)
        return (self.mw @ loc, idx) if ok else None

    def cast(self, origin, direction, dist):
        o = self.inv @ origin
        d = (self.inv.to_3x3() @ direction).normalized()
        hit, loc, nrm, idx = self.te.ray_cast(o, d, distance=dist / self.k)
        if not hit:
            return None
        return self.mw @ loc, (self.nm @ nrm).normalized(), idx


def build_geometry(pts, s, inv, surf=None):
    """Vertices / faces / group index lists / per-face material slot for all rivets.
    pts are world space, inv = world->object. With a surface, every vertex is projected onto it along the
    rivet's normal (so nothing snaps sideways near an edge)."""
    verts, faces, inside, outer, mats = [], [], [], [], []
    samples = []
    ao = []
    k = s.sides
    screw = s.style == 'SCREW'
    reach = s.radius * 1.5 + abs(s.lip) * 2.0 + abs(s.center_h) + abs(s.head_h) + 0.002
    c_off = s.head_h if screw else s.center_h          # a screw head is a flat top that sticks out
    in_off = s.head_h if screw else s.inside_off
    out_off = s.inside_off if screw else s.lip         # ...whose edge sits right on the surface, no lip

    def conform(q, n, off, cen=None):
        if surf is not None:
            h = surf.cast(q + n * reach, -n, reach * 2.0)
            if h is not None and h[1].dot(n) > 0.3:
                samples.append((h[2], h[0]))
                return h[0] + n * off
        samples.append(cen)
        return q + n * off

    for p, nrm in pts:
        n, t, b = _frame(nrm)
        base = len(verts)
        mi = 0
        if surf is not None:
            h = surf.cast(p + n * reach, -n, reach * 2.0)
            if h is not None and h[1].dot(n) > 0.3:
                # stand the rivet on the real face under it: a smoothed vertex normal would tilt it and
                # stretch the outline when projected onto a flat side
                p = h[0]
                n, t, b = _frame(h[1])
            if h is not None and surf.nmat:
                mi = min(surf.polys[h[2]].material_index, surf.nmat - 1)
        verts.append(tuple(inv @ conform(p, n, c_off)))
        cen = samples[-1]
        if cen is None and surf is not None:                  # ray missed: use the closest face instead
            nr = surf.nearest(p)
            if nr is not None:
                cen = (nr[1], nr[0])
                samples[-1] = cen
                if surf.nmat:
                    mi = min(surf.polys[nr[1]].material_index, surf.nmat - 1)
        for i in range(k):
            a = i * math.tau / k
            d = t * math.cos(a) + b * math.sin(a)
            verts.append(tuple(inv @ conform(p + d * (s.radius * s.inner), n, in_off, cen)))
            inside.append(base + 1 + i)
            if not screw:
                ao.append(base + 1 + i)
        for i in range(k):
            a = i * math.tau / k
            d = t * math.cos(a) + b * math.sin(a)
            verts.append(tuple(inv @ conform(p + d * s.radius, n, out_off, cen)))
            outer.append(base + 1 + k + i)
        for i in range(k):
            j = (i + 1) % k
            faces.append((base, base + 1 + i, base + 1 + j))
            faces.append((base + 1 + i, base + 1 + k + i, base + 1 + k + j, base + 1 + j))
            mats.extend((mi, mi))
    return verts, faces, inside, outer, mats, samples, ao


def _setup_modifiers(obj, s, target):
    for name in MOD_NAMES:
        m = obj.modifiers.get(name)
        if m is not None:
            obj.modifiers.remove(m)
    if s.live_wrap and s.style == 'DISH':
        sw = obj.modifiers.new("Rivet Shrink Inside", 'SHRINKWRAP')
        sw.wrap_method = 'NEAREST_SURFACEPOINT'
        sw.wrap_mode = 'ON_SURFACE'
        sw.target = target
        sw.vertex_group = G_INSIDE
        sw.offset = s.inside_off
        sw = obj.modifiers.new("Rivet Shrink Outer", 'SHRINKWRAP')
        sw.wrap_method = 'NEAREST_SURFACEPOINT'
        sw.wrap_mode = 'ON_SURFACE'
        sw.target = target
        sw.vertex_group = G_OUTER
        sw.offset = abs(s.lip)
    wn = obj.modifiers.new("Rivet Weighted Normal", 'WEIGHTED_NORMAL')
    wn.mode = 'FACE_AREA'
    wn.weight = 50
    wn.thresh = 0.01
    wn.keep_sharp = True
    if s.normals and s.style == 'DISH':
        dt = obj.modifiers.new("Rivet Normals", 'DATA_TRANSFER')
        dt.object = target
        dt.use_object_transform = True
        dt.use_loop_data = True
        dt.data_types_loops = {'CUSTOM_NORMAL'}
        dt.loop_mapping = 'POLYINTERP_NEAREST'
        dt.mix_mode = 'REPLACE'
        dt.mix_factor = s.normal_mix
        dt.vertex_group = G_OUTER


def _copy_attributes(me, target, surf, samples, ao_idx, s):
    """UVs / color attributes of the face under each rivet, plus the fake inner AO on the red channel."""
    import numpy as np
    tme = target.data
    uv_names = [u.name for u in tme.uv_layers] if s.copy_attrs else []
    cols = [(c.name, c.domain, c.data_type) for c in tme.color_attributes
            if c.domain in {'POINT', 'CORNER'}] if s.copy_attrs else []
    for name in list(me.uv_layers.keys()):
        me.uv_layers.remove(me.uv_layers[name])
    for name in list(me.color_attributes.keys()):
        me.color_attributes.remove(me.color_attributes[name])
    n = len(me.vertices)
    if not n:
        return
    ao = s.ao_strength if s.style == 'DISH' else 0.0
    if ao > 0.0 and not cols:
        cols = [(s.ao_attr or "Col", 'CORNER', 'BYTE_COLOR')]
    if not (uv_names or cols):
        return
    cols_src = [(c[0], c[1]) for c in cols if c[0] in tme.color_attributes]
    per = [surf.sample(smp[0], smp[1], uv_names, cols_src) if smp is not None else None for smp in samples]
    default = next((d for d in per if d is not None), None)
    per = [d if d is not None else default for d in per]
    li = np.empty(len(me.loops), dtype=np.int32)
    me.loops.foreach_get("vertex_index", li)
    weight = np.zeros(n, dtype=np.float32)
    weight[ao_idx] = 1.0
    for name in uv_names:
        arr = np.array([d[("uv", name)] if d else (0.0, 0.0) for d in per], dtype=np.float32)
        layer = me.uv_layers.new(name=name)
        layer.uv.foreach_set("vector", arr[li].ravel())
    for name, dom, dtype in cols:
        arr = np.array([d[("col", name)] if d and ("col", name) in d else (1.0, 1.0, 1.0, 1.0) for d in per],
                       dtype=np.float32)
        if ao > 0.0 and (not s.ao_attr or s.ao_attr == name):
            arr[:, 0] *= (1.0 - ao * weight)
        new = me.color_attributes.new(name, dtype, dom)
        if dom == 'CORNER':
            new.data.foreach_set("color", arr[li].ravel())
        else:
            new.data.foreach_set("color", arr.ravel())


def rebuild(obj, s, target):
    inv = obj.matrix_world.inverted()
    if target.mode == 'EDIT':
        target.update_from_editmode()          # the evaluated surface must see the current edit-mode mesh
        bpy.context.view_layer.update()
    surf = _Surface(target, bpy.context.evaluated_depsgraph_get())
    pts = _get_points(obj)
    if s.mirror_x:                      # mirrored copies, but never a second rivet on top of one on the plane
        pts = pts + [(Vector((-p.x, p.y, p.z)), Vector((-n.x, n.y, n.z)))
                     for p, n in pts if abs(p.x) >= s.radius]
    verts, faces, inside, outer, mats, samples, ao = build_geometry(pts, s, inv, surf)
    me = obj.data
    me.clear_geometry()
    me.from_pydata(verts, [], faces)
    for f, mi in zip(me.polygons, mats):
        f.use_smooth = True
    ring = set(inside)
    for e in me.edges:
        if e.vertices[0] in ring and e.vertices[1] in ring:
            e.use_edge_sharp = True
    me.update()
    if s.copy_attrs or (s.ao_strength > 0.0 and s.style == 'DISH'):
        _copy_attributes(me, target, surf, samples, ao, s)
    surf.close()
    _save_settings(obj, s)
    for name, idx in ((G_INSIDE, inside), (G_OUTER, outer)):
        vg = obj.vertex_groups.get(name) or obj.vertex_groups.new(name=name)
        vg.add(idx, 1.0, 'REPLACE') if idx else None
    _setup_modifiers(obj, s, target)
    if s.copy_mat:
        me.materials.clear()
        for slot in target.material_slots:
            me.materials.append(slot.material)
    else:
        me.materials.clear()
        mats = [0] * len(mats)
    # (clearing the slots resets every face to slot 0, so the per-face slot is set afterwards)
    for f, mi in zip(me.polygons, mats):
        f.material_index = mi
    obj[KEY_TARGET] = target.name


def _rivet_object(context, s, target):
    ob = s.rivets
    if ob is not None and ob.name in bpy.data.objects:
        return ob
    me = bpy.data.meshes.new("Rivets")
    ob = bpy.data.objects.new("Rivets", me)
    coll = context.collection or context.scene.collection
    coll.objects.link(ob)
    ob[KEY] = []
    s.rivets = ob
    return ob


def _add_points(context, new_pts):
    s = context.scene.rivet_gen
    target = _resolve_target(context, s)
    if target is None:
        return None
    ob = _rivet_object(context, s, target)
    if STRIP in ob:
        del ob[STRIP]                 # hand placed rivets: the set is no longer a slidable strip
    pts = _get_points(ob) + [(Vector(p), Vector(n)) for p, n in new_pts]
    _set_points(ob, pts)
    rebuild(ob, s, target)
    return ob


def surface_hit(target, depsgraph, origin, direction):
    """Ray (world space) against the evaluated target. Returns (point, normal) in world space or None."""
    te = target.evaluated_get(depsgraph)
    mw = te.matrix_world
    inv = mw.inverted()
    o = inv @ origin
    d = (inv.to_3x3() @ direction).normalized()
    hit, loc, nrm, _idx = te.ray_cast(o, d)
    if not hit:
        return None
    wp = mw @ loc
    wn = (mw.to_3x3().inverted().transposed() @ nrm).normalized()
    if wn.dot(direction) > 0.0:
        wn = -wn
    return wp, wn


def _chains(bm):
    adj = {}
    for e in bm.edges:
        if e.select and not e.hide:
            a, b = e.verts
            adj.setdefault(a.index, []).append(b.index)
            adj.setdefault(b.index, []).append(a.index)
    seen = set()
    chains = []
    order = sorted(adj, key=lambda i: (len(adj[i]) != 1, i))     # chain ends first
    for st in order:
        if st in seen:
            continue
        chain = [st]
        seen.add(st)
        cur = st
        while True:
            nxt = [n for n in adj[cur] if n not in seen]
            if not nxt:
                break
            cur = nxt[0]
            seen.add(cur)
            chain.append(cur)
        closed = len(chain) > 2 and chain[0] in adj[chain[-1]] and all(len(adj[i]) == 2 for i in chain)
        chains.append((chain, closed))
    return chains


def cut_line(poly, nrms, d0, d1):
    """Trim (positive) or extend (negative) a polyline by d0 at the start and d1 at the end."""
    if abs(d0) < 1e-9 and abs(d1) < 1e-9 or len(poly) < 2:
        return list(poly), list(nrms)
    pp, nn = list(poly), list(nrms)
    if d0 < 0:
        pp.insert(0, pp[0] + (pp[0] - pp[1]).normalized() * -d0)
        nn.insert(0, nn[0])
        d0 = 0.0
    if d1 < 0:
        pp.append(pp[-1] + (pp[-1] - pp[-2]).normalized() * -d1)
        nn.append(nn[-1])
        d1 = 0.0
    cum = [0.0]
    for i in range(len(pp) - 1):
        cum.append(cum[-1] + (pp[i + 1] - pp[i]).length)
    total = cum[-1]
    a, b = d0, total - d1
    if b <= a:
        m = total * 0.5
        a = b = m

    def at(d):
        for i in range(len(pp) - 1):
            if d <= cum[i + 1] or i == len(pp) - 2:
                sl = cum[i + 1] - cum[i]
                f = 0.0 if sl < 1e-12 else min(max((d - cum[i]) / sl, 0.0), 1.0)
                nv = nn[i].lerp(nn[i + 1], f)
                return pp[i].lerp(pp[i + 1], f), (nv.normalized() if nv.length > 1e-9 else nn[i])
        return pp[-1], nn[-1]

    op, on = [], []
    p0, n0 = at(a)
    op.append(p0)
    on.append(n0)
    for i in range(1, len(pp) - 1):
        if a < cum[i] < b:
            op.append(pp[i])
            on.append(nn[i])
    if b > a:
        p1, n1 = at(b)
        op.append(p1)
        on.append(n1)
    return op, on


def resample(poly, nrms, closed, mode, spacing, count, ends):
    """Points along a polyline (lists of Vectors) -> [(pos, normal)]."""
    pp = list(poly)
    nn = list(nrms)
    if closed:
        pp.append(pp[0])
        nn.append(nn[0])
    seg = [(pp[i + 1] - pp[i]).length for i in range(len(pp) - 1)]
    total = sum(seg)
    if total < 1e-9:
        return [(pp[0], nn[0])]
    if mode == 'COUNT':
        n = max(1, count)
        if closed:
            ds = [total * i / n for i in range(n)]
        elif ends:
            ds = [0.0] if n == 1 else [total * i / (n - 1) for i in range(n)]
            if n == 1:
                ds = [total * 0.5]
        else:
            ds = [total * (i + 0.5) / n for i in range(n)]
    else:
        if closed:
            n = max(1, round(total / spacing))
            ds = [total * i / n for i in range(n)]
        elif ends:
            m = max(1, round(total / spacing))
            ds = [total * i / m for i in range(m + 1)]
        else:
            m = max(1, round(total / spacing))
            ds = [total * (i + 0.5) / m for i in range(m)]
    out = []
    for d in ds:
        acc = 0.0
        for i, sl in enumerate(seg):
            if d <= acc + sl or i == len(seg) - 1:
                f = 0.0 if sl < 1e-12 else min(max((d - acc) / sl, 0.0), 1.0)
                p = pp[i].lerp(pp[i + 1], f)
                nv = nn[i].lerp(nn[i + 1], f)
                out.append((p, nv.normalized() if nv.length > 1e-9 else nn[i]))
                break
            acc += sl
    return out


# ---------------------------------------------------------------------------
# operators
# ---------------------------------------------------------------------------

class RIVET_OT_from_verts(bpy.types.Operator):
    bl_idname = "rivet.from_verts"
    bl_label = "Rivets on Selected Vertices"
    bl_description = "Put a rivet on every selected vertex (Edit Mode)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def execute(self, context):
        pts = []
        for ob in context.objects_in_mode_unique_data:
            if ob.type != 'MESH':
                continue
            bm = bmesh.from_edit_mesh(ob.data)
            mw = ob.matrix_world
            nm = mw.to_3x3().inverted().transposed()
            for v in bm.verts:
                if v.select and not v.hide:
                    pts.append((mw @ v.co, (nm @ v.normal).normalized()))
        if not pts:
            self.report({'ERROR'}, "Select some vertices")
            return {'CANCELLED'}
        if _add_points(context, pts) is None:
            self.report({'ERROR'}, "Pick the surface the rivets sit on")
            return {'CANCELLED'}
        self.report({'INFO'}, "Added %d rivet(s)" % len(pts))
        return {'FINISHED'}


class RIVET_OT_from_edges(bpy.types.Operator):
    bl_idname = "rivet.from_edges"
    bl_label = "Rivets Along Selected Edges"
    bl_description = "Spread rivets along the selected edges / edge loops (Edit Mode)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def execute(self, context):
        s = context.scene.rivet_gen
        pts = []
        for ob in context.objects_in_mode_unique_data:
            if ob.type != 'MESH':
                continue
            bm = bmesh.from_edit_mesh(ob.data)
            bm.verts.ensure_lookup_table()
            mw = ob.matrix_world
            nm = mw.to_3x3().inverted().transposed()
            for chain, closed in _chains(bm):
                poly = [mw @ bm.verts[i].co for i in chain]
                nrm = [(nm @ bm.verts[i].normal).normalized() for i in chain]
                if not closed:
                    poly, nrm = cut_line(poly, nrm, s.strip_start, s.strip_end)
                pts.extend(resample(poly, nrm, closed, s.count_mode, s.spacing, s.count, s.ends))
        if not pts:
            self.report({'ERROR'}, "Select some edges")
            return {'CANCELLED'}
        if _add_points(context, pts) is None:
            self.report({'ERROR'}, "Pick the surface the rivets sit on")
            return {'CANCELLED'}
        self.report({'INFO'}, "Added %d rivet(s)" % len(pts))
        return {'FINISHED'}


class RIVET_OT_paint(bpy.types.Operator):
    bl_idname = "rivet.paint"
    bl_label = "Place Rivets"
    bl_description = "Drag across the surface to drop rivets at the spacing, or click for single rivets"
    bl_options = {'REGISTER', 'UNDO'}

    mode: EnumProperty(items=[('DRAG', "Drag", ""), ('CLICK', "Click", "")], default='DRAG',
                       options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return context.area is not None and context.area.type == 'VIEW_3D' and context.mode in {'OBJECT', 'EDIT_MESH'}

    def invoke(self, context, event):
        s = context.scene.rivet_gen
        self.target = _resolve_target(context, s)
        if self.target is None:
            self.report({'ERROR'}, "Pick the surface the rivets sit on (or make it the active mesh)")
            return {'CANCELLED'}
        self.dragging = False
        self.last = None
        self.added = 0
        self.area = context.area
        self._status()
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _status(self):
        txt = ("Rivets: LMB %s   |   Backspace remove last   |   Enter / RMB / Esc finish"
               % ("drag over the surface" if self.mode == 'DRAG' else "click to place"))
        self.area.header_text_set(txt + "   (%d placed)" % self.added)

    def _hit(self, context, event):
        co = (event.mouse_region_x, event.mouse_region_y)
        rv3d = context.region_data
        o = view3d_utils.region_2d_to_origin_3d(context.region, rv3d, co)
        d = view3d_utils.region_2d_to_vector_3d(context.region, rv3d, co)
        return surface_hit(self.target, context.evaluated_depsgraph_get(), o, d)

    def _place(self, context, hit):
        if _add_points(context, [hit]) is None:
            return
        self.last = hit[0]
        self.added += 1
        self._status()

    def _remove_last(self, context):
        s = context.scene.rivet_gen
        ob = s.rivets
        if ob is None or not self.added:
            return
        pts = _get_points(ob)[:-1]
        _set_points(ob, pts)
        rebuild(ob, s, self.target)
        self.added -= 1
        self.last = pts[-1][0] if pts else None
        self._status()

    def _finish(self):
        self.area.header_text_set(None)

    def modal(self, context, event):
        s = context.scene.rivet_gen
        et = event.type
        if et == 'LEFTMOUSE':
            if event.value == 'PRESS':
                hit = self._hit(context, event)
                if hit is not None:
                    self._place(context, hit)
                    self.dragging = self.mode == 'DRAG'
                return {'RUNNING_MODAL'}
            if event.value == 'RELEASE':
                self.dragging = False
                return {'RUNNING_MODAL'}
        if et == 'MOUSEMOVE' and self.dragging:
            hit = self._hit(context, event)
            if hit is not None and (self.last is None or (hit[0] - self.last).length >= s.spacing):
                self._place(context, hit)
            return {'RUNNING_MODAL'}
        if event.value == 'PRESS' and et == 'BACK_SPACE':
            self._remove_last(context)
            return {'RUNNING_MODAL'}
        if event.value == 'PRESS' and et in {'RET', 'NUMPAD_ENTER', 'RIGHTMOUSE', 'ESC'}:
            self._finish()
            return {'FINISHED'}
        if et in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN', 'TRACKPADZOOM'} or \
                (event.type.startswith('NUMPAD') and et not in {'NUMPAD_ENTER'}):
            return {'PASS_THROUGH'}
        return {'RUNNING_MODAL'}


# ---------------------------------------------------------------------------
# strip from selected faces: a guide line you can slide across the faces
# ---------------------------------------------------------------------------

def _build_rows(selected, flip):
    """Rows of crossing edges for a quad strip. Each row is a list of (a_vert, b_vert) oriented so that
    b of row r is a of row r+1. Returns (rows, error text)."""
    sel = set(selected)
    if not sel:
        return None, "Select the faces the rivets should run across"
    if any(len(f.verts) != 4 for f in sel):
        return None, "The selected faces must all be quads"

    def other_face(e, f):
        for g in e.link_faces:
            if g in sel and g is not f:
                return g
        return None

    def loop_of(f, e):
        for l in f.loops:
            if l.edge is e:
                return l
        return None

    def through(a, b, e, f):
        """Walk from oriented crossing edge (a, b) = e into face f, then onwards."""
        out = []
        while f is not None:
            l = loop_of(f, e)
            v0, v1 = l.vert, l.link_loop_next.vert
            v2, v3 = l.link_loop_next.link_loop_next.vert, l.link_loop_prev.vert
            if (a, b) == (v0, v1):
                a2, b2 = v3, v2
            else:
                a2, b2 = v2, v3
            e2 = l.link_loop_next.link_loop_next.edge
            out.append((a2, b2, e2))
            a, b, e = a2, b2, e2
            f = other_face(e2, f)
        return out

    def row_from(a, b, e, f_first):
        """Whole row through crossing edge e (a->b) whose faces are f_first on one side."""
        fwd = through(a, b, e, f_first)
        other = None
        for g in e.link_faces:
            if g in sel and g is not f_first:
                other = g
        back = []
        if other is not None:
            back = through(b, a, e, other)          # runs the other way: reverse orientation afterwards
            back = [(bb, aa, ee) for aa, bb, ee in back]
        row = list(reversed(back)) + [(a, b, e)] + fwd
        return row

    def seed_row(start_face, pair):
        l0 = start_face.loops[0]
        l = l0 if pair == 0 else l0.link_loop_next
        e = l.edge
        a, b = e.verts[0], e.verts[1]
        return row_from(a, b, e, start_face)

    # pick the pairing that gives the longer rows
    f0 = next(iter(sel))
    cand = [seed_row(f0, 0), seed_row(f0, 1)]
    pick = 0 if len(cand[0]) >= len(cand[1]) else 1
    if flip:
        pick = 1 - pick
    base = cand[pick]
    rows = [base]

    def face_between(row, i):
        # face lying between crossing edge i and i+1 of the row (in the selection)
        e1, e2 = row[i][2], row[i + 1][2]
        for f in e1.link_faces:
            if f in sel and f in e2.link_faces:
                return f
        return None

    def neighbour_row(row, side):
        """Row next to `row` on side 'b' (+1) or 'a' (-1), or None."""
        # a face of the row to find the side edge
        for i in range(len(row) - 1):
            f = face_between(row, i)
            if f is None:
                continue
            a, b, e = row[i]
            v = b if side > 0 else a
            sides = [ed for ed in f.edges if ed is not e and v in ed.verts and ed is not row[i + 1][2]]
            if not sides:
                continue
            sd = sides[0]
            g = other_face(sd, f)
            if g is None:
                return None
            cont = [ed for ed in g.edges if ed is not sd and v in ed.verts]
            if not cont:
                return None
            ce = cont[0]
            w = ce.other_vert(v)
            if side > 0:
                na, nb = v, w
            else:
                na, nb = w, v
            return row_from(na, nb, ce, g if ce in g.edges else None)
        return None

    seen = set()
    for r in rows:
        seen.update(x[2] for x in r)
    # grow both ways
    for side in (1, -1):
        cur = base
        for _ in range(200):
            nr = neighbour_row(cur, side)
            if not nr or any(x[2] in seen for x in nr):
                break
            seen.update(x[2] for x in nr)
            if side > 0:
                rows.append(nr)
            else:
                rows.insert(0, nr)
            cur = nr
    return rows, None


def _strip_polyline(rows_data, u, spread):
    """Points along the strip at slide position u (0..1 over all rows)."""
    nr = len(rows_data)
    x = min(max(u, 0.0), 1.0) * nr
    r = min(int(x), nr - 1)
    t = x - r
    row = rows_data[r]
    poly, nrm = [], []
    for a, na, b, nb in row:
        pa, pb = Vector(a), Vector(b)
        poly.append(pa.lerp(pb, t))
        nv = Vector(na).lerp(Vector(nb), t)
        nrm.append(nv.normalized() if nv.length > 1e-9 else Vector(na))
    return poly, nrm


def _update_guide(context, ob, poly):
    name = ob.get(GUIDE)
    gob = bpy.data.objects.get(name) if name else None
    if gob is None:
        cu = bpy.data.curves.new("Rivet Guide", 'CURVE')
        cu.dimensions = '3D'
        gob = bpy.data.objects.new("Rivet Guide", cu)
        gob.hide_render = True
        gob.show_in_front = True
        coll = ob.users_collection[0] if ob.users_collection else context.scene.collection
        coll.objects.link(gob)
        ob[GUIDE] = gob.name
    cu = gob.data
    cu.splines.clear()
    sp = cu.splines.new('POLY')
    sp.points.add(len(poly) - 1)
    for pt, p in zip(sp.points, poly):
        pt.co = (p.x, p.y, p.z, 1.0)


def regen_strip(context, ob, s):
    import json
    rows = json.loads(ob[STRIP])
    poly, nrm = _strip_polyline(rows, s.slide, None)
    if len(poly) < 2:
        return
    poly, nrm = cut_line(poly, nrm, s.strip_start, s.strip_end)
    pts = resample(poly, nrm, False, s.count_mode, s.spacing, s.count, s.ends)
    name = ob.get(KEY_TARGET)
    target = bpy.data.objects.get(name) if name else None
    if target is None:
        return
    _set_points(ob, pts)
    rebuild(ob, s, target)
    _update_guide(context, ob, poly)


class RIVET_OT_from_faces(bpy.types.Operator):
    bl_idname = "rivet.from_faces"
    bl_label = "Rivets From Selected Faces"
    bl_description = ("Select a strip of quad faces (Edit Mode). A hidden guide line runs along them and rivets "
                      "are placed on it; use Slide to move the line across the faces")
    bl_options = {'REGISTER', 'UNDO'}

    flip: BoolProperty(name="Flip Direction", default=False,
                       description="Run the other way across the faces")

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def execute(self, context):
        import json
        s = context.scene.rivet_gen
        ob = None
        for o in context.objects_in_mode_unique_data:
            if o.type == 'MESH' and any(f.select for f in bmesh.from_edit_mesh(o.data).faces):
                ob = o
                break
        if ob is None:
            self.report({'ERROR'}, "Select some faces")
            return {'CANCELLED'}
        bm = bmesh.from_edit_mesh(ob.data)
        rows, err = _build_rows([f for f in bm.faces if f.select and not f.hide], self.flip)
        if err:
            self.report({'ERROR'}, err)
            return {'CANCELLED'}
        mw = ob.matrix_world
        nm = mw.to_3x3().inverted().transposed()
        data = []
        for row in rows:
            data.append([[list(mw @ a.co), list((nm @ a.normal).normalized()),
                          list(mw @ b.co), list((nm @ b.normal).normalized())] for a, b, _e in row])
        target = s.target if s.target is not None else ob
        # always a fresh set for a strip
        s.rivets = None
        riv = _rivet_object(context, s, target)
        riv[KEY_TARGET] = target.name
        riv[STRIP] = json.dumps(data)
        try:
            regen_strip(context, riv, s)
        except Exception as ex:
            self.report({'ERROR'}, "Could not build the strip: %s" % ex)
            return {'CANCELLED'}
        self.report({'INFO'}, "%d row(s) of faces, %d rivet(s). Use Slide to move the line across"
                    % (len(rows), len(_get_points(riv))))
        return {'FINISHED'}


class RIVET_OT_rebuild(bpy.types.Operator):
    bl_idname = "rivet.rebuild"
    bl_label = "Rebuild Rivets"
    bl_description = "Regenerate every rivet of the set with the current size, shape and modifier settings"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.scene.rivet_gen.rivets is not None

    def execute(self, context):
        s = context.scene.rivet_gen
        target = _resolve_target(context, s)
        if target is None:
            name = s.rivets.get(KEY_TARGET)
            target = bpy.data.objects.get(name) if name else None
        if target is None:
            self.report({'ERROR'}, "Pick the surface the rivets sit on")
            return {'CANCELLED'}
        rebuild(s.rivets, s, target)
        self.report({'INFO'}, "Rebuilt %d rivet(s)" % len(_get_points(s.rivets)))
        return {'FINISHED'}


class RIVET_OT_new_set(bpy.types.Operator):
    bl_idname = "rivet.new_set"
    bl_label = "Start New Set"
    bl_description = "Next rivets go into a new rivet object (the current one stays as it is)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        context.scene.rivet_gen.rivets = None
        return {'FINISHED'}


class RIVET_PT_main(bpy.types.Panel):
    bl_label = "Rivet Generator"
    bl_idname = "RIVET_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_modeling"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        s = context.scene.rivet_gen
        layout.prop(s, "target")
        row = layout.row(align=True)
        row.prop(s, "rivets", text="Set")
        row.operator("rivet.new_set", text="", icon='ADD')

        box = layout.box()
        box.label(text="Rivet")
        box.prop(s, "style", text="")
        col = box.column(align=True)
        col.prop(s, "radius")
        col.prop(s, "sides")
        col.prop(s, "inner")
        if s.style == 'DISH':
            col.prop(s, "lip")
            col.prop(s, "inside_off")
            col.prop(s, "center_h")
            box.prop(s, "normals")
            if s.normals:
                box.prop(s, "normal_mix")
        else:
            col.prop(s, "head_h")
            col.prop(s, "inside_off", text="Edge Offset")
        box.prop(s, "copy_mat")
        box.prop(s, "copy_attrs")
        if s.style == 'DISH':
            box.prop(s, "ao_strength")
            if s.ao_strength > 0.0:
                box.prop(s, "ao_attr")
            box.prop(s, "live_wrap")
        box.prop(s, "mirror_x")
        box.operator("rivet.rebuild", icon='FILE_REFRESH')

        box = layout.box()
        box.label(text="Place")
        box.prop(s, "spacing")
        op = box.operator("rivet.paint", text="Drag Over Surface", icon='BRUSH_DATA')
        op.mode = 'DRAG'
        op = box.operator("rivet.paint", text="Click to Place", icon='RESTRICT_SELECT_OFF')
        op.mode = 'CLICK'
        col = box.column(align=True)
        col.operator("rivet.from_verts", icon='VERTEXSEL')
        col.operator("rivet.from_edges", icon='EDGESEL')
        col.operator("rivet.from_faces", icon='FACESEL')
        if s.rivets is not None and STRIP in s.rivets:
            col.prop(s, "slide")
            col.prop(s, "strip_start")
            col.prop(s, "strip_end")
        col.row(align=True).prop(s, "count_mode", expand=True)
        if s.count_mode == 'COUNT':
            col.prop(s, "count")
        col.prop(s, "ends")


def _sync_active(scene, depsgraph=None):
    """Selecting a rivet object makes it the current set (and loads its own settings)."""
    try:
        s = scene.rivet_gen
        ob = bpy.context.view_layer.objects.active
        if ob is not None and KEY in ob and s.rivets is not ob:
            s.rivets = ob
    except Exception:
        pass


classes = (RivetSettings, RIVET_OT_from_verts, RIVET_OT_from_edges, RIVET_OT_from_faces, RIVET_OT_paint, RIVET_OT_rebuild,
           RIVET_OT_new_set, RIVET_PT_main)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.rivet_gen = PointerProperty(type=RivetSettings)
    if _sync_active not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_sync_active)


def unregister():
    if _sync_active in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_sync_active)
    del bpy.types.Scene.rivet_gen
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
