"""Panel Gap Generator.

Automates the bevel + vertex group + shrinkwrap panel gap workflow:

  1. a hidden copy of the mesh is kept as the shrinkwrap target ("<name>_PG_Source");
     it also remembers which edges were the panel seams
  2. the seam edges are beveled (Offset, 2 segments, profile 0.5, loop slide,
     sharp miters, grid fill - same as the manual Bevel modifier setup)
  3. the inner (middle) vertices of the bevel go into the vertex group "PanelGap"
     and the inner loop is marked sharp
  4. a Shrinkwrap modifier (Nearest Surface Point, Outside Surface, negative offset,
     vertex group "PanelGap") snaps only those vertices onto the copy and pushes them
     in by the offset -> the groove

Width / segments / profile are baked by the bevel, so change them and press
Regenerate (re-bevels from the stored copy). Add Gaps maps newly selected seam edges back to the
stored copy and rebuilds, so gaps can be added at any time. Offset is live (modifier).
Remove Gaps restores the original mesh and deletes the copy.
"""

import bmesh
import bpy
from mathutils import kdtree
from mathutils.geometry import intersect_point_line
from bpy.props import (BoolProperty, FloatProperty, IntProperty, PointerProperty)

SEAM_ATTR = "pg_seam"
GROUP_NAME = "PanelGap"
MOD_NAME = "Panel Gap"
SRC_SUFFIX = "_PG_Source"


# ----------------------------------------------------------------------------
# Core
# ----------------------------------------------------------------------------

def _make_bevel(bm, width, segments, profile, loop_slide, mark_sharp):
    """Bevel the seam edges in bm. Returns the list of inner vertex indices."""
    layer = bm.edges.layers.bool.get(SEAM_ATTR)
    if layer is None:
        return []
    edges = [e for e in bm.edges if e[layer]]
    if not edges:
        return []
    res = bmesh.ops.bevel(
        bm, geom=edges, offset=width, offset_type='OFFSET', profile=profile,
        segments=segments, affect='EDGES', clamp_overlap=False, loop_slide=loop_slide,
        material=-1, harden_normals=False, mark_seam=False, mark_sharp=False,
        miter_outer='SHARP', miter_inner='SHARP', face_strength_mode='NONE',
        vmesh_method='ADJ')
    new_faces = set(res["faces"])
    cand = set()
    for f in new_faces:
        cand.update(f.verts)
    # inner = every face around the vertex was created by the bevel
    # (outer loops of the strip still touch the original panel faces)
    inner = [v for v in cand if all(f in new_faces for f in v.link_faces)]
    inner_set = set(inner)
    if mark_sharp:
        for e in bm.edges:
            if e.verts[0] in inner_set and e.verts[1] in inner_set:
                e.smooth = False
    bm.verts.index_update()
    return [v.index for v in inner]


def _get_source(ob):
    s = ob.pg_source
    if s is not None and s.name in bpy.data.objects:
        return s
    return None


def _ensure_modifier(ob, src):
    mod = ob.modifiers.get(MOD_NAME)
    if mod is None:
        mod = ob.modifiers.new(MOD_NAME, 'SHRINKWRAP')
    mod.wrap_method = 'NEAREST_SURFACEPOINT'
    mod.wrap_mode = 'OUTSIDE_SURFACE'
    mod.target = src
    mod.offset = ob.pg_offset
    mod.vertex_group = GROUP_NAME
    mod.invert_vertex_group = False
    # shrinkwrap has to see the base mesh (before Mirror etc.), so it goes first
    names = [m.name for m in ob.modifiers]
    if names.index(MOD_NAME) != 0:
        try:
            ob.modifiers.move(names.index(MOD_NAME), 0)
        except Exception:
            with bpy.context.temp_override(object=ob, active_object=ob):
                bpy.ops.object.modifier_move_to_index(modifier=MOD_NAME, index=0)
    return mod


def _build_into(ob, src):
    """Re-bevel src.data (pristine copy + seams) into ob.data, vertex group, modifier."""
    bm = bmesh.new()
    bm.from_mesh(src.data)
    bm.edges.ensure_lookup_table()
    inner = _make_bevel(bm, ob.pg_width, ob.pg_segments, ob.pg_profile,
                        ob.pg_loop_slide, ob.pg_mark_sharp)
    # the seam layer is only meant for the stored copy
    layer = bm.edges.layers.bool.get(SEAM_ATTR)
    if layer is not None:
        bm.edges.layers.bool.remove(layer)
    bm.to_mesh(ob.data)
    bm.free()
    ob.data.update()

    vg = ob.vertex_groups.get(GROUP_NAME)
    if vg is not None:
        ob.vertex_groups.remove(vg)
    vg = ob.vertex_groups.new(name=GROUP_NAME)
    if inner:
        vg.add(inner, 1.0, 'REPLACE')
    _ensure_modifier(ob, src)
    return len(inner)


def _create_source(ob, bm_snapshot):
    """Create the hidden copy object from a bmesh that already holds the seam layer."""
    me = bpy.data.meshes.new(ob.name + SRC_SUFFIX)
    bm_snapshot.to_mesh(me)
    src = bpy.data.objects.new(ob.name + SRC_SUFFIX, me)
    for col in (ob.users_collection or [bpy.context.scene.collection]):
        col.objects.link(src)
    src.parent = ob
    src.matrix_parent_inverse.identity()
    src.hide_render = True
    src.hide_set(True)
    src.display_type = 'WIRE'
    return src


def _remove_source(ob):
    src = _get_source(ob)
    if src is None:
        return None
    me = src.data
    bpy.data.objects.remove(src)
    if me is not None and me.users == 0:
        bpy.data.meshes.remove(me)
    return me



def _map_selection_to_source(ob, src):
    """Mark the source edges that the currently selected edges of ob lie on.

    The mesh has already been beveled, so its edge indices no longer match the
    stored copy. Seam edges away from earlier gaps are the same edges; next to a
    gap they can be shorter pieces of a source edge, so match by position:
    both end points of a selected edge must lie on a source edge.
    Returns (matched source edges, selected edges)."""
    bm_edit = bmesh.from_edit_mesh(ob.data)
    sel = [(e.verts[0].co.copy(), e.verts[1].co.copy()) for e in bm_edit.edges if e.select]
    sbm = bmesh.new()
    sbm.from_mesh(src.data)
    sbm.edges.ensure_lookup_table()
    layer = sbm.edges.layers.bool.get(SEAM_ATTR)
    if layer is None:
        layer = sbm.edges.layers.bool.new(SEAM_ATTR)
    n = len(sbm.edges)
    matched = 0
    if n and sel:
        kd = kdtree.KDTree(n)
        longest = 0.0
        for i, e in enumerate(sbm.edges):
            a, b = e.verts[0].co, e.verts[1].co
            kd.insert((a + b) * 0.5, i)
            longest = max(longest, (a - b).length)
        kd.balance()
        eps = 1e-4
        radius = longest * 0.5 + eps * 4
        for a, b in sel:
            mid = (a + b) * 0.5
            for _co, i, _d in kd.find_range(mid, radius):
                se = sbm.edges[i]
                p, q = se.verts[0].co, se.verts[1].co
                hit = True
                for pt in (a, b):
                    cp, f = intersect_point_line(pt, p, q)
                    f = max(0.0, min(1.0, f))
                    if (p + (q - p) * f - pt).length > eps:
                        hit = False
                        break
                if hit:
                    if not se[layer]:
                        matched += 1
                    se[layer] = True
    sbm.to_mesh(src.data)
    sbm.free()
    return matched, len(sel)

# ----------------------------------------------------------------------------
# Properties
# ----------------------------------------------------------------------------

def _on_offset(self, context):
    mod = self.modifiers.get(MOD_NAME)
    if mod is not None and mod.type == 'SHRINKWRAP':
        mod.offset = self.pg_offset


def _source_poll(self, o):
    return o.type == 'MESH' and o != self


# ----------------------------------------------------------------------------
# Operators
# ----------------------------------------------------------------------------

class PG_OT_generate(bpy.types.Operator):
    bl_idname = "object.pg_generate"
    bl_label = "Generate Panel Gaps"
    bl_description = ("Bevel the selected edges (the panel seams) into a gap. Select the seam edges in "
                      "Edit Mode first. Keeps a hidden copy of the mesh as the shrinkwrap target")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and ob.mode == 'EDIT'

    def execute(self, context):
        ob = context.active_object
        if _get_source(ob) is not None:
            self.report({'ERROR'}, "Gaps already generated. Use Regenerate, or Remove Gaps first")
            return {'CANCELLED'}
        bm_edit = bmesh.from_edit_mesh(ob.data)
        if not any(e.select for e in bm_edit.edges):
            self.report({'WARNING'}, "Select the seam edges first")
            return {'CANCELLED'}
        snap = bm_edit.copy()
        layer = snap.edges.layers.bool.new(SEAM_ATTR)
        sel = [e.select for e in bm_edit.edges]
        snap.edges.ensure_lookup_table()
        for e, s in zip(snap.edges, sel):
            e[layer] = s
        # keep the working copy free of the seam layer's neighbours: just the pristine mesh
        bpy.ops.object.mode_set(mode='OBJECT')
        src = _create_source(ob, snap)
        snap.free()
        ob.pg_source = src
        n = _build_into(ob, src)
        bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'}, "Panel gaps generated (%d inner vertices)" % n)
        return {'FINISHED'}


class PG_OT_add(bpy.types.Operator):
    bl_idname = "object.pg_add"
    bl_label = "Add Gaps"
    bl_description = ("Add more panel gaps: select more seam edges in Edit Mode and press this. "
                      "The mesh is rebuilt from the stored copy with all seams, so manual edits "
                      "made after generating are lost")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return (ob is not None and ob.type == 'MESH' and ob.mode == 'EDIT'
                and _get_source(ob) is not None)

    def execute(self, context):
        ob = context.active_object
        src = _get_source(ob)
        bm_edit = bmesh.from_edit_mesh(ob.data)
        if not any(e.select for e in bm_edit.edges):
            self.report({'WARNING'}, "Select the new seam edges first")
            return {'CANCELLED'}
        matched, total = _map_selection_to_source(ob, src)
        if matched == 0:
            self.report({'WARNING'}, "Those edges are already gaps (or don't match the stored copy)")
            return {'CANCELLED'}
        bpy.ops.object.mode_set(mode='OBJECT')
        n = _build_into(ob, src)
        bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'}, "Added %d seam edge(s); %d inner vertices in total" % (matched, n))
        return {'FINISHED'}


class PG_OT_regenerate(bpy.types.Operator):
    bl_idname = "object.pg_regenerate"
    bl_label = "Regenerate"
    bl_description = ("Re-bevel from the stored copy with the current settings. "
                      "Manual edits made to the mesh after generating are lost")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and _get_source(ob) is not None

    def execute(self, context):
        ob = context.active_object
        was_edit = ob.mode == 'EDIT'
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')
        _build_into(ob, _get_source(ob))
        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}


class PG_OT_apply(bpy.types.Operator):
    bl_idname = "object.pg_apply"
    bl_label = "Apply Gaps"
    bl_description = ("Bake the panel gaps into the mesh: applies the Shrinkwrap, then removes the "
                      "modifier, the PanelGap vertex group and the hidden copy")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and _get_source(ob) is not None

    def execute(self, context):
        ob = context.active_object
        was_edit = ob.mode == 'EDIT'
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')
        mod = ob.modifiers.get(MOD_NAME)
        if mod is not None:
            if ob.data.users > 1:
                self.report({'ERROR'}, "The mesh is shared by several objects: make it single user first")
                if was_edit:
                    bpy.ops.object.mode_set(mode='EDIT')
                return {'CANCELLED'}
            with context.temp_override(object=ob, active_object=ob):
                bpy.ops.object.modifier_apply(modifier=MOD_NAME)
        vg = ob.vertex_groups.get(GROUP_NAME)
        if vg is not None:
            ob.vertex_groups.remove(vg)
        _remove_source(ob)
        ob.pg_source = None
        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')
        self.report({'INFO'}, "Panel gaps applied")
        return {'FINISHED'}


class PG_OT_remove(bpy.types.Operator):
    bl_idname = "object.pg_remove"
    bl_label = "Remove Gaps"
    bl_description = "Restore the original mesh and remove the modifier, vertex group and the hidden copy"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and _get_source(ob) is not None

    def execute(self, context):
        ob = context.active_object
        was_edit = ob.mode == 'EDIT'
        if was_edit:
            bpy.ops.object.mode_set(mode='OBJECT')
        src = _get_source(ob)
        bm = bmesh.new()
        bm.from_mesh(src.data)
        layer = bm.edges.layers.bool.get(SEAM_ATTR)
        if layer is not None:
            bm.edges.layers.bool.remove(layer)
        bm.to_mesh(ob.data)
        bm.free()
        ob.data.update()
        mod = ob.modifiers.get(MOD_NAME)
        if mod is not None:
            ob.modifiers.remove(mod)
        vg = ob.vertex_groups.get(GROUP_NAME)
        if vg is not None:
            ob.vertex_groups.remove(vg)
        _remove_source(ob)
        ob.pg_source = None
        if was_edit:
            bpy.ops.object.mode_set(mode='EDIT')
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------------

class VIEW3D_PT_panel_gap(bpy.types.Panel):
    bl_label = "Panel Gap Generator"
    bl_idname = "VIEW3D_PT_panel_gap"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_vehicle"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH'

    def draw(self, context):
        ob = context.active_object
        layout = self.layout
        has = _get_source(ob) is not None

        col = layout.column(align=True)
        col.prop(ob, "pg_width")
        col.prop(ob, "pg_segments")
        col.prop(ob, "pg_profile", slider=True)
        col.prop(ob, "pg_offset")
        col = layout.column(align=True)
        col.prop(ob, "pg_loop_slide")
        col.prop(ob, "pg_mark_sharp")

        if not has:
            layout.label(text="Edit Mode: select the seam edges", icon='INFO')
            layout.operator("object.pg_generate", icon='MOD_BEVEL')
        else:
            layout.prop(ob, "pg_source", text="Source")
            layout.operator("object.pg_add", icon='ADD')
            if ob.mode != 'EDIT':
                layout.label(text="Edit Mode: select more seam edges, Add Gaps", icon='INFO')
            layout.operator("object.pg_apply", icon='CHECKMARK')
            row = layout.row(align=True)
            row.operator("object.pg_regenerate", icon='FILE_REFRESH')
            row.operator("object.pg_remove", icon='X')
            layout.label(text="Width/segments/profile need Regenerate", icon='INFO')


# ----------------------------------------------------------------------------

classes = (
    PG_OT_generate,
    PG_OT_add,
    PG_OT_regenerate,
    PG_OT_apply,
    PG_OT_remove,
    VIEW3D_PT_panel_gap,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    Ob = bpy.types.Object
    Ob.pg_width = FloatProperty(name="Width", default=0.005, min=0.0, precision=4,
                                subtype='DISTANCE', description="Bevel width of the gap (Offset)")
    Ob.pg_segments = IntProperty(name="Segments", default=2, min=2, max=8,
                                 description="Bevel segments (2 puts one vertex loop in the middle)")
    Ob.pg_profile = FloatProperty(name="Profile Shape", default=0.5, min=0.0, max=1.0,
                                  subtype='FACTOR')
    Ob.pg_offset = FloatProperty(name="Depth (Offset)", default=-0.005, precision=4,
                                 subtype='DISTANCE', update=_on_offset,
                                 description="Shrinkwrap offset. Negative sinks the gap into the surface; live")
    Ob.pg_loop_slide = BoolProperty(name="Loop Slide", default=True)
    Ob.pg_mark_sharp = BoolProperty(name="Mark Inner Loop Sharp", default=True)
    Ob.pg_source = PointerProperty(name="Source", type=bpy.types.Object, poll=_source_poll)


def unregister():
    Ob = bpy.types.Object
    for n in ("pg_source", "pg_mark_sharp", "pg_loop_slide", "pg_offset",
              "pg_profile", "pg_segments", "pg_width"):
        delattr(Ob, n)
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
