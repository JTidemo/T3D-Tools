"""Object Utilities: small one-click helpers.

Make Local + Clear Parent: makes the selected objects local (linked / library-override objects
become normal ones that can be edited) and unparents them, keeping where they are in the scene.
"""

import bpy
from bpy.props import EnumProperty, PointerProperty


class ObjUtilSettings(bpy.types.PropertyGroup):
    local_type: EnumProperty(
        name="Make Local", default='SELECT_OBDATA_MATERIAL',
        items=[('SELECT_OBJECT', "Object", "Only the object"),
               ('SELECT_OBDATA', "Object + Data", "The object and its mesh / curve data"),
               ('SELECT_OBDATA_MATERIAL', "Object + Data + Materials", "Also the materials"),
               ('ALL', "Everything", "The objects and everything they use")],
        description="What becomes local when an object is linked from another file")


def _is_linked(o):
    return (o.library is not None or o.override_library is not None
            or (o.data is not None and getattr(o.data, "library", None) is not None))


class OBJUTIL_OT_local_unparent(bpy.types.Operator):
    bl_idname = "objutil.local_unparent"
    bl_label = "Make Local + Clear Parent (Keep Transform)"
    bl_description = ("Make the selected objects local and remove their parent, keeping their position, "
                      "rotation and scale in the scene")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.objutil
        if context.object is not None and context.object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        objs = list(context.selected_objects)
        if not objs:
            self.report({'ERROR'}, "Select the objects first")
            return {'CANCELLED'}
        made = unparented = 0
        linked = [(o.name, o.matrix_world.copy()) for o in objs if _is_linked(o)]
        if linked:
            try:
                bpy.ops.object.make_local(type=s.local_type)
            except RuntimeError as e:
                self.report({'ERROR'}, str(e).strip().splitlines()[-1])
                return {'CANCELLED'}
            context.view_layer.update()
            for name, mw in linked:
                lo = bpy.data.objects.get((name, None))   # the new local object
                if lo is None or lo.library is not None:
                    continue
                made += 1
                if not lo.users_collection:               # came from a linked collection: put it in the scene
                    context.collection.objects.link(lo)
                    context.view_layer.update()
                    lo.matrix_world = mw
                if lo.name in context.view_layer.objects:
                    lo.select_set(True)
        objs = [o for o in context.view_layer.objects if o.select_get() and o.library is None]
        todo = [o for o in objs if o.parent is not None]
        if todo:
            unparented = len(todo)
            for o in context.selected_objects:
                if o not in todo:
                    o.select_set(False)
            bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
            for o in objs:
                o.select_set(True)
        if not made and not unparented:
            self.report({'INFO'}, "Nothing to do: already local and without a parent")
            return {'FINISHED'}
        self.report({'INFO'}, "Made %d object(s) local, cleared the parent of %d (transform kept)"
                    % (made, unparented))
        return {'FINISHED'}


class OBJUTIL_PT_main(bpy.types.Panel):
    bl_label = "Object Utilities"
    bl_idname = "OBJUTIL_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_modeling"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(context.scene.objutil, "local_type", text="")
        layout.operator("objutil.local_unparent", icon='UNLINKED')


classes = (ObjUtilSettings, OBJUTIL_OT_local_unparent, OBJUTIL_PT_main)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.objutil = PointerProperty(type=ObjUtilSettings)


def unregister():
    del bpy.types.Scene.objutil
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
