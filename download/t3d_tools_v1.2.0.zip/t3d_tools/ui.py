"""Top-level category panels. Every tool panel is a subpanel of one of these."""

import bpy

TAB = "T3D Tools"


class _Category:
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = TAB

    def draw(self, context):
        pass  # content comes from the tool subpanels


class TOOLKIT_PT_modeling(_Category, bpy.types.Panel):
    bl_label = "Modeling Tools"
    bl_idname = "TOOLKIT_PT_modeling"


class TOOLKIT_PT_vehicle(_Category, bpy.types.Panel):
    bl_label = "Vehicle Tools"
    bl_idname = "TOOLKIT_PT_vehicle"


class TOOLKIT_PT_mapping(_Category, bpy.types.Panel):
    bl_label = "Mapping Tools"
    bl_idname = "TOOLKIT_PT_mapping"


classes = (TOOLKIT_PT_modeling, TOOLKIT_PT_vehicle, TOOLKIT_PT_mapping)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
