"""Extrude (No Border Walls): extrude the selected faces like Extrude Region (E), but an edge that has no
face on its other side (the open border of the mesh, e.g. a mirror seam) gets no side wall."""

import bmesh
import bpy


def extrude_no_walls(bm, faces):
    """Extrude `faces` in place. Returns (new top faces, number of border walls left out)."""
    faces = [f for f in faces if f.is_valid]
    old_verts = {v for f in faces for v in f.verts}
    before = set(bm.faces)
    res = bmesh.ops.extrude_face_region(bm, geom=faces)
    tops = [g for g in res["geom"] if isinstance(g, bmesh.types.BMFace)]
    tops_set = set(tops)
    walls = [f for f in bm.faces if f not in before and f not in tops_set]
    bmesh.ops.delete(bm, geom=faces, context='FACES_KEEP_BOUNDARY')       # the originals are consumed

    dropped = 0
    loose = []
    for w in walls:
        if not w.is_valid:
            continue
        old_edge = next((e for e in w.edges if e.verts[0] in old_verts and e.verts[1] in old_verts), None)
        if old_edge is not None and len(old_edge.link_faces) == 1:       # nothing on its other side
            loose.extend(w.edges)
            bmesh.ops.delete(bm, geom=[w], context='FACES_ONLY')
            dropped += 1
    loose_edges = [e for e in set(loose) if e.is_valid and not e.link_faces]
    if loose_edges:
        bmesh.ops.delete(bm, geom=loose_edges, context='EDGES')
    lone = [v for v in old_verts if v.is_valid and not v.link_edges]
    if lone:
        bmesh.ops.delete(bm, geom=lone, context='VERTS')

    for f in bm.faces:
        f.select_set(False)
    for e in bm.edges:
        e.select_set(False)
    for v in bm.verts:
        v.select_set(False)
    for f in tops:
        if f.is_valid:
            f.select_set(True)
    bm.select_flush(True)
    return tops, dropped


class EXTRUDECLEAN_OT_extrude(bpy.types.Operator):
    bl_idname = "extrudeclean.extrude"
    bl_label = "Extrude (No Border Walls)"
    bl_description = ("Extrude the selected faces along their normal. Edges with no face on the other side "
                      "(open mesh borders, like a mirror seam) get no side wall")
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def invoke(self, context, event):
        total = dropped = 0
        for ob in context.objects_in_mode_unique_data:
            if ob.type != 'MESH':
                continue
            bm = bmesh.from_edit_mesh(ob.data)
            faces = [f for f in bm.faces if f.select and not f.hide]
            if not faces:
                continue
            tops, d = extrude_no_walls(bm, faces)
            total += len(tops)
            dropped += d
            bmesh.update_edit_mesh(ob.data, loop_triangles=True, destructive=True)
        if not total:
            self.report({'ERROR'}, "Select some faces")
            return {'CANCELLED'}
        # same as pressing E: slide the new faces along their normal
        bpy.ops.transform.translate('INVOKE_DEFAULT', orient_type='NORMAL',
                                    constraint_axis=(False, False, True), mirror=True)
        return {'FINISHED'}

    def execute(self, context):
        return self.invoke(context, None)


class EXTRUDECLEAN_PT_main(bpy.types.Panel):
    bl_label = "Extrude (No Border Walls)"
    bl_idname = "EXTRUDECLEAN_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_modeling"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        col = self.layout.column(align=True)
        col.operator("extrudeclean.extrude", icon='ORIENTATION_NORMAL')
        col.label(text="Like E, but no wall on edges")
        col.label(text="that have no face behind them.")


classes = (EXTRUDECLEAN_OT_extrude, EXTRUDECLEAN_PT_main)


def register():
    for c in classes:
        bpy.utils.register_class(c)


def unregister():
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
