"""UV Pin: shrink a UV channel of the selected faces (Edit Mode) or meshes (Object Mode) to one pixel.

Dirt:        pin UV channel 2 to a chosen pixel (default: the middle of the black square in the
             top-left corner of a 1024 dirt texture).
Glass dirt:  pick the glass dirt texture and the darkest solid area of it is found automatically
             (it works like an alpha map), then UV channel 2 is pinned into that spot.

In Edit Mode only the selected faces move. Every mesh is scaled down on its own, keeping its layout, until it fits a box of the
given size in pixels, centred on the target pixel.
"""

import bpy
from bpy.props import EnumProperty, FloatProperty, IntProperty, PointerProperty


class UVPinSettings(bpy.types.PropertyGroup):
    uv_slot: IntProperty(name="UV Channel", default=2, min=1, max=8,
                         description="Which UV map to pin (2 = the second UV map)")
    size_px: FloatProperty(name="Size (px)", default=1.0, min=0.01, max=64.0,
                           description="The mesh's UVs are scaled to fit a box this many pixels wide")
    tex_size: IntProperty(name="Texture Size", default=1024, min=16, max=16384,
                          description="Resolution of the dirt texture the pixel position refers to")
    pos_x: FloatProperty(name="X", default=28.0, min=0.0, max=16384.0,
                         description="Target pixel, counted from the left edge of the texture")
    pos_y: FloatProperty(name="Y", default=28.5, min=0.0, max=16384.0,
                         description="Target pixel, counted from the TOP edge of the texture")
    pal_slot: IntProperty(name="UV Channel", default=1, min=1, max=8,
                          description="Which UV map to send to the chrome / black plastic spot (1 = the first UV map)")
    pal_tex: IntProperty(name="Texture Size", default=1024, min=16, max=16384,
                         description="Resolution of the texture that holds the chrome / black plastic spots")
    pal_size: FloatProperty(name="Size (px)", default=1.0, min=0.01, max=64.0,
                            description="The faces are scaled to fit a box this many pixels wide")
    chrome_u: FloatProperty(name="U", default=0.250, min=0.0, max=1.0, precision=3,
                            description="Chrome spot, U (0 = left edge)")
    chrome_v: FloatProperty(name="V", default=0.925, min=0.0, max=1.0, precision=3,
                            description="Chrome spot, V (0 = bottom edge, 1 = top edge)")
    black_u: FloatProperty(name="U", default=0.170, min=0.0, max=1.0, precision=3,
                           description="Black plastic spot, U (0 = left edge)")
    black_v: FloatProperty(name="V", default=0.855, min=0.0, max=1.0, precision=3,
                           description="Black plastic spot, V (0 = bottom edge, 1 = top edge)")
    proj: EnumProperty(
        name="Project First", default='VIEW',
        items=[('VIEW', "From View", "Planar projection from the current 3D view, then pin"),
               ('X', "From X", "Planar projection looking along X (side), then pin"),
               ('Y', "From Y", "Planar projection looking along Y (front/back), then pin"),
               ('Z', "From Z", "Planar projection looking along Z (top), then pin"),
               ('NONE', "Keep Existing UVs", "Pin the existing layout as it is (can leave seams)")],
        description="Flatten the UVs into one continuous planar projection before pinning, so there "
                    "are no broken seams")
    glass_image: PointerProperty(type=bpy.types.Image, name="Glass Dirt Texture",
                                 description="Texture to search for its darkest solid area")
    glass_tol: FloatProperty(name="Dark Tolerance", default=0.04, min=0.0, max=0.5,
                             description="How much brighter than the very darkest value still counts "
                                         "as dark. Raise it if the texture is noisy")


def _darkest(image, tol):
    """(x, y, radius) in image pixels (y from the top) of the centre of the biggest solid dark area."""
    import numpy as np
    w, h = image.size
    px = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(px)
    px = px.reshape(h, w, 4)
    lum = px[..., 0] * 0.2126 + px[..., 1] * 0.7152 + px[..., 2] * 0.0722
    lum = lum * px[..., 3] + (1.0 - px[..., 3])          # transparent counts as white
    lum = lum[::-1]                                       # Blender rows run bottom-up
    n = min(w, h)
    f = max(1, n // 512)
    mh, mw = h // f, w // f
    r = lum[:mh * f, :mw * f].reshape(mh, f, mw, f).mean(axis=(1, 3))
    lo = float(r.min())
    mask = r <= lo + tol
    c = np.pad(np.cumsum(np.cumsum(mask.astype(np.int32), 0), 1), ((1, 0), (1, 0)))

    def win(rr):
        k = 2 * rr + 1
        if k > min(mh, mw):
            return None
        s = c[k:, k:] - c[:-k, k:] - c[k:, :-k] + c[:-k, :-k]
        ys, xs = np.nonzero(s == k * k)
        return (ys, xs) if len(ys) else None

    a, b, best = 0, min(mh, mw) // 2, None
    while a <= b:
        mid = (a + b) // 2
        res = win(mid)
        if res is not None:
            best, a = (mid, res), mid + 1
        else:
            b = mid - 1
    if best is None:
        y, x = np.unravel_index(np.argmin(r), r.shape)
        return (x + 0.5) * f, (y + 0.5) * f, 0
    rr, (ys, xs) = best
    cy = ys.mean() + rr + 0.5
    cx = xs.mean() + rr + 0.5
    return cx * f, cy * f, rr * f


def _proj_rows(context, kind):
    """2x3 matrix that turns a world position into a flat UV position, or None to keep the UVs."""
    import numpy as np
    if kind == 'NONE':
        return None
    if kind == 'VIEW':
        rv = getattr(context.space_data, "region_3d", None) or context.region_data
        if rv is not None:
            m = np.array([list(r)[:3] for r in rv.view_matrix.to_3x3()], dtype=np.float64)
            return m[:2]
        kind = 'Y'
    if kind == 'X':
        return np.array([[0, 1, 0], [0, 0, 1]], dtype=np.float64)
    if kind == 'Y':
        return np.array([[1, 0, 0], [0, 0, 1]], dtype=np.float64)
    return np.array([[1, 0, 0], [0, 1, 0]], dtype=np.float64)


def _pin(objs, slot, u, v, size_uv, proj=None):
    import numpy as np
    done = 0
    for ob in objs:
        me = ob.data
        if len(me.uv_layers) < slot:
            continue
        layer = me.uv_layers[slot - 1]
        arr = np.empty(len(me.loops) * 2, dtype=np.float32)
        layer.uv.foreach_get("vector", arr)
        a = arr.reshape(-1, 2)
        if proj is not None:
            co = np.empty(len(me.vertices) * 3, dtype=np.float32)
            me.vertices.foreach_get("co", co)
            li = np.empty(len(me.loops), dtype=np.int32)
            me.loops.foreach_get("vertex_index", li)
            mw = np.array([list(r) for r in ob.matrix_world], dtype=np.float64)
            w = co.reshape(-1, 3).astype(np.float64)[li] @ mw[:3, :3].T + mw[:3, 3]
            a[:] = (w @ proj.T).astype(np.float32)
        lo, hi = a.min(axis=0), a.max(axis=0)
        ext = float((hi - lo).max())
        c = (lo + hi) * 0.5
        k = 0.0 if ext < 1e-12 else size_uv / ext
        a[:] = np.array([u, v], dtype=np.float32) + (a - c) * k
        layer.uv.foreach_set("vector", a.ravel())
        me.update()
        done += 1
    return done


def _pin_edit(context, slot, u, v, size_uv, proj=None):
    """Edit mode: only the selected faces of every mesh being edited. Returns (objects, faces)."""
    import bmesh
    objs = faces = 0
    for ob in context.objects_in_mode_unique_data:
        if ob.type != 'MESH':
            continue
        me = ob.data
        bm = bmesh.from_edit_mesh(me)
        layers = bm.loops.layers.uv.values()
        if len(layers) < slot:
            continue
        uvl = layers[slot - 1]
        sel = [f for f in bm.faces if f.select]
        if not sel:
            continue
        loops = [lp for f in sel for lp in f.loops]
        if proj is not None:
            import numpy as np
            mw = np.array([list(r) for r in ob.matrix_world], dtype=np.float64)
            for lp in loops:
                w = mw[:3, :3] @ np.array(list(lp.vert.co)) + mw[:3, 3]
                p = proj @ w
                lp[uvl].uv.x, lp[uvl].uv.y = float(p[0]), float(p[1])
        xs = [lp[uvl].uv.x for lp in loops]
        ys = [lp[uvl].uv.y for lp in loops]
        lo_x, hi_x, lo_y, hi_y = min(xs), max(xs), min(ys), max(ys)
        ext = max(hi_x - lo_x, hi_y - lo_y)
        k = 0.0 if ext < 1e-12 else size_uv / ext
        cx, cy = (lo_x + hi_x) * 0.5, (lo_y + hi_y) * 0.5
        for lp in loops:
            uv = lp[uvl].uv
            uv.x = u + (uv.x - cx) * k
            uv.y = v + (uv.y - cy) * k
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        objs += 1
        faces += len(sel)
    return objs, faces


class _PinBase:
    bl_options = {'REGISTER', 'UNDO'}

    def _pin_it(self, context, slot, u, v, size_uv):
        """Edit mode: the selected faces. Object mode: the whole selected meshes. Returns a text or None."""
        if context.mode == 'EDIT_MESH':
            n, faces = _pin_edit(context, slot, u, v, size_uv, _proj_rows(context, context.scene.uvpin.proj))
            if not n:
                self.report({'ERROR'}, "Select faces in Edit Mode (and check the mesh has UV map %d)" % slot)
                return None
            return "%d selected face(s)" % faces
        objs = [o for o in context.selected_objects if o.type == 'MESH']
        if not objs:
            self.report({'ERROR'}, "Select faces in Edit Mode, or meshes in Object Mode")
            return None
        n = _pin(objs, slot, u, v, size_uv, _proj_rows(context, context.scene.uvpin.proj))
        if not n:
            self.report({'ERROR'}, "None of the selected meshes has UV map %d" % slot)
            return None
        return "%d object(s)" % n


class UVPIN_OT_dirt(_PinBase, bpy.types.Operator):
    bl_idname = "uvpin.dirt"
    bl_label = "Map Selected to No Dirt"
    bl_description = ("Map the selected faces (Edit Mode) or meshes (Object Mode) to 'no dirt': their UV "
                      "channel is scaled down to a pixel in the clean spot of the dirt texture")

    def execute(self, context):
        s = context.scene.uvpin
        size = float(s.tex_size)
        u, v = s.pos_x / size, 1.0 - s.pos_y / size
        what = self._pin_it(context, s.uv_slot, u, v, s.size_px / size)
        if what is None:
            return {'CANCELLED'}
        self.report({'INFO'}, "Mapped %s to no dirt: pixel (%.1f, %.1f) of %d"
                    % (what, s.pos_x, s.pos_y, s.tex_size))
        return {'FINISHED'}


class UVPIN_OT_glass(_PinBase, bpy.types.Operator):
    bl_idname = "uvpin.glass"
    bl_label = "Map Selected to No Glass Dirt"
    bl_description = ("Map the selected faces (Edit Mode) or meshes (Object Mode) to 'no glass dirt': finds "
                      "the darkest solid area of the glass dirt texture and scales their UV channel into it")

    def execute(self, context):
        s = context.scene.uvpin
        img = s.glass_image
        if img is None or img.size[0] == 0:
            self.report({'ERROR'}, "Pick the glass dirt texture first")
            return {'CANCELLED'}
        x, y, r = _darkest(img, s.glass_tol)
        w, h = img.size
        what = self._pin_it(context, s.uv_slot, x / w, 1.0 - y / h, s.size_px / w)
        if what is None:
            return {'CANCELLED'}
        self.report({'INFO'}, "Mapped %s to no glass dirt: pixel (%d, %d), solid dark about %d px around it"
                    % (what, round(x), round(y), r))
        return {'FINISHED'}


class UVPIN_OT_chrome(_PinBase, bpy.types.Operator):
    bl_idname = "uvpin.chrome"
    bl_label = "Map Selected to Chrome"
    bl_description = ("Map the selected faces (Edit Mode) or meshes (Object Mode) to the chrome spot: "
                      "their UV channel is scaled down to a pixel at that UV position")

    def execute(self, context):
        s = context.scene.uvpin
        what = self._pin_it(context, s.pal_slot, s.chrome_u, s.chrome_v, s.pal_size / float(s.pal_tex))
        if what is None:
            return {'CANCELLED'}
        self.report({'INFO'}, "Mapped %s to chrome (UV %.3f, %.3f)" % (what, s.chrome_u, s.chrome_v))
        return {'FINISHED'}


class UVPIN_OT_black(_PinBase, bpy.types.Operator):
    bl_idname = "uvpin.black"
    bl_label = "Map Selected to Black Plastic"
    bl_description = ("Map the selected faces (Edit Mode) or meshes (Object Mode) to the black plastic spot: "
                      "their UV channel is scaled down to a pixel at that UV position")

    def execute(self, context):
        s = context.scene.uvpin
        what = self._pin_it(context, s.pal_slot, s.black_u, s.black_v, s.pal_size / float(s.pal_tex))
        if what is None:
            return {'CANCELLED'}
        self.report({'INFO'}, "Mapped %s to black plastic (UV %.3f, %.3f)" % (what, s.black_u, s.black_v))
        return {'FINISHED'}


class UVPIN_PT_main(bpy.types.Panel):
    bl_label = "UV Pin (Dirt UV2)"
    bl_idname = "UVPIN_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_vehicle"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        s = context.scene.uvpin
        col = layout.column(align=True)
        col.prop(s, "uv_slot")
        col.prop(s, "size_px")
        layout.prop(s, "proj")

        box = layout.box()
        box.label(text="No-dirt spot (clean pixel)")
        col = box.column(align=True)
        col.prop(s, "tex_size")
        row = col.row(align=True)
        row.prop(s, "pos_x")
        row.prop(s, "pos_y")
        box.operator("uvpin.dirt", icon='PINNED')

        box = layout.box()
        box.label(text="Palette spots (chrome / black plastic)")
        col = box.column(align=True)
        col.prop(s, "pal_slot")
        col.prop(s, "pal_tex")
        col.prop(s, "pal_size")
        row = box.row(align=True)
        row.label(text="Chrome")
        row.prop(s, "chrome_u")
        row.prop(s, "chrome_v")
        box.operator("uvpin.chrome", icon='PINNED')
        row = box.row(align=True)
        row.label(text="Black")
        row.prop(s, "black_u")
        row.prop(s, "black_v")
        box.operator("uvpin.black", icon='PINNED')

        box = layout.box()
        box.label(text="Glass dirt (darkest spot = no dirt)")
        box.prop(s, "glass_image", text="")
        box.prop(s, "glass_tol")
        box.operator("uvpin.glass", icon='PINNED')


classes = (UVPinSettings, UVPIN_OT_dirt, UVPIN_OT_glass, UVPIN_OT_chrome, UVPIN_OT_black, UVPIN_PT_main)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.uvpin = PointerProperty(type=UVPinSettings)


def unregister():
    del bpy.types.Scene.uvpin
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
