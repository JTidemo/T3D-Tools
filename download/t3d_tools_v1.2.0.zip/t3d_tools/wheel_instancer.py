import re
import bpy
from math import pi, radians
from mathutils import Matrix
from bpy.props import BoolProperty, FloatProperty, IntProperty, PointerProperty

# name, x sign (GTA: left = -X), y sign (GTA: front = +Y), is_right, is_front
WHEELS = (
    ("wheel_lf", -1, 1, False, True),
    ("wheel_rf", 1, 1, True, True),
    ("wheel_lr", -1, -1, False, False),
    ("wheel_rr", 1, -1, True, False),
)
INSTANCE_TAG = "wheel_instance"  # pivot empty under each dummy (gets steering / roll / flip)
SOURCE_TAG = "wheel_source"      # on each linked copy: points at the original object

# "wheel_L0", "wheel_L1.001" -> base, "_L0", 0
LOD_RE = re.compile(r"^(?P<base>.*?)(?P<lod>_L(?P<n>\d+))?(?P<dup>\.\d+)?$")


# ---------------------------------------------------------------- helpers

def parse_name(name):
    """Split an object name into (base, '_L<n>' suffix or '', lod number or None)."""
    m = LOD_RE.match(name)
    n = m.group("n")
    return m.group("base"), (m.group("lod") or ""), (int(n) if n is not None else None)


def get_instance(dummy):
    """Return the pivot empty parented to a wheel dummy, if any."""
    for child in dummy.children:
        if INSTANCE_TAG in child.keys():
            return child
    return None


def clear_copies(pivot):
    for child in list(pivot.children):
        if SOURCE_TAG in child.keys():
            bpy.data.objects.remove(child, do_unlink=True)


def apply_pose(scene):
    """Apply steering / roll / right-side flip to every pivot."""
    s = scene.wheel_inst
    for name, _sx, _sy, is_right, is_front in WHEELS:
        dummy = bpy.data.objects.get(name)
        if dummy is None:
            continue
        pivot = get_instance(dummy)
        if pivot is None:
            continue
        flipped = is_right and s.flip_right
        yaw = (s.steer if is_front else 0.0) + (pi if flipped else 0.0)
        roll = s.roll if flipped else -s.roll  # keeps all wheels rolling forward
        pivot.rotation_mode = 'XYZ'
        pivot.rotation_euler = (roll, 0.0, yaw)
        pivot.scale = (s.width_front if is_front else s.width_rear, 1.0, 1.0)


def lod_decision(lod, source_visible, scene_lods, follow_scene):
    """Pure rule: should a wheel copy with LOD number `lod` be shown?

    source_visible  - the original wheel object is visible (its own flags + its collections)
    scene_lods      - set of LOD numbers of the visible _L# objects elsewhere in the scene
    follow_scene    - narrow by scene_lods when that set is known (non-empty)
    Both signals have to agree, so it works whichever way the LOD tool hides things.
    """
    if not source_visible:
        return False
    if follow_scene and scene_lods and lod is not None:
        return lod in scene_lods
    return True


def _layer_collection_map(view_layer):
    """collection name -> (layer collection, parent layer collection)"""
    out = {}

    def walk(lc, parent):
        out[lc.name] = (lc, parent)
        for child in lc.children:
            walk(child, lc)

    walk(view_layer.layer_collection, None)
    return out


def _source_visible(src, view_layer, lmap, root_names, hide_source):
    """Visibility of an original wheel object, including hidden / excluded (sub)collections.

    The wheel root collections are hidden by this addon when 'Hide Original Collections' is on,
    so their own flag (and anything above) is ignored; everything below them still counts.
    """
    try:
        if src.hide_get(view_layer=view_layer):
            return False
    except (RuntimeError, TypeError):
        pass
    if src.hide_viewport:
        return False
    if not hide_source:
        try:
            return src.visible_get(view_layer=view_layer)
        except Exception:
            return True

    for coll in src.users_collection:
        entry = lmap.get(coll.name)
        if entry is None:
            continue
        hidden = False
        while entry is not None:
            lc, parent = entry
            if lc.name in root_names:
                break                      # our own hiding of the root: not the LOD tool's
            if lc.exclude or lc.hide_viewport or lc.collection.hide_viewport:
                hidden = True
                break
            entry = lmap.get(parent.name) if parent is not None else None
        if not hidden:
            return True
    return False


def scene_lod_set(view_layer, skip_names):
    """LOD numbers of the visible _L# objects outside the wheel collections (body, glass, ...)."""
    lods = set()
    for ob in view_layer.objects:
        if ob.type != 'MESH' or ob.name in skip_names or SOURCE_TAG in ob.keys():
            continue
        n = parse_name(ob.name)[2]
        if n is None:
            continue
        try:
            if ob.visible_get(view_layer=view_layer):
                lods.add(n)
        except Exception:
            pass
    return lods


def sync_visibility(scene):
    """Make every wheel copy show/hide like its source object (or follow the manual LOD)."""
    s = scene.wheel_inst
    view_layer = bpy.context.view_layer
    lmap = None
    root_names = {c.name for c in (s.collection, s.collection_rear) if c is not None}
    scene_lods = set()
    if not s.manual_lod:
        lmap = _layer_collection_map(view_layer)
        if s.follow_scene:
            skip = set()
            for c in (s.collection, s.collection_rear):
                if c is not None:
                    skip.update(o.name for o in c.all_objects)
            scene_lods = scene_lod_set(view_layer, skip)

    for name, *_ in WHEELS:
        dummy = bpy.data.objects.get(name)
        pivot = get_instance(dummy) if dummy else None
        if pivot is None:
            continue
        for ob in pivot.children:
            src = ob.get(SOURCE_TAG)
            if src is None:
                continue

            if s.manual_lod:
                lod = parse_name(src.name)[2]
                show = lod is None or lod == s.lod
                hide_render = not show
            else:
                lod = parse_name(src.name)[2]
                src_vis = _source_visible(src, view_layer, lmap, root_names, s.hide_source)
                show = lod_decision(lod, src_vis, scene_lods, s.follow_scene)
                hide_render = src.hide_render or not show

            if ob.hide_viewport:
                ob.hide_viewport = False
            try:
                if ob.hide_get() == show:  # current hidden state differs from wanted
                    ob.hide_set(not show)
            except RuntimeError:
                pass  # copy is not in the current view layer
            if ob.hide_render != hide_render:
                ob.hide_render = hide_render


def find_layer_collection(layer_coll, coll):
    if layer_coll.collection == coll:
        return layer_coll
    for child in layer_coll.children:
        found = find_layer_collection(child, coll)
        if found is not None:
            return found
    return None


def has_instances():
    for name, *_ in WHEELS:
        dummy = bpy.data.objects.get(name)
        if dummy is not None and get_instance(dummy) is not None:
            return True
    return False


def apply_source_hiding(scene, view_layer, hide=None):
    """Hide (or show) the original wheel collections in the viewport and in renders."""
    s = scene.wheel_inst
    if hide is None:
        hide = s.hide_source
    if hide and not has_instances():
        hide = False  # never hide the originals when there is nothing to replace them
    for coll in (s.collection, s.collection_rear):
        if coll is None:
            continue
        layer_coll = find_layer_collection(view_layer.layer_collection, coll)
        if layer_coll is not None:
            layer_coll.hide_viewport = hide
        coll.hide_render = hide


def _update_hide_source(self, context):
    apply_source_hiding(self.id_data, context.view_layer)
    sync_visibility(self.id_data)


def _update_pose(self, context):
    apply_pose(self.id_data)


def _update_lod(self, context):
    sync_visibility(self.id_data)


def _sync_timer():
    """Poll so the copies follow the LOD script no matter how it hides objects."""
    try:
        if not bpy.app.is_job_running('RENDER'):
            scene = bpy.context.scene
            if scene is not None and hasattr(scene, "wheel_inst"):
                sync_visibility(scene)
    except Exception:
        pass
    return 0.25


# ---------------------------------------------------------------- settings

class WheelInstSettings(bpy.types.PropertyGroup):
    collection: PointerProperty(
        name="Wheel Collection",
        description="Collection holding the wheel objects (all LODs). Its Instance Offset is used as the wheel pivot",
        type=bpy.types.Collection,
    )
    collection_rear: PointerProperty(
        name="Rear Wheel Collection",
        description="Optional. If set, the rear dummies use this collection instead (e.g. dually rear wheels). "
                    "Leave empty to use the same wheels as the front",
        type=bpy.types.Collection,
    )
    hide_source: BoolProperty(
        name="Hide Original Collections",
        description="Hide the original wheel collections (viewport and render) while the instances exist. "
                    "The copies keep following your LOD script's object visibility",
        default=True,
        update=_update_hide_source,
    )
    flip_right: BoolProperty(
        name="Flip Right Wheels",
        description="Rotate the right-side wheels 180 degrees around Z so the wheel faces outwards",
        default=True,
        update=_update_pose,
    )
    width_front: FloatProperty(
        name="Front Wheel Width",
        description="Scale of the front wheels along the axle (1 = original width)",
        default=1.0, min=0.1, max=3.0,
        update=_update_pose,
    )
    width_rear: FloatProperty(
        name="Rear Wheel Width",
        description="Scale of the rear wheels along the axle (1 = original width)",
        default=1.0, min=0.1, max=3.0,
        update=_update_pose,
    )
    manual_lod: BoolProperty(
        name="Override LOD",
        description="Ignore the visibility of the source wheels and show only the LOD chosen below",
        default=False,
        update=_update_lod,
    )
    lod: IntProperty(
        name="LOD",
        description="LOD to show on the instances when Override LOD is on (objects without _L# are always shown)",
        default=0, min=0, max=9,
        update=_update_lod,
    )
    follow_scene: BoolProperty(
        name="Follow Scene LODs",
        description="Also hide wheel LODs whose _L# is not visible on the other _L# objects in the scene "
                    "(body, glass, ...). Works with LOD tools that hide objects or collections in any way",
        default=True,
        update=_update_lod,
    )
    steer: FloatProperty(
        name="Steering",
        description="Front wheel steering angle (positive = left)",
        subtype='ANGLE',
        min=radians(-60.0),
        max=radians(60.0),
        default=0.0,
        update=_update_pose,
    )
    roll: FloatProperty(
        name="Roll",
        description="Wheel spin around the axle, for render variety",
        subtype='ANGLE',
        soft_min=-2 * pi,
        soft_max=2 * pi,
        default=0.0,
        update=_update_pose,
    )
    wheelbase: FloatProperty(
        name="Wheelbase", subtype='DISTANCE', unit='LENGTH',
        description="Distance between front and rear dummies", default=2.6, min=0.0,
    )
    track: FloatProperty(
        name="Track Width", subtype='DISTANCE', unit='LENGTH',
        description="Distance between left and right dummies", default=1.6, min=0.0,
    )
    radius: FloatProperty(
        name="Dummy Height", subtype='DISTANCE', unit='LENGTH',
        description="Z height of the dummies (usually the wheel radius)", default=0.35, min=0.0,
    )


# ---------------------------------------------------------------- operators

class WHEELINST_OT_create_dummies(bpy.types.Operator):
    bl_idname = "wheel_inst.create_dummies"
    bl_label = "Create Wheel Dummies"
    bl_description = "Create wheel_lf, wheel_rf, wheel_lr and wheel_rr empties (existing ones are kept)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.wheel_inst
        target = context.collection
        created = 0
        for name, sx, sy, *_ in WHEELS:
            if bpy.data.objects.get(name) is not None:
                continue
            ob = bpy.data.objects.new(name, None)
            ob.empty_display_type = 'ARROWS'
            ob.empty_display_size = 0.2
            ob.location = (sx * s.track / 2, sy * s.wheelbase / 2, s.radius)
            target.objects.link(ob)
            created += 1
        if created:
            self.report({'INFO'}, f"Created {created} wheel dummies")
        else:
            self.report({'INFO'}, "All four wheel dummies already exist")
        return {'FINISHED'}


class WHEELINST_OT_instance(bpy.types.Operator):
    bl_idname = "wheel_inst.instance"
    bl_label = "Instance Wheels"
    bl_description = ("Build linked copies of every object in the wheel collection on all four dummies. "
                      "Run again after adding/removing wheel objects or changing their transforms")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.wheel_inst
        if s.collection is None:
            self.report({'ERROR'}, "Pick a wheel collection first")
            return {'CANCELLED'}

        jobs = []   # (dummy, source objects, pivot offset)
        cache = {}  # collection name -> (sources, offset)
        for name, _sx, _sy, _is_right, is_front in WHEELS:
            dummy = bpy.data.objects.get(name)
            if dummy is None:
                self.report({'ERROR'}, f"Missing '{name}' - create the dummies first")
                return {'CANCELLED'}
            coll = s.collection if is_front else (s.collection_rear or s.collection)
            if coll.all_objects.get(dummy.name) is not None:
                self.report({'ERROR'}, f"'{name}' is inside '{coll.name}' - move it out first")
                return {'CANCELLED'}
            if coll.name not in cache:
                sources = [o for o in coll.all_objects
                           if SOURCE_TAG not in o.keys() and INSTANCE_TAG not in o.keys()]
                if not sources:
                    self.report({'ERROR'}, f"'{coll.name}' has no objects")
                    return {'CANCELLED'}
                cache[coll.name] = (sources, Matrix.Translation(-coll.instance_offset))
            sources, offset = cache[coll.name]
            jobs.append((dummy, sources, offset))

        for dummy, sources, offset in jobs:
            pivot = get_instance(dummy)
            if pivot is None:
                pivot = bpy.data.objects.new(f"{dummy.name}_instance", None)
                pivot[INSTANCE_TAG] = True
                pivot.empty_display_type = 'PLAIN_AXES'
                pivot.empty_display_size = 0.05
                for c in dummy.users_collection:
                    c.objects.link(pivot)
                pivot.parent = dummy
            # also upgrades pivots made by v1.0, which used collection instancing
            pivot.instance_type = 'NONE'
            pivot.instance_collection = None
            clear_copies(pivot)

            for src in sources:
                base, lod, _n = parse_name(src.name)
                ob = src.copy()  # shares mesh data with the source
                ob.name = f"{base}_{dummy.name}{lod}"  # keeps the _L# suffix at the end
                ob[SOURCE_TAG] = src
                for c in dummy.users_collection:
                    c.objects.link(ob)
                ob.parent = pivot
                ob.parent_type = 'OBJECT'
                ob.matrix_parent_inverse = Matrix.Identity(4)
                ob.matrix_basis = offset @ src.matrix_world

        apply_pose(context.scene)
        apply_source_hiding(context.scene, context.view_layer)
        sync_visibility(context.scene)
        return {'FINISHED'}


class WHEELINST_OT_remove(bpy.types.Operator):
    bl_idname = "wheel_inst.remove"
    bl_label = "Remove Instances"
    bl_description = "Delete the wheel copies and pivots and show the original collections again (the dummies are kept)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        for name, *_ in WHEELS:
            dummy = bpy.data.objects.get(name)
            pivot = get_instance(dummy) if dummy else None
            if pivot is not None:
                clear_copies(pivot)
                bpy.data.objects.remove(pivot, do_unlink=True)
        apply_source_hiding(context.scene, context.view_layer, hide=False)
        return {'FINISHED'}


class WHEELINST_OT_reset_pose(bpy.types.Operator):
    bl_idname = "wheel_inst.reset_pose"
    bl_label = "Reset Steering / Roll"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.wheel_inst
        s.steer = 0.0
        s.roll = 0.0
        apply_pose(context.scene)
        return {'FINISHED'}


# ---------------------------------------------------------------- UI

class WHEELINST_PT_main(bpy.types.Panel):
    bl_label = "Wheel Instancer"
    bl_idname = "WHEELINST_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_vehicle"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        s = context.scene.wheel_inst
        layout = self.layout

        box = layout.box()
        box.label(text="Dummies", icon='EMPTY_ARROWS')
        col = box.column(align=True)
        col.prop(s, "wheelbase")
        col.prop(s, "track")
        col.prop(s, "radius")
        box.operator("wheel_inst.create_dummies", icon='ADD')

        box = layout.box()
        box.label(text="Instancing", icon='OUTLINER_COLLECTION')
        box.prop(s, "collection", text="Wheels")
        box.prop(s, "collection_rear", text="Rear (optional)")
        box.prop(s, "flip_right")
        box.prop(s, "hide_source")
        col = box.column(align=True)
        col.prop(s, "width_front", slider=True)
        col.prop(s, "width_rear", slider=True)
        row = box.row(align=True)
        row.operator("wheel_inst.instance", icon='LINKED')
        row.operator("wheel_inst.remove", text="", icon='X')

        box = layout.box()
        box.label(text="LOD", icon='MOD_DECIM')
        box.prop(s, "manual_lod")
        row = box.row()
        row.active = s.manual_lod
        row.prop(s, "lod")
        row = box.row()
        row.active = not s.manual_lod
        row.prop(s, "follow_scene")
        if not s.manual_lod:
            box.label(text="Following source wheel visibility")

        box = layout.box()
        box.label(text="Preview", icon='CON_ROTLIKE')
        box.prop(s, "steer", slider=True)
        box.prop(s, "roll")
        box.operator("wheel_inst.reset_pose", icon='LOOP_BACK')


# ---------------------------------------------------------------- register

classes = (
    WheelInstSettings,
    WHEELINST_OT_create_dummies,
    WHEELINST_OT_instance,
    WHEELINST_OT_remove,
    WHEELINST_OT_reset_pose,
    WHEELINST_PT_main,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.wheel_inst = PointerProperty(type=WheelInstSettings)
    if not bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.register(_sync_timer, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_sync_timer):
        bpy.app.timers.unregister(_sync_timer)
    del bpy.types.Scene.wheel_inst
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
