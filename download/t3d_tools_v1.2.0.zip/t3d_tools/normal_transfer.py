"""Normal Transfer: project custom normals from other meshes onto selected faces.

Same workflow as UV Transfer:
  * a list of transfers on the object, each with its own stored face set
    (Edit Mode: select faces -> Apply Selection, Get Selection re-selects them)
  * every source mesh of a transfer is one Geometry Nodes modifier, kept pinned
    to the bottom of the stack (so it runs after Mirror etc.)
  * the modifier inputs are driven from the properties below, so everything is
    edited in the panel

Mark Sharp edges are respected: the faces on the two sides of a sharp edge are
treated as separate "fans", so a transfer never leaks across a sharp edge onto
the neighbouring faces.

Stack order: [... Mirror etc.] -> "CN Normals" (CN face sets, if present) ->
Normal Transfer modifiers (in list order, the later one wins where they overlap).
Transfers are the last word: they blend over the CN normals on their faces.
"""

import bmesh
import bpy
from bpy.app.handlers import persistent
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, FloatProperty,
                       FloatVectorProperty, IntProperty, PointerProperty, StringProperty)

GROUP_NAME = ".NTR_Transfer"      # leading dot hides it from most dropdowns
GROUP_VERSION = 1
MOD_PREFIX = "NTR "

# The CN Normals tool (face sets 1-4) keeps its modifier at the very bottom;
# transfers are ordered just above it.
CN_MOD_NAME = "CN Normals"

METHOD_ITEMS = (
    ('NEAREST', "Nearest", "Use the normal of the closest point on the source surface"),
    ('RAY_NORMAL', "Along Normal",
     "Cast rays along the target's own normal (both ways) and use the source normal at the hit"),
    ('RAY_AXIS', "Direction",
     "Cast rays along a fixed direction (in the target's local space) onto the source"),
)
METHOD_INDEX = {k: i for i, (k, _n, _d) in enumerate(METHOD_ITEMS)}


# ----------------------------------------------------------------------------
# Version-safe access to Geometry Nodes modifier inputs
# (Blender <= 5.1: mod[key]; Blender 5.2+: mod.properties.inputs[key]["value"])
# ----------------------------------------------------------------------------

def _mod_get(mod, key):
    props = getattr(mod, "properties", None)
    if props is not None:
        return props.inputs[key]["value"]
    return mod[key]


def _mod_set(mod, key, value):
    props = getattr(mod, "properties", None)
    if props is not None:
        props.inputs[key]["value"] = value
    else:
        mod[key] = value


def _norm(v):
    """Make values comparable (vectors / idprop arrays -> tuples of floats)."""
    if v is None or isinstance(v, (str, bool, int, float)):
        return v
    try:
        return tuple(round(float(x), 6) for x in v)
    except TypeError:
        return v


def _set(mod, key, value):
    try:
        cur = _mod_get(mod, key)
    except (KeyError, TypeError, AttributeError):
        cur = None
    if _norm(cur) == _norm(value):
        return False
    _mod_set(mod, key, value)
    return True


# ----------------------------------------------------------------------------
# Node group (built from code, shared by every modifier)
# ----------------------------------------------------------------------------

def _inp(node, name):
    for s in node.inputs:
        if s.name == name and s.enabled:
            return s
    raise KeyError("%s: no enabled input '%s'" % (node.bl_idname, name))


def _out(node, name):
    for s in node.outputs:
        if s.name == name and s.enabled:
            return s
    raise KeyError("%s: no enabled output '%s'" % (node.bl_idname, name))


def _build_group():
    old = bpy.data.node_groups.get(GROUP_NAME)
    if old is not None:
        # Remove instead of clearing so modifiers re-bind to the fresh interface
        bpy.data.node_groups.remove(old)
    ng = bpy.data.node_groups.new(GROUP_NAME, 'GeometryNodeTree')

    iface = ng.interface
    iface.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    iface.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    iface.new_socket("Source", in_out='INPUT', socket_type='NodeSocketObject')
    s = iface.new_socket("Method", in_out='INPUT', socket_type='NodeSocketInt')
    s.default_value, s.min_value, s.max_value = 0, 0, 2
    s = iface.new_socket("Strength", in_out='INPUT', socket_type='NodeSocketFloat')
    s.default_value, s.min_value, s.max_value = 1.0, 0.0, 1.0
    s = iface.new_socket("Max Distance", in_out='INPUT', socket_type='NodeSocketFloat')
    s.default_value, s.min_value = 0.0, 0.0
    s = iface.new_socket("Direction", in_out='INPUT', socket_type='NodeSocketVector')
    s.default_value = (0.0, 0.0, -1.0)
    s = iface.new_socket("Both Ways", in_out='INPUT', socket_type='NodeSocketBool')
    s.default_value = True
    iface.new_socket("Vertex Group", in_out='INPUT', socket_type='NodeSocketString')
    iface.new_socket("Use Set", in_out='INPUT', socket_type='NodeSocketBool')
    iface.new_socket("Set Attribute", in_out='INPUT', socket_type='NodeSocketString')
    s = iface.new_socket("Smooth Border", in_out='INPUT', socket_type='NodeSocketBool')
    s.default_value = True

    nodes, links = ng.nodes, ng.links

    def N(idname, x, y, **props):
        n = nodes.new(idname)
        n.location = (x, y)
        for k, v in props.items():
            setattr(n, k, v)
        return n

    def L(a, b):
        links.new(a, b)

    gin = N('NodeGroupInput', -2300, 0)
    gout = N('NodeGroupOutput', 2500, 0)

    # ------------------------------------------------------------------
    # Which corners may be written?  (mesh selection + mark sharp)
    # ------------------------------------------------------------------
    set_attr = N('GeometryNodeInputNamedAttribute', -2000, 900, data_type='BOOLEAN')
    L(_out(gin, "Set Attribute"), _inp(set_attr, "Name"))

    # Strict: a corner is written only when its own face is in the stored set.
    # Smooth Border: a corner is written when ANY face of the same fan touches
    # its vertex. Fans are split by Mark Sharp edges, so the other side of a
    # sharp edge is never touched.
    sharp = N('GeometryNodeInputNamedAttribute', -2000, 700, data_type='BOOLEAN')
    _inp(sharp, "Name").default_value = "sharp_edge"
    split = N('GeometryNodeSplitEdges', -1750, 700)
    L(_out(gin, "Geometry"), _inp(split, "Mesh"))
    L(_out(sharp, "Attribute"), _inp(split, "Selection"))

    set_f = N('GeometryNodeFieldOnDomain', -1750, 900, domain='FACE', data_type='FLOAT')
    set_p = N('GeometryNodeFieldOnDomain', -1550, 900, domain='POINT', data_type='FLOAT')
    L(_out(set_attr, "Attribute"), _inp(set_f, "Value"))
    L(_out(set_f, "Value"), _inp(set_p, "Value"))
    any_set = N('FunctionNodeCompare', -1350, 900, data_type='FLOAT', operation='GREATER_THAN')
    L(_out(set_p, "Value"), _inp(any_set, "A"))
    _inp(any_set, "B").default_value = 0.0001

    corner_idx = N('GeometryNodeInputIndex', -1350, 700)
    fan_sample = N('GeometryNodeSampleIndex', -1150, 800, data_type='BOOLEAN', domain='CORNER')
    fan_sample.clamp = True
    L(_out(split, "Mesh"), _inp(fan_sample, "Geometry"))
    L(_out(any_set, "Result"), _inp(fan_sample, "Value"))
    L(_out(corner_idx, "Index"), _inp(fan_sample, "Index"))

    border_sw = N('GeometryNodeSwitch', -950, 900, input_type='BOOLEAN')
    L(_out(gin, "Smooth Border"), _inp(border_sw, "Switch"))
    L(_out(set_attr, "Attribute"), _inp(border_sw, "False"))
    L(_out(fan_sample, "Value"), _inp(border_sw, "True"))
    use_sw = N('GeometryNodeSwitch', -750, 900, input_type='BOOLEAN')   # no set -> everything
    L(_out(gin, "Use Set"), _inp(use_sw, "Switch"))
    _inp(use_sw, "False").default_value = True
    L(_out(border_sw, "Output"), _inp(use_sw, "True"))
    sel_f = N('GeometryNodeSwitch', -550, 900, input_type='FLOAT')
    L(_out(use_sw, "Output"), _inp(sel_f, "Switch"))
    _inp(sel_f, "False").default_value = 0.0
    _inp(sel_f, "True").default_value = 1.0

    # faces that get written must be smooth shaded or Blender ignores the
    # custom normals; do it here instead of editing the mesh
    face_sel = N('GeometryNodeSwitch', -750, 1100, input_type='BOOLEAN')
    L(_out(gin, "Use Set"), _inp(face_sel, "Switch"))
    _inp(face_sel, "False").default_value = True
    L(_out(set_attr, "Attribute"), _inp(face_sel, "True"))
    smooth = N('GeometryNodeSetShadeSmooth', -500, 1100, domain='FACE')
    L(_out(gin, "Geometry"), _inp(smooth, "Mesh"))
    L(_out(face_sel, "Output"), _inp(smooth, "Selection"))
    _inp(smooth, "Shade Smooth").default_value = True

    # ------------------------------------------------------------------
    # Source geometry, expressed in the TARGET's local space
    # ------------------------------------------------------------------
    info = N('GeometryNodeObjectInfo', -2000, 300, transform_space='RELATIVE')
    L(_out(gin, "Source"), _inp(info, "Object"))
    src_geo = _out(info, "Geometry")

    pos = N('GeometryNodeInputPosition', -2000, 0)           # target-side position
    cur = N('GeometryNodeInputNormal', -2000, -150)          # normal arriving from above
    src_normal = N('GeometryNodeInputNormal', -2000, -300)   # evaluated on the SOURCE
    src_pos = N('GeometryNodeInputPosition', -2000, -450)    # evaluated on the SOURCE

    max_dist_on = N('FunctionNodeCompare', -2000, -600, data_type='FLOAT', operation='GREATER_THAN')
    L(_out(gin, "Max Distance"), _inp(max_dist_on, "A"))
    _inp(max_dist_on, "B").default_value = 0.0

    # ---- method 0: nearest surface -----------------------------------
    snn = N('GeometryNodeSampleNearestSurface', -1650, 250, data_type='FLOAT_VECTOR')
    L(src_geo, _inp(snn, "Mesh"))
    L(_out(src_normal, "Normal"), _inp(snn, "Value"))
    L(_out(pos, "Position"), _inp(snn, "Sample Position"))
    snp = N('GeometryNodeSampleNearestSurface', -1650, 0, data_type='FLOAT_VECTOR')
    L(src_geo, _inp(snp, "Mesh"))
    L(_out(src_pos, "Position"), _inp(snp, "Value"))
    L(_out(pos, "Position"), _inp(snp, "Sample Position"))
    dist = N('ShaderNodeVectorMath', -1400, 0, operation='DISTANCE')
    L(_out(snp, "Value"), dist.inputs[0])
    L(_out(pos, "Position"), dist.inputs[1])
    within = N('FunctionNodeCompare', -1200, 0, data_type='FLOAT', operation='LESS_EQUAL')
    L(_out(dist, "Value"), _inp(within, "A"))
    L(_out(gin, "Max Distance"), _inp(within, "B"))
    unlimited = N('FunctionNodeBooleanMath', -1000, 0, operation='NOT')
    L(_out(max_dist_on, "Result"), unlimited.inputs[0])
    near_ok = N('FunctionNodeBooleanMath', -850, 0, operation='OR')
    L(_out(unlimited, "Boolean"), near_ok.inputs[0])
    L(_out(within, "Result"), near_ok.inputs[1])
    near_valid_n = N('FunctionNodeBooleanMath', -700, 0, operation='AND')
    L(_out(snn, "Is Valid"), near_valid_n.inputs[0])
    L(_out(near_ok, "Boolean"), near_valid_n.inputs[1])
    near_normal = _out(snn, "Value")
    near_valid = _out(near_valid_n, "Boolean")

    # ---- methods 1/2: raycast ----------------------------------------
    is_ray_normal = N('FunctionNodeCompare', -1650, -450, data_type='INT', operation='EQUAL')
    L(_out(gin, "Method"), _inp(is_ray_normal, "A"))
    _inp(is_ray_normal, "B").default_value = 1

    # direction for "Along Normal": the target's own geometry with custom
    # normals stripped, so it isn't bent by whatever is above this modifier
    clean_in = N('GeometryNodeSetMeshNormal', -2000, -750, mode='SHARPNESS')
    _inp(clean_in, "Remove Custom").default_value = True
    L(_out(gin, "Geometry"), _inp(clean_in, "Mesh"))
    point_normal = N('GeometryNodeInputNormal', -2000, -900)
    pn_sample = N('GeometryNodeSampleIndex', -1750, -750, data_type='FLOAT_VECTOR', domain='CORNER')
    pn_sample.clamp = True
    L(_out(clean_in, "Mesh"), _inp(pn_sample, "Geometry"))
    L(_out(point_normal, "Normal"), _inp(pn_sample, "Value"))
    L(_out(corner_idx, "Index"), _inp(pn_sample, "Index"))

    dir_norm = N('ShaderNodeVectorMath', -1750, -950, operation='NORMALIZE')
    L(_out(gin, "Direction"), dir_norm.inputs[0])
    ray_dir_sw = N('GeometryNodeSwitch', -1500, -750, input_type='VECTOR')
    L(_out(is_ray_normal, "Result"), _inp(ray_dir_sw, "Switch"))
    L(_out(dir_norm, "Vector"), _inp(ray_dir_sw, "False"))
    L(_out(pn_sample, "Value"), _inp(ray_dir_sw, "True"))
    ray_dir = _out(ray_dir_sw, "Output")
    ray_dir_back = N('ShaderNodeVectorMath', -1300, -850, operation='SCALE')
    L(ray_dir, ray_dir_back.inputs[0])
    _inp(ray_dir_back, "Scale").default_value = -1.0

    ray_len = N('GeometryNodeSwitch', -1300, -1050, input_type='FLOAT')
    L(_out(max_dist_on, "Result"), _inp(ray_len, "Switch"))
    _inp(ray_len, "False").default_value = 10000.0
    L(_out(gin, "Max Distance"), _inp(ray_len, "True"))

    def raycast(x, y, direction):
        rc = N('GeometryNodeRaycast', x, y, data_type='FLOAT_VECTOR')
        L(src_geo, _inp(rc, "Target Geometry"))
        L(_out(src_normal, "Normal"), _inp(rc, "Attribute"))
        L(_out(pos, "Position"), _inp(rc, "Source Position"))
        L(direction, _inp(rc, "Ray Direction"))
        L(_out(ray_len, "Output"), _inp(rc, "Ray Length"))
        return rc

    rc_fwd = raycast(-1050, -700, ray_dir)
    rc_back = raycast(-1050, -1000, _out(ray_dir_back, "Vector"))

    two_way = N('FunctionNodeBooleanMath', -850, -1150, operation='OR')
    L(_out(gin, "Both Ways"), two_way.inputs[0])
    L(_out(is_ray_normal, "Result"), two_way.inputs[1])
    back_hit = N('FunctionNodeBooleanMath', -650, -1150, operation='AND')
    L(_out(rc_back, "Is Hit"), back_hit.inputs[0])
    L(_out(two_way, "Boolean"), back_hit.inputs[1])

    back_closer = N('FunctionNodeCompare', -850, -900, data_type='FLOAT', operation='LESS_THAN')
    L(_out(rc_back, "Hit Distance"), _inp(back_closer, "A"))
    L(_out(rc_fwd, "Hit Distance"), _inp(back_closer, "B"))
    fwd_missed = N('FunctionNodeBooleanMath', -850, -750, operation='NOT')
    L(_out(rc_fwd, "Is Hit"), fwd_missed.inputs[0])
    prefer_back = N('FunctionNodeBooleanMath', -650, -900, operation='OR')
    L(_out(fwd_missed, "Boolean"), prefer_back.inputs[0])
    L(_out(back_closer, "Result"), prefer_back.inputs[1])
    use_back = N('FunctionNodeBooleanMath', -450, -900, operation='AND')
    L(_out(back_hit, "Boolean"), use_back.inputs[0])
    L(_out(prefer_back, "Boolean"), use_back.inputs[1])
    ray_normal_sw = N('GeometryNodeSwitch', -250, -800, input_type='VECTOR')
    L(_out(use_back, "Boolean"), _inp(ray_normal_sw, "Switch"))
    L(_out(rc_fwd, "Attribute"), _inp(ray_normal_sw, "False"))
    L(_out(rc_back, "Attribute"), _inp(ray_normal_sw, "True"))
    ray_valid = N('FunctionNodeBooleanMath', -250, -1000, operation='OR')
    L(_out(rc_fwd, "Is Hit"), ray_valid.inputs[0])
    L(_out(back_hit, "Boolean"), ray_valid.inputs[1])

    # ---- pick by method ----------------------------------------------
    is_nearest = N('FunctionNodeCompare', 0, -300, data_type='INT', operation='EQUAL')
    L(_out(gin, "Method"), _inp(is_nearest, "A"))
    _inp(is_nearest, "B").default_value = 0
    sel_normal = N('GeometryNodeSwitch', 250, -300, input_type='VECTOR')
    L(_out(is_nearest, "Result"), _inp(sel_normal, "Switch"))
    L(_out(ray_normal_sw, "Output"), _inp(sel_normal, "False"))
    L(near_normal, _inp(sel_normal, "True"))
    sel_valid = N('GeometryNodeSwitch', 250, -500, input_type='BOOLEAN')
    L(_out(is_nearest, "Result"), _inp(sel_valid, "Switch"))
    L(_out(ray_valid, "Boolean"), _inp(sel_valid, "False"))
    L(near_valid, _inp(sel_valid, "True"))

    # ---- weight = strength * vertex group * hit-valid * mesh selection ---
    vg = N('GeometryNodeInputNamedAttribute', 0, 300, data_type='FLOAT')
    L(_out(gin, "Vertex Group"), _inp(vg, "Name"))
    mask = N('GeometryNodeSwitch', 250, 300, input_type='FLOAT')       # no group -> 1.0
    L(_out(vg, "Exists"), _inp(mask, "Switch"))
    _inp(mask, "False").default_value = 1.0
    L(_out(vg, "Attribute"), _inp(mask, "True"))
    valid_f = N('GeometryNodeSwitch', 500, -500, input_type='FLOAT')
    L(_out(sel_valid, "Output"), _inp(valid_f, "Switch"))
    _inp(valid_f, "False").default_value = 0.0
    _inp(valid_f, "True").default_value = 1.0
    w1 = N('ShaderNodeMath', 500, 200, operation='MULTIPLY')
    L(_out(gin, "Strength"), w1.inputs[0])
    L(_out(mask, "Output"), w1.inputs[1])
    w2 = N('ShaderNodeMath', 700, 100, operation='MULTIPLY')
    L(_out(w1, "Value"), w2.inputs[0])
    L(_out(valid_f, "Output"), w2.inputs[1])
    w3 = N('ShaderNodeMath', 900, 0, operation='MULTIPLY')
    L(_out(w2, "Value"), w3.inputs[0])
    L(_out(sel_f, "Output"), w3.inputs[1])

    mix = N('ShaderNodeMix', 1100, 0, data_type='VECTOR')
    L(_out(w3, "Value"), _inp(mix, "Factor"))
    L(_out(cur, "Normal"), _inp(mix, "A"))
    L(_out(sel_normal, "Output"), _inp(mix, "B"))
    result = N('ShaderNodeVectorMath', 1300, 0, operation='NORMALIZE')
    L(_out(mix, "Result"), result.inputs[0])

    setn = N('GeometryNodeSetMeshNormal', 1700, 0, mode='FREE', domain='CORNER')
    L(_out(smooth, "Mesh"), _inp(setn, "Mesh"))
    L(_out(result, "Vector"), _inp(setn, "Custom Normal"))
    L(_out(setn, "Mesh"), _inp(gout, "Geometry"))

    ng["ntr_version"] = GROUP_VERSION
    return ng


def _get_group():
    ng = bpy.data.node_groups.get(GROUP_NAME)
    if ng is None or ng.get("ntr_version") != GROUP_VERSION:
        ng = _build_group()
    return ng


def _group_ids(ng):
    return {
        it.name: it.identifier
        for it in ng.interface.items_tree
        if it.item_type == 'SOCKET' and it.in_out == 'INPUT'
    }


# ----------------------------------------------------------------------------
# Sync logic (properties -> modifiers)
# ----------------------------------------------------------------------------

_suspend = 0     # >0: property update callbacks do nothing (used while populating entries)


def _sync_source(ob, t, s, create):
    modname = s.modname
    mod = ob.modifiers.get(modname)

    if not (t.enabled and s.enabled):
        if mod is not None:
            ob.modifiers.remove(mod)
        return

    if mod is None:
        if not create:
            return
        mod = ob.modifiers.new(modname, 'NODES')
        mod.show_expanded = False
        mod.show_on_cage = False

    ng = _get_group()
    if mod.node_group != ng:
        mod.node_group = ng
    if hasattr(mod, "use_pin_to_last") and not mod.use_pin_to_last:
        mod.use_pin_to_last = True

    ids = _group_ids(ng)
    ok = bool(s.source is not None and s.source.type == 'MESH' and s.source != ob)

    vg = s.vertex_group if s.vertex_group in ob.vertex_groups else ""

    changed = False
    if s.source is not None:
        changed |= _set(mod, ids["Source"], s.source)
    changed |= _set(mod, ids["Method"], METHOD_INDEX[s.method])
    changed |= _set(mod, ids["Strength"], float(s.strength))
    changed |= _set(mod, ids["Max Distance"], float(s.max_distance))
    changed |= _set(mod, ids["Direction"], tuple(s.direction))
    changed |= _set(mod, ids["Both Ways"], bool(s.both_ways))
    changed |= _set(mod, ids["Vertex Group"], vg)
    changed |= _set(mod, ids["Use Set"], bool(t.use_set))
    changed |= _set(mod, ids["Set Attribute"], t.set_attr)
    changed |= _set(mod, ids["Smooth Border"], bool(t.smooth_border))

    # Never let the modifier run without a source
    if mod.show_viewport != ok:
        mod.show_viewport = ok
    if mod.show_render != ok:
        mod.show_render = ok

    if changed:
        ob.update_tag()


def _all_modnames(ob):
    return [s.modname for t in ob.ntr_transfers for s in t.sources]


def _enforce_order(ob):
    """Our modifiers: in list order, at the very end (below 'CN Normals'), so transfers win."""
    mine = [ob.modifiers.get(n) for n in _all_modnames(ob)]
    mine = [m for m in mine if m is not None]
    if not mine:
        return
    mine_names = [m.name for m in mine]
    current = [m.name for m in ob.modifiers]
    others = [n for n in current if n not in mine_names]
    desired = others + mine_names
    if current == desired:
        return
    for target, name in enumerate(desired):
        names = [m.name for m in ob.modifiers]
        cur = names.index(name)
        if cur == target:
            continue
        try:
            if hasattr(ob.modifiers, "move"):
                ob.modifiers.move(cur, target)
            else:
                with bpy.context.temp_override(object=ob, active_object=ob):
                    bpy.ops.object.modifier_move_to_index(modifier=name, index=target)
        except Exception:
            pass


def _remove_orphans(ob):
    keep = set(_all_modnames(ob))
    for m in list(ob.modifiers):
        if m.type == 'NODES' and m.name.startswith(MOD_PREFIX) and m.name not in keep:
            ob.modifiers.remove(m)


def sync_object(ob, create=True):
    if ob is None or ob.type != 'MESH':
        return
    _remove_orphans(ob)
    for t in ob.ntr_transfers:
        for s in t.sources:
            _sync_source(ob, t, s, create)
    _enforce_order(ob)


# ----------------------------------------------------------------------------
# List helpers
# ----------------------------------------------------------------------------

def _new_source(ob, t, copy_from=None, source=None):
    global _suspend
    _suspend += 1
    try:
        ob.ntr_counter += 1
        s = t.sources.add()
        s.modname = "%sSource %d" % (MOD_PREFIX, ob.ntr_counter)
        if copy_from is not None:
            s.method = copy_from.method
            s.strength = copy_from.strength
            s.max_distance = copy_from.max_distance
            s.direction = copy_from.direction
            s.both_ways = copy_from.both_ways
        if source is not None:
            s.source = source
    finally:
        _suspend -= 1
    return s


def _new_transfer(ob, name="", sources=()):
    global _suspend
    _suspend += 1
    try:
        ob.ntr_counter += 1
        t = ob.ntr_transfers.add()
        t.set_attr = "ntr_set_%d" % ob.ntr_counter
        t.name = name or ("Transfer %d" % ob.ntr_counter)
    finally:
        _suspend -= 1
    if sources:
        for src in sources:
            _new_source(ob, t, source=src)
    else:
        _new_source(ob, t)
    return t


_busy = False


def _has_work(ob):
    return len(ob.ntr_transfers) > 0


@persistent
def _on_depsgraph(scene, depsgraph):
    global _busy
    if _busy:
        return
    _busy = True
    try:
        for upd in depsgraph.updates:
            idb = upd.id
            if not isinstance(idb, bpy.types.Object):
                continue
            ob = idb.original
            if ob.type != 'MESH' or not _has_work(ob):
                continue
            sync_object(ob, create=False)
    except Exception:
        pass
    finally:
        _busy = False


# ----------------------------------------------------------------------------
# Properties
# ----------------------------------------------------------------------------

def _on_change(self, context):
    if _suspend:
        return
    ob = self.id_data
    if isinstance(ob, bpy.types.Object):
        sync_object(ob, create=True)


def _source_poll(self, obj):
    return obj.type == 'MESH' and obj != self.id_data


class NTR_Source(bpy.types.PropertyGroup):
    """One source mesh. Becomes one modifier."""
    modname: StringProperty(default="")
    enabled: BoolProperty(name="Enabled", default=True, update=_on_change)
    source: PointerProperty(
        name="Source", type=bpy.types.Object, poll=_source_poll, update=_on_change,
        description="Mesh to read the normals from")
    method: EnumProperty(
        name="Method", items=METHOD_ITEMS, default='NEAREST', update=_on_change,
        description="How the matching point on the source is found")
    strength: FloatProperty(
        name="Strength", min=0.0, max=1.0, default=1.0, subtype='FACTOR', update=_on_change,
        description="Blend between the normals already there (0) and the transferred ones (1)")
    max_distance: FloatProperty(
        name="Max Distance", min=0.0, default=0.0, subtype='DISTANCE', update=_on_change,
        description="Ignore source points further away than this (0 = unlimited)")
    direction: FloatVectorProperty(
        name="Direction", size=3, default=(0.0, 0.0, -1.0), subtype='XYZ', update=_on_change,
        description="Ray direction in this object's local space")
    both_ways: BoolProperty(
        name="Both Ways", default=True, update=_on_change,
        description="Also cast the ray the opposite way and use whichever hit is closer")
    vertex_group: StringProperty(
        name="Falloff", default="", update=_on_change,
        description="Optional vertex group that scales the strength per vertex. "
                    "Use the mesh selection to keep a transfer from crossing sharp edges")


class NTR_Transfer(bpy.types.PropertyGroup):
    """One face set with any number of source meshes on it."""
    name: StringProperty(name="Name", default="Transfer")
    set_attr: StringProperty(default="")
    enabled: BoolProperty(
        name="Enabled", default=True, update=_on_change,
        description="Keep this transfer active (modifiers pinned to the bottom of the stack)")
    sources: CollectionProperty(type=NTR_Source)
    use_set: BoolProperty(
        name="Limit to Mesh Selection", default=False, update=_on_change,
        description="Only write normals on the faces stored with 'Apply Selection'")
    smooth_border: BoolProperty(
        name="Smooth Border", default=True, update=_on_change,
        description="Also blend the faces touching the selection (up to the nearest Mark Sharp "
                    "edge) so the border doesn't show. Off: write only the stored faces")


# ----------------------------------------------------------------------------
# Operators
# ----------------------------------------------------------------------------

def _entry(ob, index):
    if ob is None or not (0 <= index < len(ob.ntr_transfers)):
        return None
    return ob.ntr_transfers[index]


def _src(ob, index, src_index):
    t = _entry(ob, index)
    if t is None or not (0 <= src_index < len(t.sources)):
        return t, None
    return t, t.sources[src_index]


def _drop_set_attribute(ob, name):
    if not name:
        return
    me = ob.data
    try:
        if ob.mode == 'EDIT':
            bm = bmesh.from_edit_mesh(me)
            layer = bm.faces.layers.bool.get(name)
            if layer is not None:
                bm.faces.layers.bool.remove(layer)
        else:
            a = me.attributes.get(name)
            if a is not None:
                me.attributes.remove(a)
    except Exception:
        pass


class NTR_OT_add(bpy.types.Operator):
    bl_idname = "object.ntr_add"
    bl_label = "Add Transfer"
    bl_description = ("Add a normal transfer (its own face selection). Other selected meshes "
                      "become its sources; with none selected you pick the source in the panel")
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        ob = context.active_object
        if ob is None or ob.type != 'MESH':
            return {'CANCELLED'}
        others = [o for o in context.selected_objects if o != ob and o.type == 'MESH']
        _new_transfer(ob, sources=others)
        sync_object(ob, create=True)
        if others:
            self.report({'INFO'}, "Added a transfer with %d source%s"
                        % (len(others), "" if len(others) == 1 else "s"))
        return {'FINISHED'}


class NTR_OT_remove(bpy.types.Operator):
    bl_idname = "object.ntr_remove"
    bl_label = "Remove Transfer"
    bl_description = "Remove this transfer, all its modifiers and its stored mesh selection"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        t = _entry(ob, self.index)
        if t is None:
            return {'CANCELLED'}
        for s in t.sources:
            mod = ob.modifiers.get(s.modname)
            if mod is not None:
                ob.modifiers.remove(mod)
        _drop_set_attribute(ob, t.set_attr)
        ob.ntr_transfers.remove(self.index)
        sync_object(ob, create=True)
        return {'FINISHED'}


class NTR_OT_source_add(bpy.types.Operator):
    bl_idname = "object.ntr_source_add"
    bl_label = "Add Source"
    bl_description = ("Add another source mesh to this transfer. It uses the same face selection; "
                      "later sources blend over earlier ones")
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        t = _entry(ob, self.index)
        if t is None:
            return {'CANCELLED'}
        prev = t.sources[-1] if len(t.sources) else None
        _new_source(ob, t, copy_from=prev)
        sync_object(ob, create=True)
        return {'FINISHED'}


class NTR_OT_source_remove(bpy.types.Operator):
    bl_idname = "object.ntr_source_remove"
    bl_label = "Remove Source"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()
    src_index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        t, s = _src(ob, self.index, self.src_index)
        if s is None:
            return {'CANCELLED'}
        mod = ob.modifiers.get(s.modname)
        if mod is not None:
            ob.modifiers.remove(mod)
        t.sources.remove(self.src_index)
        sync_object(ob, create=True)
        return {'FINISHED'}


class NTR_OT_source_move(bpy.types.Operator):
    bl_idname = "object.ntr_source_move"
    bl_label = "Move Source"
    bl_description = "Change the order (later sources blend over earlier ones)"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()
    src_index: IntProperty()
    direction: IntProperty(default=-1)

    def execute(self, context):
        ob = context.active_object
        t, s = _src(ob, self.index, self.src_index)
        if s is None:
            return {'CANCELLED'}
        new = self.src_index + self.direction
        if not (0 <= new < len(t.sources)):
            return {'CANCELLED'}
        t.sources.move(self.src_index, new)
        sync_object(ob, create=True)
        return {'FINISHED'}


class NTR_OT_pick_source(bpy.types.Operator):
    bl_idname = "object.ntr_pick_source"
    bl_label = "Use Selected Object as Source"
    bl_description = ("Select the source mesh, then make the target object active "
                      "(Ctrl+click) and press this")
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()
    src_index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        others = [o for o in context.selected_objects if o != ob and o.type == 'MESH']
        t, s = _src(ob, self.index, self.src_index)
        if s is None or len(others) != 1:
            self.report({'ERROR'}, "Select exactly one source mesh plus the active target object")
            return {'CANCELLED'}
        s.source = others[0]
        return {'FINISHED'}


class NTR_OT_set_assign(bpy.types.Operator):
    bl_idname = "object.ntr_set_assign"
    bl_label = "Apply Selection"
    bl_description = ("Store the faces currently selected in Edit Mode as this transfer's face set "
                      "(replaces the previous set) and turn the selection filter on")
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and ob.mode == 'EDIT'

    def execute(self, context):
        ob = context.active_object
        t = _entry(ob, self.index)
        if t is None:
            return {'CANCELLED'}
        bm = bmesh.from_edit_mesh(ob.data)
        count = sum(1 for f in bm.faces if f.select)
        if count == 0:
            self.report({'WARNING'}, "No faces selected")
            return {'CANCELLED'}
        layer = bm.faces.layers.bool.get(t.set_attr)
        if layer is None:
            layer = bm.faces.layers.bool.new(t.set_attr)
        for f in bm.faces:
            f[layer] = f.select
        bmesh.update_edit_mesh(ob.data, loop_triangles=False, destructive=False)

        t.use_set = True    # triggers a sync
        self.report({'INFO'}, "Stored %d face%s" % (count, "" if count == 1 else "s"))
        return {'FINISHED'}


class NTR_OT_set_select(bpy.types.Operator):
    bl_idname = "object.ntr_set_select"
    bl_label = "Get Selection"
    bl_description = "Replace the Edit Mode selection with this transfer's stored faces"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and ob.mode == 'EDIT'

    def execute(self, context):
        ob = context.active_object
        t = _entry(ob, self.index)
        if t is None:
            return {'CANCELLED'}
        bm = bmesh.from_edit_mesh(ob.data)
        layer = bm.faces.layers.bool.get(t.set_attr)
        if layer is None:
            self.report({'WARNING'}, "Nothing applied for this transfer yet")
            return {'CANCELLED'}
        # explicit vert/edge/face flags: select_flush alone can leave the
        # highlight incomplete in vertex/edge select mode
        for v in bm.verts:
            v.select_set(False)
        for e in bm.edges:
            e.select_set(False)
        for f in bm.faces:
            f.select_set(False)
        count = 0
        for f in bm.faces:
            if f[layer]:
                f.select_set(True)
                count += 1
        bm.select_flush_mode()
        bmesh.update_edit_mesh(ob.data, loop_triangles=False, destructive=False)
        self.report({'INFO'}, "Selected %d face%s" % (count, "" if count == 1 else "s"))
        return {'FINISHED'}


class NTR_OT_refresh(bpy.types.Operator):
    bl_idname = "object.ntr_refresh"
    bl_label = "Refresh Normal Transfer"
    bl_description = "Rebuild missing modifiers and re-apply the stack order"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        sync_object(context.active_object, create=True)
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------------

class VIEW3D_PT_normal_transfer(bpy.types.Panel):
    bl_label = "Normal Transfer"
    bl_idname = "VIEW3D_PT_normal_transfer"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_vehicle"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH'

    def draw(self, context):
        ob = context.active_object
        layout = self.layout
        editing = ob.mode == 'EDIT'

        for i, t in enumerate(ob.ntr_transfers):
            box = layout.box()
            row = box.row(align=True)
            row.prop(t, "enabled", text="")
            row.prop(t, "name", text="")
            op = row.operator("object.ntr_remove", text="", icon='X')
            op.index = i
            if not t.enabled:
                continue

            # --- face filter (shared by every source of this transfer) ---
            box.prop(t, "use_set")
            if t.use_set:
                box.prop(t, "smooth_border")
            row = box.row(align=True)
            row.operator("object.ntr_set_assign", text="Apply Selection",
                         icon='CHECKMARK').index = i
            row.operator("object.ntr_set_select", text="Get Selection",
                         icon='RESTRICT_SELECT_OFF').index = i
            has_set = editing or t.set_attr in ob.data.attributes
            if not editing and not has_set:
                box.label(text="Enter Edit Mode, select faces, then Apply", icon='INFO')

            # --- sources ---
            for j, s in enumerate(t.sources):
                sub = box.box()
                row = sub.row(align=True)
                row.prop(s, "enabled", text="")
                row.prop(s, "source", text="")
                op = row.operator("object.ntr_pick_source", text="", icon='EYEDROPPER')
                op.index, op.src_index = i, j
                op = row.operator("object.ntr_source_move", text="", icon='TRIA_UP')
                op.index, op.src_index, op.direction = i, j, -1
                op = row.operator("object.ntr_source_move", text="", icon='TRIA_DOWN')
                op.index, op.src_index, op.direction = i, j, 1
                op = row.operator("object.ntr_source_remove", text="", icon='X')
                op.index, op.src_index = i, j
                if not s.enabled:
                    continue
                sub.row(align=True).prop(s, "method", expand=True)
                sub.prop(s, "strength", slider=True)
                sub.prop(s, "max_distance")
                if s.method == 'RAY_AXIS':
                    sub.prop(s, "direction", text="")
                    sub.prop(s, "both_ways")
                sub.prop_search(s, "vertex_group", ob, "vertex_groups", text="Falloff")

                if s.source is None:
                    sub.label(text="Pick a source mesh", icon='INFO')
                elif t.use_set and not has_set:
                    sub.label(text="No faces applied yet", icon='INFO')
                elif ob.modifiers.get(s.modname) is None:
                    sub.label(text="Modifier missing - press Refresh", icon='ERROR')

            box.operator("object.ntr_source_add", text="Add Source",
                         icon='ADD').index = i

        row = layout.row(align=True)
        row.operator("object.ntr_add", icon='ADD')
        row.operator("object.ntr_refresh", text="", icon='FILE_REFRESH')


# ----------------------------------------------------------------------------

classes = (
    NTR_Source,
    NTR_Transfer,
    NTR_OT_add,
    NTR_OT_remove,
    NTR_OT_source_add,
    NTR_OT_source_remove,
    NTR_OT_source_move,
    NTR_OT_pick_source,
    NTR_OT_set_assign,
    NTR_OT_set_select,
    NTR_OT_refresh,
    VIEW3D_PT_normal_transfer,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Object.ntr_transfers = CollectionProperty(type=NTR_Transfer)
    bpy.types.Object.ntr_counter = IntProperty(default=0, options={'HIDDEN'})
    if _on_depsgraph not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph)


def unregister():
    if _on_depsgraph in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph)
    del bpy.types.Object.ntr_counter
    del bpy.types.Object.ntr_transfers
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
