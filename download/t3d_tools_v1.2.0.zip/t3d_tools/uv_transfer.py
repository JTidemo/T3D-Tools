import bmesh
import bpy
from bpy.app.handlers import persistent
from bpy.props import (BoolProperty, CollectionProperty, EnumProperty, IntProperty,
                       PointerProperty, StringProperty)

GROUP_NAME = ".UVT_Transfer"   # leading dot hides it from most dropdowns
GROUP_VERSION = 3

MOD_PREFIX = "UVT "

# Old fixed transfers (pre-list versions). Kept registered only so existing files
# can be migrated into the new transfer list: (Object property, modifier name, label)
LEGACY = (
    ("uvt_dirt", "UVT Dirt", "Dirt Transfer"),
    ("uvt_dirt2", "UVT Dirt 2", "Dirt Transfer 2 (Paint)"),
    ("uvt_livery", "UVT Livery", "Livery Transfer"),
)

UV_ITEMS = (
    ("0", "UV1", "First UV map"),
    ("1", "UV2", "Second UV map"),
)


# ----------------------------------------------------------------------------
# Node group (built from code, shared by every modifier)
# ----------------------------------------------------------------------------

def _pick(sockets, name):
    """Dynamic-type nodes have several sockets with the same name; take the enabled one."""
    for s in sockets:
        if s.name == name and s.enabled:
            return s
    raise KeyError(name)


def _build_group():
    old = bpy.data.node_groups.get(GROUP_NAME)
    if old is not None:
        # Remove instead of clearing so modifiers re-bind to the fresh interface
        bpy.data.node_groups.remove(old)
    ng = bpy.data.node_groups.new(GROUP_NAME, 'GeometryNodeTree')

    iface = ng.interface
    iface.new_socket("Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    iface.new_socket("Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    iface.new_socket("Source", in_out='INPUT', socket_type='NodeSocketObject')
    iface.new_socket("Source UV", in_out='INPUT', socket_type='NodeSocketString')
    iface.new_socket("Target UV", in_out='INPUT', socket_type='NodeSocketString')
    iface.new_socket("Use Material", in_out='INPUT', socket_type='NodeSocketBool')
    iface.new_socket("Material Mask", in_out='INPUT', socket_type='NodeSocketInt')
    iface.new_socket("Use Set", in_out='INPUT', socket_type='NodeSocketBool')
    iface.new_socket("Set Attribute", in_out='INPUT', socket_type='NodeSocketString')

    n = ng.nodes
    link = ng.links.new

    gin = n.new('NodeGroupInput')
    gin.location = (-900, 0)
    gout = n.new('NodeGroupOutput')
    gout.location = (900, 0)

    objinfo = n.new('GeometryNodeObjectInfo')
    objinfo.transform_space = 'RELATIVE'
    objinfo.location = (-650, 200)

    attr = n.new('GeometryNodeInputNamedAttribute')
    attr.data_type = 'FLOAT_VECTOR'
    attr.location = (-650, 0)

    pos = n.new('GeometryNodeInputPosition')
    pos.location = (-650, -150)

    sample = n.new('GeometryNodeSampleNearestSurface')
    sample.data_type = 'FLOAT_VECTOR'
    # (this node has no domain setting; the corner domain follows from the UV attribute)
    sample.location = (-350, 100)

    # Material filter: bit i of "Material Mask" set -> material slot i is included.
    # bit = floor(mask / 2^slot) mod 2
    matidx = n.new('GeometryNodeInputMaterialIndex')
    matidx.location = (-900, -300)
    m_pow = n.new('ShaderNodeMath')
    m_pow.operation = 'POWER'
    m_pow.inputs[0].default_value = 2.0
    m_pow.location = (-700, -300)
    m_div = n.new('ShaderNodeMath')
    m_div.operation = 'DIVIDE'
    m_div.location = (-500, -300)
    m_floor = n.new('ShaderNodeMath')
    m_floor.operation = 'FLOOR'
    m_floor.location = (-350, -300)
    m_mod = n.new('ShaderNodeMath')
    m_mod.operation = 'MODULO'
    m_mod.inputs[1].default_value = 2.0
    m_mod.location = (-200, -300)

    not_use = n.new('FunctionNodeBooleanMath')
    not_use.operation = 'NOT'
    not_use.location = (-650, -450)

    or_node = n.new('FunctionNodeBooleanMath')
    or_node.operation = 'OR'
    or_node.location = (-350, -350)

    # Mesh-selection filter: (NOT use set) OR (face is in the stored set)
    set_attr = n.new('GeometryNodeInputNamedAttribute')
    set_attr.data_type = 'BOOLEAN'
    set_attr.location = (-650, -650)

    not_set = n.new('FunctionNodeBooleanMath')
    not_set.operation = 'NOT'
    not_set.location = (-650, -800)

    or_set = n.new('FunctionNodeBooleanMath')
    or_set.operation = 'OR'
    or_set.location = (-350, -700)

    and_node = n.new('FunctionNodeBooleanMath')
    and_node.operation = 'AND'
    and_node.location = (100, -400)

    store = n.new('GeometryNodeStoreNamedAttribute')
    store.data_type = 'FLOAT2'
    store.domain = 'CORNER'
    store.location = (500, 0)

    # Source geometry -> sampler
    link(gin.outputs["Source"], objinfo.inputs["Object"])
    link(objinfo.outputs["Geometry"], _pick(sample.inputs, "Mesh"))
    link(gin.outputs["Source UV"], attr.inputs["Name"])
    link(_pick(attr.outputs, "Attribute"), _pick(sample.inputs, "Value"))
    link(pos.outputs["Position"], _pick(sample.inputs, "Sample Position"))

    # Material filter: (NOT use) OR in-material
    link(matidx.outputs["Material Index"], m_pow.inputs[1])
    link(gin.outputs["Material Mask"], m_div.inputs[0])
    link(m_pow.outputs[0], m_div.inputs[1])
    link(m_div.outputs[0], m_floor.inputs[0])
    link(m_floor.outputs[0], m_mod.inputs[0])
    link(gin.outputs["Use Material"], not_use.inputs[0])
    link(not_use.outputs[0], or_node.inputs[0])
    link(m_mod.outputs[0], or_node.inputs[1])

    # Set filter: (NOT use set) OR in-set
    link(gin.outputs["Set Attribute"], set_attr.inputs["Name"])
    link(gin.outputs["Use Set"], not_set.inputs[0])
    link(not_set.outputs[0], or_set.inputs[0])
    link(_pick(set_attr.outputs, "Attribute"), or_set.inputs[1])

    # Both filters must pass
    link(or_node.outputs[0], and_node.inputs[0])
    link(or_set.outputs[0], and_node.inputs[1])

    # Write result
    link(gin.outputs["Geometry"], _pick(store.inputs, "Geometry"))
    link(and_node.outputs[0], _pick(store.inputs, "Selection"))
    link(gin.outputs["Target UV"], _pick(store.inputs, "Name"))
    link(_pick(sample.outputs, "Value"), _pick(store.inputs, "Value"))
    link(_pick(store.outputs, "Geometry"), gout.inputs["Geometry"])

    ng["uvt_version"] = GROUP_VERSION
    return ng


def _get_group():
    ng = bpy.data.node_groups.get(GROUP_NAME)
    if ng is None or ng.get("uvt_version") != GROUP_VERSION:
        ng = _build_group()
    return ng


def _group_ids(ng):
    return {
        it.name: it.identifier
        for it in ng.interface.items_tree
        if it.item_type == 'SOCKET' and it.in_out == 'INPUT'
    }


# ----------------------------------------------------------------------------
# Sync logic
# ----------------------------------------------------------------------------

_suspend = 0     # >0: property update callbacks do nothing (used while populating entries)


def _uv_name(ob, idx):
    if ob is not None and ob.type == 'MESH' and idx < len(ob.data.uv_layers):
        return ob.data.uv_layers[idx].name
    return ""


def _target_uv_name(ob, idx, create):
    uvs = ob.data.uv_layers
    if idx >= len(uvs) and create:
        try:
            while len(uvs) <= idx:
                uvs.new(name="UVMap")
        except Exception:
            pass
    return uvs[idx].name if idx < len(uvs) else ""


def _mod_get(mod, key):
    # Blender <= 5.1: mod[key]; Blender 5.2+: mod.properties.inputs[key]["value"]
    props = getattr(mod, "properties", None)
    if props is not None:
        return props.inputs[key]["value"]
    return mod[key]


def _mod_set(mod, key, value):
    props = getattr(mod, "properties", None)
    if props is not None:
        props.inputs[key]["value"] = value
    else:
        mod[key] = value


def _set(mod, key, value):
    try:
        cur = _mod_get(mod, key)
    except (KeyError, TypeError, AttributeError):
        cur = None
    if cur == value:
        return False
    _mod_set(mod, key, value)
    return True


def _sync_one(ob, t, m, create):
    """One map (plane + UV channel pair) of transfer t -> one modifier."""
    modname = m.modname
    mod = ob.modifiers.get(modname)

    if not (t.enabled and m.enabled):
        if mod is not None:
            ob.modifiers.remove(mod)
        return

    if mod is None:
        if not create:
            return
        mod = ob.modifiers.new(modname, 'NODES')
        mod.show_expanded = False

    ng = _get_group()
    if mod.node_group != ng:
        mod.node_group = ng
    if hasattr(mod, "use_pin_to_last") and not mod.use_pin_to_last:
        mod.use_pin_to_last = True

    ids = _group_ids(ng)
    src = m.source
    src_name = _uv_name(src, int(m.source_uv))
    dst_name = _target_uv_name(ob, int(m.target_uv), create)
    ok = bool(src and src_name and dst_name)

    changed = False
    if src is not None:
        changed |= _set(mod, ids["Source"], src)
    changed |= _set(mod, ids["Source UV"], src_name)
    changed |= _set(mod, ids["Target UV"], dst_name)
    changed |= _set(mod, ids["Use Material"], bool(t.use_material))
    names = {it.material.name for it in t.materials if it.material is not None}
    mask = 0
    for i, slot in enumerate(ob.material_slots):
        if i >= 24:
            break
        if slot.material is not None and slot.material.name in names:
            mask |= 1 << i
    changed |= _set(mod, ids["Material Mask"], mask)
    changed |= _set(mod, ids["Use Set"], bool(t.use_set))
    changed |= _set(mod, ids["Set Attribute"], t.set_attr)
    # No material picked while the filter is on -> nothing should be written
    if t.use_material and not names:
        ok = False

    # Never let the modifier run with a missing source/UV: it would write zeros.
    if mod.show_viewport != ok:
        mod.show_viewport = ok
    if mod.show_render != ok:
        mod.show_render = ok

    if changed:
        ob.update_tag()


def _all_modnames(ob):
    return [m.modname for t in ob.uvt_transfers for m in t.maps]


def _enforce_order(ob):
    """Fallback for Blender versions without 'Pin to Last'."""
    mods = [ob.modifiers.get(n) for n in _all_modnames(ob)]
    mods = [m for m in mods if m is not None]
    if not mods or hasattr(mods[0], "use_pin_to_last"):
        return
    total = len(ob.modifiers)
    for i, m in enumerate(mods):
        target = total - len(mods) + i
        names = [x.name for x in ob.modifiers]
        cur = names.index(m.name)
        if cur == target:
            continue
        try:
            if hasattr(ob.modifiers, "move"):
                ob.modifiers.move(cur, target)
            else:
                with bpy.context.temp_override(object=ob, active_object=ob):
                    bpy.ops.object.modifier_move_to_index(modifier=m.name, index=target)
        except Exception:
            pass


def _remove_orphans(ob):
    keep = set(_all_modnames(ob))
    for m in list(ob.modifiers):
        if m.type == 'NODES' and m.name.startswith(MOD_PREFIX) and m.name not in keep:
            ob.modifiers.remove(m)


def sync_object(ob, create=True):
    if ob is None or ob.type != 'MESH':
        return
    _migrate(ob)
    _remove_orphans(ob)
    for t in ob.uvt_transfers:
        for m in t.maps:
            _sync_one(ob, t, m, create)
    _enforce_order(ob)


# ----------------------------------------------------------------------------
# Transfer list helpers + migration of the old fixed transfers
# ----------------------------------------------------------------------------

def _new_map(ob, t, copy_from=None, modname=None):
    """Add a map (plane + UV pair) to transfer t without syncing per field."""
    global _suspend
    _suspend += 1
    try:
        ob.uvt_counter += 1
        m = t.maps.add()
        m.modname = modname or "%sTransfer %d" % (MOD_PREFIX, ob.uvt_counter)
        if copy_from is not None:
            m.source_uv = copy_from.source_uv
            m.target_uv = copy_from.target_uv
    finally:
        _suspend -= 1
    return m


def _new_transfer(ob, name=""):
    """Add a transfer (one selection set) that already holds one empty map."""
    global _suspend
    _suspend += 1
    try:
        ob.uvt_counter += 1
        t = ob.uvt_transfers.add()
        t.set_attr = "uvt_set_%d" % ob.uvt_counter
        t.name = name or ("Transfer %d" % ob.uvt_counter)
    finally:
        _suspend -= 1
    _new_map(ob, t)
    return t


def _migrate(ob):
    """Move enabled legacy transfers into the list, reusing their modifier."""
    global _suspend
    for attr, modname, label in LEGACY:
        old = getattr(ob, attr, None)
        if old is None or not old.enabled:
            continue
        _suspend += 1
        try:
            ob.uvt_counter += 1
            t = ob.uvt_transfers.add()
            t.set_attr = "uvt_set_%d" % ob.uvt_counter
            t.name = label
            t.use_material = old.use_material
            for it in old.materials:
                new = t.materials.add()
                new.material = it.material
            m = t.maps.add()
            m.modname = modname
            m.source = old.source
            m.source_uv = old.source_uv
            m.target_uv = old.target_uv
            old.enabled = False
        finally:
            _suspend -= 1


def _migrate_all():
    for ob in bpy.data.objects:
        if ob.type == 'MESH':
            try:
                _migrate(ob)
            except Exception:
                pass


_busy = False


def _has_work(ob):
    if len(ob.uvt_transfers):
        return True
    return any(getattr(ob, a).enabled for a, _m, _l in LEGACY)


@persistent
def _on_depsgraph(scene, depsgraph):
    global _busy
    if _busy:
        return
    _busy = True
    try:
        for upd in depsgraph.updates:
            idb = upd.id
            if not isinstance(idb, bpy.types.Object):
                continue
            ob = idb.original
            if ob.type != 'MESH' or not _has_work(ob):
                continue
            sync_object(ob, create=False)
    except Exception:
        pass
    finally:
        _busy = False


@persistent
def _on_load(_dummy):
    _migrate_all()


# ----------------------------------------------------------------------------
# Properties
# ----------------------------------------------------------------------------

def _on_change(self, context):
    if _suspend:
        return
    ob = self.id_data
    if isinstance(ob, bpy.types.Object):
        sync_object(ob, create=True)


def _source_poll(self, obj):
    return obj.type == 'MESH' and obj != self.id_data


class UVT_MaterialItem(bpy.types.PropertyGroup):
    material: PointerProperty(
        name="Material", type=bpy.types.Material, update=_on_change)


class UVT_Map(bpy.types.PropertyGroup):
    """One plane + From/To UV pair. Becomes one modifier."""
    modname: StringProperty(default="")
    enabled: BoolProperty(name="Enabled", default=True, update=_on_change)
    source: PointerProperty(
        name="Source", type=bpy.types.Object, poll=_source_poll, update=_on_change,
        description="Mapping plane to read UVs from")
    source_uv: EnumProperty(
        name="Source UV", items=UV_ITEMS, default="0", update=_on_change,
        description="UV map on the mapping plane")
    target_uv: EnumProperty(
        name="Target UV", items=UV_ITEMS, default="0", update=_on_change,
        description="UV map on this object that receives the result "
                    "(created if it does not exist yet)")


class UVT_Transfer(bpy.types.PropertyGroup):
    """One face set (selection and/or materials) with any number of maps on it."""
    name: StringProperty(name="Name", default="Transfer")
    set_attr: StringProperty(default="")
    enabled: BoolProperty(
        name="Enabled", default=True, update=_on_change,
        description="Keep this transfer active (modifiers pinned to the bottom of the stack)")
    maps: CollectionProperty(type=UVT_Map)
    use_material: BoolProperty(
        name="Limit to Materials", default=False, update=_on_change,
        description="Only write UVs on faces that use one of the listed materials")
    materials: CollectionProperty(type=UVT_MaterialItem)
    use_set: BoolProperty(
        name="Limit to Mesh Selection", default=False, update=_on_change,
        description="Only write UVs on the faces stored with 'Apply Selection' "
                    "(combined with the material filter if that is on too)")


# --- legacy groups: only used to read old files, no update callbacks ---------

class UVT_LegacyMaterial(bpy.types.PropertyGroup):
    material: PointerProperty(name="Material", type=bpy.types.Material)


class UVT_Settings(bpy.types.PropertyGroup):
    enabled: BoolProperty(name="Enabled", default=False)
    source: PointerProperty(name="Source", type=bpy.types.Object)
    source_uv: EnumProperty(name="Source UV", items=UV_ITEMS, default="0")
    target_uv: EnumProperty(name="Target UV", items=UV_ITEMS, default="0")
    use_material: BoolProperty(name="Limit to Materials", default=False)
    materials: CollectionProperty(type=UVT_LegacyMaterial)


class UVT_SettingsUV2(bpy.types.PropertyGroup):
    """Legacy: same as UVT_Settings, but From/To defaulted to UV2."""
    enabled: BoolProperty(name="Enabled", default=False)
    source: PointerProperty(name="Source", type=bpy.types.Object)
    source_uv: EnumProperty(name="Source UV", items=UV_ITEMS, default="1")
    target_uv: EnumProperty(name="Target UV", items=UV_ITEMS, default="1")
    use_material: BoolProperty(name="Limit to Materials", default=False)
    materials: CollectionProperty(type=UVT_LegacyMaterial)


# ----------------------------------------------------------------------------
# Operators
# ----------------------------------------------------------------------------

def _entry(ob, index):
    if ob is None or not (0 <= index < len(ob.uvt_transfers)):
        return None
    return ob.uvt_transfers[index]


def _map(ob, index, map_index):
    t = _entry(ob, index)
    if t is None or not (0 <= map_index < len(t.maps)):
        return None, None
    return t, t.maps[map_index]


def _drop_set_attribute(ob, name):
    if not name:
        return
    me = ob.data
    try:
        if ob.mode == 'EDIT':
            bm = bmesh.from_edit_mesh(me)
            layer = bm.faces.layers.bool.get(name)
            if layer is not None:
                bm.faces.layers.bool.remove(layer)
        else:
            a = me.attributes.get(name)
            if a is not None:
                me.attributes.remove(a)
    except Exception:
        pass


class UVT_OT_add(bpy.types.Operator):
    bl_idname = "object.uvt_add"
    bl_label = "Add Transfer"
    bl_description = "Add a new transfer (its own face selection / materials, with its own planes)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        ob = context.active_object
        if ob is None or ob.type != 'MESH':
            return {'CANCELLED'}
        _new_transfer(ob)
        sync_object(ob, create=True)
        return {'FINISHED'}


class UVT_OT_remove(bpy.types.Operator):
    bl_idname = "object.uvt_remove"
    bl_label = "Remove Transfer"
    bl_description = "Remove this transfer, all its modifiers and its stored mesh selection"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        t = _entry(ob, self.index)
        if t is None:
            return {'CANCELLED'}
        for m in t.maps:
            mod = ob.modifiers.get(m.modname)
            if mod is not None:
                ob.modifiers.remove(mod)
        _drop_set_attribute(ob, t.set_attr)
        ob.uvt_transfers.remove(self.index)
        sync_object(ob, create=True)
        return {'FINISHED'}


class UVT_OT_map_add(bpy.types.Operator):
    bl_idname = "object.uvt_map_add"
    bl_label = "Add Plane"
    bl_description = ("Add another plane / UV channel pair to this transfer. "
                      "It uses the same face selection and material filter")
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        t = _entry(ob, self.index)
        if t is None:
            return {'CANCELLED'}
        prev = t.maps[-1] if len(t.maps) else None
        _new_map(ob, t, copy_from=prev)
        sync_object(ob, create=True)
        return {'FINISHED'}


class UVT_OT_map_remove(bpy.types.Operator):
    bl_idname = "object.uvt_map_remove"
    bl_label = "Remove Plane"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()
    map_index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        t, m = _map(ob, self.index, self.map_index)
        if m is None:
            return {'CANCELLED'}
        mod = ob.modifiers.get(m.modname)
        if mod is not None:
            ob.modifiers.remove(mod)
        t.maps.remove(self.map_index)
        sync_object(ob, create=True)
        return {'FINISHED'}


class UVT_OT_pick_source(bpy.types.Operator):
    bl_idname = "object.uvt_pick_source"
    bl_label = "Use Selected Object as Source"
    bl_description = ("Select the mapping plane, then make the target object active "
                      "(Ctrl+click) and press this")
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()
    map_index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        others = [o for o in context.selected_objects if o != ob and o.type == 'MESH']
        t, m = _map(ob, self.index, self.map_index)
        if m is None or len(others) != 1:
            self.report({'ERROR'}, "Select exactly one mapping plane plus the active target object")
            return {'CANCELLED'}
        m.source = others[0]
        return {'FINISHED'}


class UVT_OT_material_add(bpy.types.Operator):
    bl_idname = "object.uvt_material_add"
    bl_label = "Add Material"
    bl_description = "Add a material to the list (starts with the active material slot)"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        s = _entry(ob, self.index)
        if s is None:
            return {'CANCELLED'}
        item = s.materials.add()
        used = {it.material for it in s.materials if it.material is not None}
        mat = ob.active_material
        if mat is not None and mat not in used:
            item.material = mat
        else:
            for slot in ob.material_slots:
                if slot.material is not None and slot.material not in used:
                    item.material = slot.material
                    break
        sync_object(ob, create=True)
        return {'FINISHED'}


class UVT_OT_material_remove(bpy.types.Operator):
    bl_idname = "object.uvt_material_remove"
    bl_label = "Remove Material"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()
    mat_index: IntProperty()

    def execute(self, context):
        ob = context.active_object
        s = _entry(ob, self.index)
        if s is None or not (0 <= self.mat_index < len(s.materials)):
            return {'CANCELLED'}
        s.materials.remove(self.mat_index)
        sync_object(ob, create=True)
        return {'FINISHED'}


class UVT_OT_set_assign(bpy.types.Operator):
    bl_idname = "object.uvt_set_assign"
    bl_label = "Apply Selection"
    bl_description = ("Store the faces currently selected in Edit Mode as this transfer's face set "
                      "(replaces the previous set) and turn the selection filter on")
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and ob.mode == 'EDIT'

    def execute(self, context):
        ob = context.active_object
        t = _entry(ob, self.index)
        if t is None:
            return {'CANCELLED'}
        bm = bmesh.from_edit_mesh(ob.data)
        count = sum(1 for f in bm.faces if f.select)
        if count == 0:
            self.report({'WARNING'}, "No faces selected")
            return {'CANCELLED'}
        layer = bm.faces.layers.bool.get(t.set_attr)
        if layer is None:
            layer = bm.faces.layers.bool.new(t.set_attr)
        for f in bm.faces:
            f[layer] = f.select
        bmesh.update_edit_mesh(ob.data, loop_triangles=False, destructive=False)

        t.use_set = True    # triggers a sync
        self.report({'INFO'}, "Stored %d face%s" % (count, "" if count == 1 else "s"))
        return {'FINISHED'}


class UVT_OT_set_select(bpy.types.Operator):
    bl_idname = "object.uvt_set_select"
    bl_label = "Get Selection"
    bl_description = "Replace the Edit Mode selection with this transfer's stored faces"
    bl_options = {'REGISTER', 'UNDO'}

    index: IntProperty()

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and ob.mode == 'EDIT'

    def execute(self, context):
        ob = context.active_object
        t = _entry(ob, self.index)
        if t is None:
            return {'CANCELLED'}
        bm = bmesh.from_edit_mesh(ob.data)
        layer = bm.faces.layers.bool.get(t.set_attr)
        if layer is None:
            self.report({'WARNING'}, "Nothing applied for this transfer yet")
            return {'CANCELLED'}
        for f in bm.faces:
            f.select_set(False)
        for f in bm.faces:
            if f[layer]:
                f.select_set(True)
        bm.select_flush_mode()
        bmesh.update_edit_mesh(ob.data, loop_triangles=False, destructive=False)
        return {'FINISHED'}


class UVT_OT_refresh(bpy.types.Operator):
    bl_idname = "object.uvt_refresh"
    bl_label = "Refresh UV Transfer"
    bl_description = "Re-read UV map names and rebuild missing modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        sync_object(context.active_object, create=True)
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------------

class VIEW3D_PT_uv_transfer(bpy.types.Panel):
    bl_label = "UV Transfer"
    bl_idname = "VIEW3D_PT_uv_transfer"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_vehicle"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH'

    def draw(self, context):
        ob = context.active_object
        layout = self.layout
        editing = ob.mode == 'EDIT'

        for i, t in enumerate(ob.uvt_transfers):
            box = layout.box()
            row = box.row(align=True)
            row.prop(t, "enabled", text="")
            row.prop(t, "name", text="")
            op = row.operator("object.uvt_remove", text="", icon='X')
            op.index = i
            if not t.enabled:
                continue

            # --- face filters (shared by every plane of this transfer) ---
            box.prop(t, "use_material")
            if t.use_material:
                for j, it in enumerate(t.materials):
                    row = box.row(align=True)
                    row.prop_search(it, "material", ob.data, "materials", text="")
                    op = row.operator("object.uvt_material_remove", text="", icon='X')
                    op.index = i
                    op.mat_index = j
                op = box.operator("object.uvt_material_add", text="Add Material", icon='ADD')
                op.index = i

            box.prop(t, "use_set")
            row = box.row(align=True)
            row.operator("object.uvt_set_assign", text="Apply Selection",
                         icon='CHECKMARK').index = i
            row.operator("object.uvt_set_select", text="Get Selection",
                         icon='RESTRICT_SELECT_OFF').index = i
            has_set = editing or t.set_attr in ob.data.attributes
            if not editing and not has_set:
                box.label(text="Enter Edit Mode, select faces, then Apply", icon='INFO')

            # --- planes / channels ---
            for j, m in enumerate(t.maps):
                sub = box.box()
                row = sub.row(align=True)
                row.prop(m, "enabled", text="")
                row.prop(m, "source", text="Plane")
                op = row.operator("object.uvt_pick_source", text="", icon='EYEDROPPER')
                op.index = i
                op.map_index = j
                op = row.operator("object.uvt_map_remove", text="", icon='X')
                op.index = i
                op.map_index = j
                if not m.enabled:
                    continue
                row = sub.row(align=True)
                row.label(text="From")
                row.prop(m, "source_uv", expand=True)
                row = sub.row(align=True)
                row.label(text="To")
                row.prop(m, "target_uv", expand=True)

                if m.source is None:
                    sub.label(text="Pick a mapping plane", icon='INFO')
                elif t.use_material and not any(it.material for it in t.materials):
                    sub.label(text="Add at least one material", icon='INFO')
                elif t.use_set and not has_set:
                    sub.label(text="No faces applied yet", icon='INFO')
                elif ob.modifiers.get(m.modname) is None:
                    sub.label(text="Modifier missing - press Refresh", icon='ERROR')

            box.operator("object.uvt_map_add", text="Add Plane / Channel",
                         icon='ADD').index = i

        row = layout.row(align=True)
        row.operator("object.uvt_add", icon='ADD')
        row.operator("object.uvt_refresh", text="", icon='FILE_REFRESH')


# ----------------------------------------------------------------------------

classes = (
    UVT_MaterialItem,
    UVT_Map,
    UVT_Transfer,
    UVT_LegacyMaterial,
    UVT_Settings,
    UVT_SettingsUV2,
    UVT_OT_add,
    UVT_OT_remove,
    UVT_OT_map_add,
    UVT_OT_map_remove,
    UVT_OT_pick_source,
    UVT_OT_material_add,
    UVT_OT_material_remove,
    UVT_OT_set_assign,
    UVT_OT_set_select,
    UVT_OT_refresh,
    VIEW3D_PT_uv_transfer,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Object.uvt_transfers = CollectionProperty(type=UVT_Transfer)
    bpy.types.Object.uvt_counter = IntProperty(default=0, options={'HIDDEN'})
    # Legacy storage, read-only, migrated into uvt_transfers on load / first update
    bpy.types.Object.uvt_dirt = PointerProperty(type=UVT_SettingsUV2)
    bpy.types.Object.uvt_dirt2 = PointerProperty(type=UVT_Settings)
    bpy.types.Object.uvt_livery = PointerProperty(type=UVT_SettingsUV2)
    if _on_depsgraph not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph)
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)
    try:
        _migrate_all()      # addon enabled while a file is already open
    except Exception:
        pass                # bpy.data is restricted during startup; load_post covers it


def unregister():
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    if _on_depsgraph in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(_on_depsgraph)
    del bpy.types.Object.uvt_livery
    del bpy.types.Object.uvt_dirt2
    del bpy.types.Object.uvt_dirt
    del bpy.types.Object.uvt_counter
    del bpy.types.Object.uvt_transfers
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
