import bisect
import math
from collections import defaultdict

import bpy
import bmesh
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
)
from mathutils import Vector

Z_UP = Vector((0.0, 0.0, 1.0))
GEN_TAG = "floor_trim_generated"


# ----------------------------------------------------------------------------
# Settings
# ----------------------------------------------------------------------------

SIMPLE_PROFILES = [
    ('BOX', "Box", "Plain rectangular profile"),
    ('BEVEL', "Beveled", "Rectangular profile with a beveled/rounded top front edge"),
    ('STEPPED', "Stepped", "Thinner upper step"),
    ('SLOPED', "Sloped", "Wedge with a sloped top"),
    ('QUARTER', "Quarter Round", "Convex quarter round"),
    ('OGEE', "Ogee (Colonial)", "S-curve transition to a narrower top"),
    ('CAPPED', "Capped", "Protruding chamfered ledge near the top"),
]


class FloorTrimSettings(bpy.types.PropertyGroup):
    mode: EnumProperty(
        name="Mode",
        items=[
            ('TRIM', "Trim", "Single trim profile along the floor border"),
            ('WAINSCOT', "Wainscoting", "Baseboard + evenly spaced panels + cap along the floor border"),
        ],
        default='TRIM',
    )

    # --- wainscoting ---
    wain_height: FloatProperty(
        name="Total Height", description="Height of the whole wainscoting, from floor to top of the cap",
        default=1.0, min=0.05, unit='LENGTH', subtype='DISTANCE',
    )
    corner_angle: FloatProperty(
        name="Corner Angle",
        description="Turns sharper than this start a new wall run, each run gets its own evenly spaced panels",
        default=30.0, min=1.0, max=90.0,
    )
    wain_separate: BoolProperty(
        name="Separate Objects",
        description=("Make baseboard, panels and cap separate objects. Otherwise they share one object "
                     "with material indices 0 = baseboard, 1 = panels, 2 = cap"),
        default=False,
    )
    bb_enabled: BoolProperty(name="Baseboard", default=True)
    bb_profile: EnumProperty(name="Profile", items=SIMPLE_PROFILES, default='BEVEL')
    bb_height: FloatProperty(name="Height", default=0.12, min=0.005, unit='LENGTH', subtype='DISTANCE')
    bb_thickness: FloatProperty(name="Thickness", default=0.02, min=0.001, unit='LENGTH', subtype='DISTANCE')
    cap_enabled: BoolProperty(name="Cap", default=True)
    cap_profile: EnumProperty(name="Profile", items=SIMPLE_PROFILES, default='OGEE')
    cap_height: FloatProperty(name="Height", default=0.06, min=0.005, unit='LENGTH', subtype='DISTANCE')
    cap_thickness: FloatProperty(name="Thickness", default=0.035, min=0.001, unit='LENGTH', subtype='DISTANCE')
    panel_style: EnumProperty(
        name="Style",
        items=[
            ('SHAKER', "Shaker (Recessed)", "Raised frame around recessed flat panels"),
            ('RAISED', "Raised Panel", "Raised frame around beveled raised panels"),
            ('BATTEN', "Board & Batten", "Evenly spaced vertical battens, no horizontal rails"),
        ],
        default='SHAKER',
    )
    panel_width: FloatProperty(
        name="Panel Width", description="Target width; each wall run is divided so all its panels are identical",
        default=0.6, min=0.02, unit='LENGTH', subtype='DISTANCE',
    )
    stile_width: FloatProperty(
        name="Stile Width", description="Width of the vertical frame pieces between panels and at the ends",
        default=0.07, min=0.005, unit='LENGTH', subtype='DISTANCE',
    )
    rail_width: FloatProperty(
        name="Rail Width", description="Height of the horizontal frame pieces at the top and bottom",
        default=0.07, min=0.0, unit='LENGTH', subtype='DISTANCE',
    )
    frame_depth: FloatProperty(
        name="Frame Depth", description="How far the frame sticks out from the wall",
        default=0.018, min=0.001, unit='LENGTH', subtype='DISTANCE',
    )
    field_depth: FloatProperty(
        name="Panel Field Depth",
        description="Depth of the flat area inside the frame. 0 leaves the bare wall (saves polygons)",
        default=0.006, min=0.0, unit='LENGTH', subtype='DISTANCE',
    )
    panel_depth: FloatProperty(
        name="Raised Depth", description="Depth of the top of a raised panel",
        default=0.014, min=0.001, unit='LENGTH', subtype='DISTANCE',
    )
    panel_gap: FloatProperty(
        name="Raised Gap", description="Gap between the frame and the foot of a raised panel",
        default=0.008, min=0.0, unit='LENGTH', subtype='DISTANCE',
    )
    panel_bevel: FloatProperty(
        name="Raised Bevel", description="Width of the sloped edge of a raised panel",
        default=0.02, min=0.0, unit='LENGTH', subtype='DISTANCE',
    )

    # --- trim shape ---
    profile: EnumProperty(
        name="Profile",
        items=[
            ('BOX', "Box", "Plain rectangular trim"),
            ('BEVEL', "Beveled", "Rectangular trim with a beveled/rounded top front edge"),
            ('STEPPED', "Stepped", "Classic skirting board with a thinner upper step"),
            ('SLOPED', "Sloped", "Modern wedge with a sloped top"),
            ('QUARTER', "Quarter Round", "Convex quarter-round shoe molding"),
            ('OGEE', "Ogee (Colonial)", "Straight base with an S-curve transition to a narrower top"),
            ('CAPPED', "Capped", "Baseboard with a protruding chamfered cap ledge"),
            ('COVE', "Vinyl Cove", "Thin sheet that curves out of the wall and wraps onto the floor, like vinyl/linoleum flash cove"),
        ],
        default='BEVEL',
    )
    placement: EnumProperty(
        name="Placement",
        description="Where the trim sits relative to the border edge",
        items=[
            ('INSIDE', "Inside", "Trim sits on the floor, back flush with the border edge (against a wall)"),
            ('OUTSIDE', "Outside", "Trim sits outside the floor, back flush with the border edge"),
            ('CENTER', "Centered", "Trim is centered on the border edge"),
        ],
        default='INSIDE',
    )
    height: FloatProperty(name="Height", default=0.10, min=0.0001, unit='LENGTH', subtype='DISTANCE')
    thickness: FloatProperty(name="Thickness", default=0.015, min=0.0001, unit='LENGTH', subtype='DISTANCE')
    bevel_size: FloatProperty(name="Bevel Size", default=0.008, min=0.0, unit='LENGTH', subtype='DISTANCE')
    bevel_segments: IntProperty(name="Bevel Segments", default=1, min=1, max=16)
    curve_segments: IntProperty(
        name="Curve Segments", description="Segments used for curved profiles (quarter round, ogee, vinyl cove)",
        default=6, min=1, max=32,
    )
    sheet_thickness: FloatProperty(
        name="Sheet Thickness", description="Thickness of the vinyl sheet",
        default=0.004, min=0.0001, unit='LENGTH', subtype='DISTANCE',
    )
    cove_radius: FloatProperty(
        name="Cove Radius", description="Radius of the curve between wall and floor",
        default=0.04, min=0.0, unit='LENGTH', subtype='DISTANCE',
    )
    cove_flange: FloatProperty(
        name="Floor Flange", description="How far the sheet continues onto the floor after the curve",
        default=0.04, min=0.0, unit='LENGTH', subtype='DISTANCE',
    )
    cove_feather: BoolProperty(
        name="Feather Flange",
        description="Taper the flange down to the floor so the sheet blends into the existing floor without a lip",
        default=True,
    )
    cove_edge_height: FloatProperty(
        name="Edge Height",
        description="Height of the feathered flange edge above the floor. Keep it tiny to avoid z-fighting with the floor",
        default=0.0005, min=0.0, precision=4, unit='LENGTH', subtype='DISTANCE',
    )
    cove_match_uv: BoolProperty(
        name="Match Floor UVs",
        description=("Take the UVs from the floor faces' active UV map and continue them up the cove and wall, "
                     "so a floor pattern flows onto the cove"),
        default=True,
    )
    lift: FloatProperty(
        name="Lift",
        description="Raise the trim above the floor surface",
        default=0.0, unit='LENGTH', subtype='DISTANCE',
    )
    up_mode: EnumProperty(
        name="Up Direction",
        items=[
            ('FACE', "Face Normal", "Trim height follows the floor's normal (works on sloped floors)"),
            ('WORLD', "World Z", "Trim height always points along world Z"),
        ],
        default='FACE',
    )
    miter_limit: FloatProperty(
        name="Miter Limit",
        description="Maximum corner stretch. Prevents spikes on very sharp corners",
        default=3.0, min=1.0, max=20.0,
    )

    # --- polygon saving ---
    remove_back: BoolProperty(
        name="Remove Wall Side",
        description="Delete the flat face that sits against the wall",
        default=True,
    )
    remove_bottom: BoolProperty(
        name="Remove Floor Side",
        description="Delete the flat face that sits on the floor",
        default=True,
    )

    # --- UVs ---
    uv_mode: EnumProperty(
        name="Trim UVs",
        items=[
            ('WORLD', "World Scale", "U and V in real-world size / Tile Size (tileable materials)"),
            ('FIT', "Fit Profile", "V runs 0-1 across the visible profile, U in world size / Tile Size (trim sheets)"),
        ],
        default='WORLD',
    )
    uv_tile_size: FloatProperty(
        name="Tile Size",
        description="Length that covers one UV unit",
        default=1.0, min=0.001, unit='LENGTH', subtype='DISTANCE',
    )

    # --- decals ---
    floor_decal: BoolProperty(
        name="Floor Decal",
        description="Flat strip on the floor starting at the front-bottom of the trim",
        default=True,
    )
    floor_decal_width: FloatProperty(
        name="Width", default=0.08, min=0.001, unit='LENGTH', subtype='DISTANCE',
    )
    wall_decal: BoolProperty(
        name="Wall Decal",
        description="Vertical strip on the wall starting at the top of the trim",
        default=True,
    )
    wall_decal_height: FloatProperty(
        name="Height", default=0.25, min=0.001, unit='LENGTH', subtype='DISTANCE',
    )
    decal_offset: FloatProperty(
        name="Offset",
        description="Distance decals are pushed off the floor/wall to avoid z-fighting",
        default=0.001, min=0.0, precision=4, unit='LENGTH', subtype='DISTANCE',
    )
    decal_tile_length: FloatProperty(
        name="Tile Length",
        description="Length along the wall that one repeat of the decal texture covers (U direction). V always runs 0-1 across the decal",
        default=1.0, min=0.001, unit='LENGTH', subtype='DISTANCE',
    )

    # --- source handling ---
    selected_edges_only: BoolProperty(
        name="Selected Edges Only",
        description=("Edit Mode: only trim the selected border edges of the whole mesh "
                     "(handy for skipping doorways). Used automatically when no faces are selected"),
        default=False,
    )
    replace_existing: BoolProperty(
        name="Replace Previous",
        description="Delete the objects previously generated for this floor",
        default=True,
    )


# ----------------------------------------------------------------------------
# Profile
# ----------------------------------------------------------------------------

def raw_profile_full(s):
    """Closed polygon [(a, y)]; a = distance from the back (wall side), y = height.

    Edges lying on a == 0 are the wall-side faces, edges lying on y == 0 are the floor-side faces.
    Returns (points, meta). meta (vinyl cove only) holds the unrolled floor distance of every point
    ("fa") and the point where the sheet ends on the floor ("foot")."""
    t, h = s.thickness, s.height
    kind = s.profile
    n = s.curve_segments
    fa = None
    foot = None

    if kind == 'BOX':
        pts = [(0, 0), (t, 0), (t, h), (0, h)]
    elif kind == 'STEPPED':
        pts = [(0, 0), (t, 0), (t, h * 0.65), (t * 0.55, h * 0.65), (t * 0.55, h), (0, h)]
    elif kind == 'SLOPED':
        pts = [(0, 0), (t, 0), (t, h * 0.3), (0, h)]
    elif kind == 'QUARTER':
        pts = [(0, 0), (t, 0)]
        for k in range(1, n + 1):
            ang = (math.pi / 2) * k / n
            pts.append((t * math.cos(ang), h * math.sin(ang)))
        pts[-1] = (0.0, h)
    elif kind == 'OGEE':
        y1, t_top = h * 0.5, t * 0.4
        pts = [(0, 0), (t, 0), (t, y1)]
        for k in range(1, n + 1):
            f = k / n
            pts.append((t_top + (t - t_top) * 0.5 * (1 + math.cos(math.pi * f)), y1 + (h - y1) * f))
        pts.append((0, h))
    elif kind == 'CAPPED':
        pts = [(0, 0), (t, 0), (t, h * 0.72), (t * 1.3, h * 0.72), (t * 1.3, h * 0.84), (t, h), (0, h)]
    elif kind == 'COVE':
        tk = min(s.sheet_thickness, h * 0.5)
        r = max(0.0, min(s.cove_radius, h - tk))
        c = tk + r                                   # tangent point on the floor / on the wall
        foot = c + s.cove_flange
        eh = min(s.cove_edge_height, tk) if s.cove_feather else tk
        pts = [(0, 0), (foot, 0), (foot, eh)]
        fa = [0.0, foot, foot]
        for k in range(n + 1):
            phi = -math.pi / 2 - (math.pi / 2) * k / n
            pts.append((c + r * math.cos(phi), c + r * math.sin(phi)))
            fa.append(c - r * (math.pi / 2) * k / n)  # floor distance continues round the curve
        s_wall = r * math.pi / 2 + (h - c)
        pts += [(tk, h), (0, h)]
        fa += [c - s_wall, c - s_wall - tk]
    else:  # BEVEL
        b = min(s.bevel_size, t * 0.99, h * 0.99)
        pts = [(0, 0), (t, 0)]
        if b > 1e-6:
            nb = s.bevel_segments
            for i in range(nb + 1):
                ang = (math.pi / 2) * i / nb
                pts.append((t - b + b * math.cos(ang), h - b + b * math.sin(ang)))
        else:
            pts.append((t, h))
        pts.append((0, h))

    clean, cfa = [], []
    for idx, p in enumerate(pts):
        if not clean or abs(p[0] - clean[-1][0]) > 1e-7 or abs(p[1] - clean[-1][1]) > 1e-7:
            clean.append(p)
            if fa is not None:
                cfa.append(fa[idx])
    if len(clean) > 1 and abs(clean[0][0] - clean[-1][0]) < 1e-7 and abs(clean[0][1] - clean[-1][1]) < 1e-7:
        clean.pop()
        if fa is not None:
            cfa.pop()
    return clean, {"fa": cfa if fa is not None else None, "foot": foot}


def front_sign(s):
    """Sign of the 'u' axis (away from the floor face) that the trim front points to."""
    return 1.0 if s.placement == 'OUTSIDE' else -1.0


def map_u(s, a, depth):
    if s.placement == 'INSIDE':
        return -a
    if s.placement == 'OUTSIDE':
        return a
    return depth / 2 - a


def profile_info(s):
    raw, meta = raw_profile_full(s)
    n = len(raw)
    depth = max(a for a, _ in raw)
    foot = meta["foot"]
    if foot is None:
        foot = max(a for a, y in raw if y < 1e-7)   # how far the trim reaches along the floor
    pts = [(map_u(s, a, depth), y + s.lift) for a, y in raw]

    area = 0.0
    for j in range(n):
        k = (j + 1) % n
        area += pts[j][0] * pts[k][1] - pts[k][0] * pts[j][1]
    ccw = area > 0

    vis, nrm, length = [], [], []
    for j in range(n):
        k = (j + 1) % n
        back = abs(raw[j][0]) < 1e-7 and abs(raw[k][0]) < 1e-7
        bottom = abs(raw[j][1]) < 1e-7 and abs(raw[k][1]) < 1e-7
        vis.append(not ((back and s.remove_back) or (bottom and s.remove_bottom)))
        du, dy = pts[k][0] - pts[j][0], pts[k][1] - pts[j][1]
        length.append(math.hypot(du, dy))
        nrm.append((dy, -du) if ccw else (-dy, du))

    # V starts at the first visible edge that follows a removed one
    start = 0
    if not all(vis):
        for j in range(n):
            if vis[j] and not vis[j - 1]:
                start = j
                break
    vr = [None] * n
    acc = 0.0
    for off in range(n):
        j = (start + off) % n
        if vis[j]:
            vr[j] = (acc, acc + length[j])
            acc += length[j]
    scale = (1.0 / acc) if (s.uv_mode == 'FIT' and acc > 1e-9) else 1.0 / s.uv_tile_size
    vr = [None if r is None else (r[0] * scale, r[1] * scale) for r in vr]

    return {"raw": raw, "pts": pts, "vis": vis, "nrm": nrm, "vr": vr, "depth": depth, "foot": foot,
            "fa": meta["fa"]}


# ----------------------------------------------------------------------------
# Chains / frames
# ----------------------------------------------------------------------------

def miter_vector(outs, limit):
    if len(outs) == 1:
        return outs[0].copy()
    o1, o2 = outs
    m = o1 + o2
    if m.length < 1e-6:
        return o1.copy()
    m.normalize()
    scale = min(1.0 / max(m.dot(o1), 1e-6), limit)
    return m * scale


def collect_chains(info):
    """Link border edges into ordered chains. Returns [(verts, edges, closed)]."""
    adj = defaultdict(list)
    for e in info:
        for v in e.verts:
            adj[v].append(e)

    used = set()
    chains = []

    def walk(start, e):
        verts = [start]
        edges = []
        cur = start
        while True:
            used.add(e)
            edges.append(e)
            nxt = e.other_vert(cur)
            if nxt is start:
                return verts, edges, True
            verts.append(nxt)
            cur = nxt
            cand = [x for x in adj[cur] if x not in used]
            if not cand:
                return verts, edges, False
            e = cand[0]

    for v, es in adj.items():
        if len(es) != 2:
            for e in es:
                if e not in used:
                    chains.append(walk(v, e))
    for e in info:
        if e not in used:
            chains.append(walk(e.verts[0], e))
    return chains


def chain_frames(verts, edges, closed, info, limit):
    """Per-vertex (position, miter vector, up vector) and cumulative length."""
    n = len(verts)
    frames = []
    for i, v in enumerate(verts):
        if closed:
            inc = [edges[i - 1], edges[i]]
        else:
            inc = []
            if i > 0:
                inc.append(edges[i - 1])
            if i < len(edges):
                inc.append(edges[i])
        m = miter_vector([info[e][0] for e in inc], limit)
        up = Vector((0.0, 0.0, 0.0))
        for e in inc:
            up += info[e][1]
        up = up.normalized() if up.length > 1e-6 else Z_UP.copy()
        frames.append((v.co.copy(), m, up))

    lens = [0.0]
    for i in range(1, n):
        lens.append(lens[-1] + (verts[i].co - verts[i - 1].co).length)
    if closed:
        lens.append(lens[-1] + (verts[0].co - verts[-1].co).length)
    return frames, lens


def place(frame, u, y):
    co, m, up = frame
    return co + m * u + up * y


def face_uv_map(face, uv_layer):
    """Affine map world position -> UV of a face, from its loop UVs (None if degenerate)."""
    loops = list(face.loops)
    n = len(loops)
    best = None
    for i in range(n):
        l0, l1, l2 = loops[i], loops[(i + 1) % n], loops[(i + 2) % n]
        area = (l1.vert.co - l0.vert.co).cross(l2.vert.co - l0.vert.co).length
        if best is None or area > best[0]:
            best = (area, l0, l1, l2)
    if best is None or best[0] < 1e-12:
        return None
    _, l0, l1, l2 = best
    p0 = l0.vert.co.copy()
    e1, e2 = l1.vert.co - p0, l2.vert.co - p0
    g11, g12, g22 = e1.dot(e1), e1.dot(e2), e2.dot(e2)
    det = g11 * g22 - g12 * g12
    if abs(det) < 1e-18:
        return None
    uv0 = l0[uv_layer].uv.copy()
    d1 = l1[uv_layer].uv - uv0
    d2 = l2[uv_layer].uv - uv0
    return (p0, e1, e2, g11, g12, g22, det, uv0, d1, d2)


def eval_uv(m, point):
    """UV of `point` (projected into the face plane) under map `m`."""
    p0, e1, e2, g11, g12, g22, det, uv0, d1, d2 = m
    w = point - p0
    b1, b2 = w.dot(e1), w.dot(e2)
    al = (g22 * b1 - g12 * b2) / det
    be = (-g12 * b1 + g11 * b2) / det
    return (uv0.x + al * d1.x + be * d2.x, uv0.y + al * d1.y + be * d2.y)


def add_face(bm, uv_layer, verts, uvs, expected):
    """Create a face, orient it towards `expected`, assign UVs by vertex."""
    try:
        f = bm.faces.new(verts)
    except ValueError:
        return None
    f.normal_update()
    if f.normal.dot(expected) < 0:
        f.normal_flip()
    mapping = {v: uv for v, uv in zip(verts, uvs)}
    for loop in f.loops:
        loop[uv_layer].uv = mapping[loop.vert]
    return f


# ----------------------------------------------------------------------------
# Generation
# ----------------------------------------------------------------------------

def find_border(src, s, in_edit):
    """Returns (bm, info, note); bm is in world space, info maps border edge -> (outward, up, floor uv map)."""
    if in_edit:
        src.update_from_editmode()

    bm = bmesh.new()
    bm.from_mesh(src.data)
    bm.transform(src.matrix_world)
    if src.matrix_world.determinant() < 0:
        bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
    bm.normal_update()

    use_edges = False
    if in_edit:
        any_face_sel = any(f.select for f in bm.faces)
        use_edges = s.selected_edges_only or not any_face_sel
        region = set(bm.faces) if use_edges else {f for f in bm.faces if f.select}
    else:
        region = set(bm.faces)

    want_uv = s.mode == 'TRIM' and s.profile == 'COVE' and s.cove_match_uv
    floor_uv = bm.loops.layers.uv.active if want_uv else None
    note = ""
    if want_uv and floor_uv is None:
        note = "floor has no UV map, using generated UVs for the cove"

    info = {}
    for e in bm.edges:
        loops = [l for l in e.link_loops if l.face in region]
        if len(loops) != 1:
            continue
        if use_edges and not e.select:
            continue
        l = loops[0]
        n = l.face.normal.copy()
        d = l.link_loop_next.vert.co - l.vert.co
        if d.length < 1e-9:
            continue
        o = d.normalized().cross(n)  # away from the face, within its plane
        if o.length < 1e-9:
            continue
        o.normalize()
        if s.up_mode == 'WORLD':
            up = Z_UP.copy()
        else:
            up = n if n.dot(Z_UP) >= 0 else -n
        info[e] = (o, up, face_uv_map(l.face, floor_uv) if floor_uv is not None else None)
    return bm, info, note


def new_bm_with_uv():
    bm = bmesh.new()
    return bm, bm.loops.layers.uv.new("UVMap")


def build_trim(chains_data, info, s, pf, target=None, mat=None):
    pts, vis, nrm, vr, raw = pf["pts"], pf["vis"], pf["nrm"], pf["vr"], pf["raw"]
    fa, depth = pf["fa"], pf["depth"]
    n_p = len(pts)
    tile = s.uv_tile_size
    bm, uvl = target if target is not None else new_bm_with_uv()

    for verts, edges, closed, frames, lens in chains_data:
        n_v = len(verts)
        rings = [[bm.verts.new(place(fr, u, y)) for u, y in pts] for fr in frames]

        segs = n_v if closed else n_v - 1
        for i in range(segs):
            o_e, up_e, uvmap = info[edges[i]]
            r0, r1 = rings[i], rings[(i + 1) % n_v]
            u0, u1 = lens[i] / tile, lens[i + 1] / tile
            if fa is not None and uvmap is not None:
                fr0, fr1 = frames[i], frames[(i + 1) % n_v]
            for j in range(n_p):
                if not vis[j]:
                    continue
                k = (j + 1) % n_p
                expected = o_e * nrm[j][0] + up_e * nrm[j][1]
                if fa is not None and uvmap is not None:
                    # continue the floor's UVs: unroll the sheet back onto the floor plane
                    uj, uk = map_u(s, fa[j], depth), map_u(s, fa[k], depth)
                    uvs = [eval_uv(uvmap, place(fr0, uj, 0.0)), eval_uv(uvmap, place(fr0, uk, 0.0)),
                           eval_uv(uvmap, place(fr1, uk, 0.0)), eval_uv(uvmap, place(fr1, uj, 0.0))]
                else:
                    v0, v1 = vr[j]
                    uvs = [(u0, v0), (u0, v1), (u1, v1), (u1, v0)]
                f = add_face(bm, uvl, [r0[j], r0[k], r1[k], r1[j]], uvs, expected)
                if f is not None and mat is not None:
                    f.material_index = mat

        if not closed:
            cap_uv = [(a / tile, y / tile) for a, y in raw]
            t_start = (verts[1].co - verts[0].co).normalized()
            t_end = (verts[-1].co - verts[-2].co).normalized()
            for ring, direction in ((rings[0], -t_start), (rings[-1], t_end)):
                f = add_face(bm, uvl, ring, cap_uv, direction)
                if f is not None and mat is not None:
                    f.material_index = mat
    return bm


def build_floor_decal(chains_data, info, s, pf):
    sf = front_sign(s)
    u_a = map_u(s, pf["foot"], pf["depth"])  # where the trim meets the floor, room side
    u_b = u_a + sf * s.floor_decal_width
    y = s.decal_offset                     # just above the floor surface
    tile = s.decal_tile_length
    bm, uvl = new_bm_with_uv()

    for verts, edges, closed, frames, lens in chains_data:
        n_v = len(verts)
        rings = [(bm.verts.new(place(fr, u_a, y)), bm.verts.new(place(fr, u_b, y))) for fr in frames]
        segs = n_v if closed else n_v - 1
        for i in range(segs):
            up_e = info[edges[i]][1]
            (a0, b0), (a1, b1) = rings[i], rings[(i + 1) % n_v]
            u0, u1 = lens[i] / tile, lens[i + 1] / tile
            add_face(bm, uvl, [a0, b0, b1, a1],
                     [(u0, 0.0), (u0, 1.0), (u1, 1.0), (u1, 0.0)], up_e)
    return bm


def build_wall_decal(chains_data, info, s, pf):
    sf = front_sign(s)
    u_w = map_u(s, 0.0, pf["depth"]) + sf * s.decal_offset   # wall plane, pushed towards the room
    y0 = s.height + s.lift                       # top of the trim
    y1 = y0 + s.wall_decal_height
    tile = s.decal_tile_length
    bm, uvl = new_bm_with_uv()

    for verts, edges, closed, frames, lens in chains_data:
        n_v = len(verts)
        rings = [(bm.verts.new(place(fr, u_w, y0)), bm.verts.new(place(fr, u_w, y1))) for fr in frames]
        segs = n_v if closed else n_v - 1
        for i in range(segs):
            o_e = info[edges[i]][0]
            (a0, b0), (a1, b1) = rings[i], rings[(i + 1) % n_v]
            u0, u1 = lens[i] / tile, lens[i + 1] / tile
            add_face(bm, uvl, [a0, b0, b1, a1],
                     [(u0, 0.0), (u0, 1.0), (u1, 1.0), (u1, 0.0)], o_e * sf)
    return bm


def generate_all(src, s, in_edit):
    """Returns ({name_suffix: bmesh}, message)."""
    src_bm, info, note = find_border(src, s, in_edit)
    if not info:
        src_bm.free()
        return None, "no border edges found"

    chains_data = []
    for verts, edges, closed in collect_chains(info):
        frames, lens = chain_frames(verts, edges, closed, info, s.miter_limit)
        chains_data.append((verts, edges, closed, frames, lens))

    if s.mode == 'WAINSCOT':
        result = build_wainscot(chains_data, info, s)
    else:
        pf = profile_info(s)
        result = {"_Trim": build_trim(chains_data, info, s, pf)}
        if s.floor_decal:
            result["_Trim_FloorDecal"] = build_floor_decal(chains_data, info, s, pf)
        if s.wall_decal:
            result["_Trim_WallDecal"] = build_wall_decal(chains_data, info, s, pf)
    src_bm.free()
    return result, note


# ----------------------------------------------------------------------------
# Wainscoting
# ----------------------------------------------------------------------------

class Proxy:
    """Settings view with some values overridden (lets the trim builders be reused)."""

    def __init__(self, base, **over):
        object.__setattr__(self, "_base", base)
        object.__setattr__(self, "_over", over)

    def __getattr__(self, name):
        over = object.__getattribute__(self, "_over")
        if name in over:
            return over[name]
        return getattr(object.__getattribute__(self, "_base"), name)


def split_runs(verts, edges, closed, info, cos_limit):
    """Split a border chain into straight-ish wall runs (lists of chain vertex indices)."""
    n = len(verts)
    corner = [False] * n
    rng = range(n) if closed else range(1, n - 1)
    for i in rng:
        o1, o2 = info[edges[i - 1]][0], info[edges[i]][0]
        if o1.dot(o2) < cos_limit:
            corner[i] = True
    if not closed:
        corner[0] = corner[-1] = True

    cs = [i for i in range(n) if corner[i]]
    runs = []
    if closed:
        if not cs:
            runs.append([t % n for t in range(n + 1)])
        else:
            for k, a in enumerate(cs):
                b = cs[(k + 1) % len(cs)]
                if b <= a:
                    b += n
                runs.append([t % n for t in range(a, b + 1)])
    else:
        for a, b in zip(cs, cs[1:]):
            runs.append(list(range(a, b + 1)))
    return runs


class RunSampler:
    """Positions along one wall run, parameterised by arc length s."""

    def __init__(self, idxs, edges, frames, info):
        self.fr = [frames[i] for i in idxs]
        self.segs = [info[edges[i]] for i in idxs[:-1]]
        S = [0.0]
        for a in range(len(self.fr) - 1):
            S.append(S[-1] + (self.fr[a + 1][0] - self.fr[a][0]).length)
        self.S = S
        self.L = S[-1]

    def seg_index(self, s):
        a = bisect.bisect_right(self.S, s + 1e-6) - 1
        return max(0, min(a, len(self.S) - 2))

    def frame_at(self, s):
        a = self.seg_index(s)
        S = self.S
        if abs(s - S[a]) < 1e-5:
            return self.fr[a]
        if abs(s - S[a + 1]) < 1e-5:
            return self.fr[a + 1]
        t = (s - S[a]) / (S[a + 1] - S[a])
        co = self.fr[a][0] * (1.0 - t) + self.fr[a + 1][0] * t
        o, up, _ = self.segs[a]
        return (co, o, up)

    def vectors(self, s):
        a = self.seg_index(s)
        o, up, _ = self.segs[a]
        T = (self.fr[a + 1][0] - self.fr[a][0]).normalized()
        return o, up, T

    def stations(self, sa, sb):
        return [sa] + [x for x in self.S if sa + 1e-5 < x < sb - 1e-5] + [sb]


class WainBuilder:
    """Emits faces given as (s, depth, y) corners: s along the wall, depth out from the wall, y up."""

    def __init__(self, bm, uvl, sf, tile, mat):
        self.bm, self.uvl, self.sf, self.tile, self.mat = bm, uvl, sf, tile, mat
        self.sm = None
        self.cache = {}

    def begin(self, sampler):
        self.sm = sampler
        self.cache = {}

    def sline(self, sa, sb, d, y):
        """Points from sa to sb at constant depth/height, including the run's interior stations."""
        if sa <= sb:
            return [(x, d, y) for x in self.sm.stations(sa, sb)]
        return [(x, d, y) for x in reversed(self.sm.stations(sb, sa))]

    def face(self, corners, nrm):
        """nrm = (towards room, up, along wall) direction the face must point to."""
        pts = []
        for c in corners:
            key = (round(c[0], 5), round(c[1], 5), round(c[2], 5))
            if not pts or pts[-1][0] != key:
                pts.append((key, c))
        if len(pts) > 1 and pts[0][0] == pts[-1][0]:
            pts.pop()
        if len(pts) < 3:
            return None

        verts = []
        for key, c in pts:
            v = self.cache.get(key)
            if v is None:
                v = self.bm.verts.new(place(self.sm.frame_at(c[0]), self.sf * c[1], c[2]))
                self.cache[key] = v
            verts.append(v)
        if len(set(verts)) != len(verts):
            return None

        s_mid = sum(c[0] for _, c in pts) / len(pts)
        o, up, T = self.sm.vectors(s_mid)
        nd, ny, nt = nrm
        expected = o * (self.sf * nd) + up * ny + T * nt

        t = self.tile
        ad, ay, at = abs(nd), abs(ny), abs(nt)
        if ad >= ay and ad >= at:
            uvs = [(c[0] / t, c[2] / t) for _, c in pts]
        elif ay >= at:
            uvs = [(c[0] / t, c[1] / t) for _, c in pts]
        else:
            uvs = [(c[1] / t, c[2] / t) for _, c in pts]

        f = add_face(self.bm, self.uvl, verts, uvs, expected)
        if f is not None and self.mat is not None:
            f.material_index = self.mat
        return f


def build_panels(chains_data, info, s, cap_depth, target, mat):
    bm, uvl = target
    sf = front_sign(s)
    y_b = s.bb_height if s.bb_enabled else 0.0
    y_t = s.wain_height - (s.cap_height if s.cap_enabled else 0.0)
    if y_t - y_b < 0.02:
        return

    d_f = s.frame_depth
    d_fld = min(max(s.field_depth, 0.0), d_f)
    batten = s.panel_style == 'BATTEN'
    rw = 0.0 if batten else max(0.0, min(s.rail_width, (y_t - y_b) / 2 - 0.01))
    ya, yb = y_b + rw, y_t - rw
    cap_covers = s.cap_enabled and cap_depth >= d_f - 1e-6
    cos_lim = math.cos(math.radians(s.corner_angle))
    Ws, Wp = max(s.stile_width, 0.005), max(s.panel_width, 0.02)
    B = WainBuilder(bm, uvl, sf, s.uv_tile_size, mat)

    for verts, edges, closed, frames, lens in chains_data:
        n = len(verts)
        for idxs in split_runs(verts, edges, closed, info, cos_lim):
            sm = RunSampler(idxs, edges, frames, info)
            L = sm.L
            if L < 1e-3:
                continue
            B.begin(sm)
            sl = B.sline

            # evenly spaced panels: N panels + (N + 1) stiles exactly fill the run
            N = 0
            if L > 2 * Ws + 0.02:
                N = max(1, int(round((L - Ws) / (Wp + Ws))))
                while N >= 1 and (L - (N + 1) * Ws) / N < 0.02:
                    N -= 1
            if N >= 1:
                pitch = Ws + (L - (N + 1) * Ws) / N
                stiles = [(k * pitch, k * pitch + Ws) for k in range(N + 1)]
                opens = [(k * pitch + Ws, (k + 1) * pitch) for k in range(N)]
            else:
                stiles, opens = [], []

            # frame fronts
            if N == 0:
                B.face(sl(0, L, d_f, y_b) + sl(L, 0, d_f, y_t), (1, 0, 0))
                top_regions = [(0.0, L)]
            else:
                if rw > 1e-6:
                    for y0, y1 in ((y_b, y_b + rw), (y_t - rw, y_t)):
                        B.face(sl(0, L, d_f, y0) + sl(L, 0, d_f, y1), (1, 0, 0))
                    top_regions = [(0.0, L)]
                else:
                    top_regions = stiles
                for sa, sb in stiles:
                    B.face(sl(sa, sb, d_f, ya) + sl(sb, sa, d_f, yb), (1, 0, 0))

            if not cap_covers:
                for sa, sb in top_regions:
                    B.face(sl(sa, sb, 0.0, y_t) + sl(sb, sa, d_f, y_t), (0, 1, 0))

            # openings
            for sa, sb in opens:
                if d_f - d_fld > 1e-5:
                    B.face([(sa, d_fld, ya), (sa, d_f, ya), (sa, d_f, yb), (sa, d_fld, yb)], (0, 0, 1))
                    B.face([(sb, d_fld, ya), (sb, d_fld, yb), (sb, d_f, yb), (sb, d_f, ya)], (0, 0, -1))
                    if rw > 1e-6:
                        B.face(sl(sa, sb, d_fld, ya) + sl(sb, sa, d_f, ya), (0, 1, 0))
                        B.face(sl(sa, sb, d_fld, yb) + sl(sb, sa, d_f, yb), (0, -1, 0))

                d_p = min(s.panel_depth, d_f)
                if s.panel_style == 'RAISED' and d_p > d_fld + 1e-4:
                    g = max(0.0, min(s.panel_gap, (sb - sa) / 4, (yb - ya) / 4))
                    s0, s1, y0, y1 = sa + g, sb - g, ya + g, yb - g
                    pb = max(0.0, min(s.panel_bevel, (s1 - s0) / 2 - 1e-3, (y1 - y0) / 2 - 1e-3))
                    dd = d_p - d_fld
                    if d_fld > 1e-6 and g > 1e-6:      # flat field around the foot of the panel
                        B.face(sl(sa, sb, d_fld, ya) + sl(sb, sa, d_fld, y0), (1, 0, 0))
                        B.face(sl(sa, sb, d_fld, y1) + sl(sb, sa, d_fld, yb), (1, 0, 0))
                        B.face([(sa, d_fld, y0), (s0, d_fld, y0), (s0, d_fld, y1), (sa, d_fld, y1)], (1, 0, 0))
                        B.face([(s1, d_fld, y0), (sb, d_fld, y0), (sb, d_fld, y1), (s1, d_fld, y1)], (1, 0, 0))
                    B.face(sl(s0, s1, d_fld, y0) + sl(s1 - pb, s0 + pb, d_p, y0 + pb), (pb, -dd, 0))
                    B.face(sl(s0, s1, d_fld, y1) + sl(s1 - pb, s0 + pb, d_p, y1 - pb), (pb, dd, 0))
                    B.face([(s0, d_fld, y0), (s0, d_fld, y1), (s0 + pb, d_p, y1 - pb), (s0 + pb, d_p, y0 + pb)], (pb, 0, -dd))
                    B.face([(s1, d_fld, y0), (s1 - pb, d_p, y0 + pb), (s1 - pb, d_p, y1 - pb), (s1, d_fld, y1)], (pb, 0, dd))
                    B.face(sl(s0 + pb, s1 - pb, d_p, y0 + pb) + sl(s1 - pb, s0 + pb, d_p, y1 - pb), (1, 0, 0))
                elif d_fld > 1e-6:
                    B.face(sl(sa, sb, d_fld, ya) + sl(sb, sa, d_fld, yb), (1, 0, 0))

            # open ends of the chain (e.g. doorways) get a closing face
            if not closed and idxs[0] == 0:
                B.face([(0.0, 0.0, y_b), (0.0, d_f, y_b), (0.0, d_f, y_t), (0.0, 0.0, y_t)], (0, 0, -1))
            if not closed and idxs[-1] == n - 1:
                B.face([(L, 0.0, y_b), (L, 0.0, y_t), (L, d_f, y_t), (L, d_f, y_b)], (0, 0, 1))


def build_wainscot(chains_data, info, s):
    """Returns {name_suffix: bmesh} for baseboard + panels + cap + decals."""
    bbs = Proxy(s, profile=s.bb_profile, height=s.bb_height, thickness=s.bb_thickness, lift=0.0)
    caps = Proxy(s, profile=s.cap_profile, height=s.cap_height, thickness=s.cap_thickness,
                 lift=s.wain_height - s.cap_height, remove_bottom=False)
    pf_bb = profile_info(bbs) if s.bb_enabled else None
    pf_cap = profile_info(caps) if s.cap_enabled else None

    result = {}
    combined = not s.wain_separate
    shared = new_bm_with_uv() if combined else None

    def target(suffix):
        if combined:
            return shared
        t = new_bm_with_uv()
        result[suffix] = t[0]
        return t

    if s.bb_enabled:
        build_trim(chains_data, info, bbs, pf_bb, target=target("_Wainscot_Base"), mat=0)
    build_panels(chains_data, info, s, pf_cap["depth"] if pf_cap else 0.0, target("_Wainscot_Panels"), 1)
    if s.cap_enabled:
        build_trim(chains_data, info, caps, pf_cap, target=target("_Wainscot_Cap"), mat=2)
    if combined:
        result["_Wainscot"] = shared[0]

    dec = Proxy(s, height=s.wain_height, lift=0.0)
    pf_dec = pf_bb if pf_bb is not None else {"foot": s.frame_depth, "depth": s.frame_depth}
    if s.floor_decal:
        result["_Wainscot_FloorDecal"] = build_floor_decal(chains_data, info, dec, pf_dec)
    if s.wall_decal:
        result["_Wainscot_WallDecal"] = build_wall_decal(chains_data, info, dec, pf_dec)
    return result


# ----------------------------------------------------------------------------
# Operator
# ----------------------------------------------------------------------------

def remove_object(name):
    old = bpy.data.objects.get(name)
    if old is None:
        return
    mesh = old.data
    bpy.data.objects.remove(old, do_unlink=True)
    if mesh is not None and mesh.users == 0:
        bpy.data.meshes.remove(mesh)


class MESH_OT_generate_floor_trim(bpy.types.Operator):
    bl_idname = "mesh.generate_floor_trim"
    bl_label = "Generate Floor Trim"
    bl_description = "Generate trim and decal strips along the border of the selected floor mesh / faces"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        ob = context.active_object
        return ob is not None and ob.type == 'MESH' and context.mode in {'OBJECT', 'EDIT_MESH'}

    def execute(self, context):
        s = context.scene.floor_trim
        in_edit = context.mode == 'EDIT_MESH'
        pool = context.objects_in_mode if in_edit else context.selected_objects
        sources = [o for o in pool if o.type == 'MESH' and not o.get(GEN_TAG)]
        if not sources:
            self.report({'WARNING'}, "Select a floor mesh first")
            return {'CANCELLED'}

        all_suffixes = ("_Trim", "_Trim_FloorDecal", "_Trim_WallDecal",
                        "_Wainscot", "_Wainscot_Base", "_Wainscot_Panels", "_Wainscot_Cap",
                        "_Wainscot_FloorDecal", "_Wainscot_WallDecal")
        created = 0
        for src in sources:
            result, msg = generate_all(src, s, in_edit)
            if result is None:
                self.report({'WARNING'}, f"{src.name}: {msg}")
                continue
            if msg:
                self.report({'WARNING'}, f"{src.name}: {msg}")

            if s.replace_existing:
                for suf in all_suffixes:
                    remove_object(src.name + suf)

            for suf, bm in result.items():
                name = src.name + suf
                me = bpy.data.meshes.new(name)
                bm.to_mesh(me)
                bm.free()
                me.update()
                ob = bpy.data.objects.new(name, me)  # geometry is already in world space
                ob[GEN_TAG] = True
                for coll in (src.users_collection or [context.scene.collection]):
                    coll.objects.link(ob)
                created += 1

        if not created:
            return {'CANCELLED'}
        self.report({'INFO'}, f"Created {created} object(s)")
        return {'FINISHED'}


# ----------------------------------------------------------------------------
# UI
# ----------------------------------------------------------------------------

class VIEW3D_PT_floor_trim(bpy.types.Panel):
    bl_label = "Floor Trim"
    bl_idname = "VIEW3D_PT_floor_trim"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_mapping"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        s = context.scene.floor_trim
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        layout.row().prop(s, "mode", expand=True)
        layout.operator("mesh.generate_floor_trim",
                        text="Generate Wainscoting" if s.mode == 'WAINSCOT' else "Generate Trim",
                        icon='MESH_GRID')

        if s.mode == 'TRIM':
            box = layout.box()
            box.label(text="Trim")
            col = box.column()
            col.prop(s, "profile")
            col.prop(s, "height")
            if s.profile == 'COVE':
                col.prop(s, "sheet_thickness")
                col.prop(s, "cove_radius")
                col.prop(s, "cove_flange")
                col.prop(s, "cove_feather")
                if s.cove_feather:
                    col.prop(s, "cove_edge_height")
                col.prop(s, "cove_match_uv")
            else:
                col.prop(s, "thickness")
            if s.profile == 'BEVEL':
                col.prop(s, "bevel_size")
                col.prop(s, "bevel_segments")
            if s.profile in {'QUARTER', 'OGEE', 'COVE'}:
                col.prop(s, "curve_segments")
            col.prop(s, "lift")
        else:
            box = layout.box()
            box.label(text="Wainscoting")
            col = box.column()
            col.prop(s, "wain_height")
            col.prop(s, "panel_style")
            col.prop(s, "corner_angle")
            col.prop(s, "wain_separate")

            box = layout.box()
            box.prop(s, "bb_enabled")
            if s.bb_enabled:
                col = box.column()
                col.prop(s, "bb_profile")
                col.prop(s, "bb_height")
                col.prop(s, "bb_thickness")

            box = layout.box()
            box.label(text="Panels")
            col = box.column()
            col.prop(s, "panel_width")
            col.prop(s, "stile_width")
            if s.panel_style != 'BATTEN':
                col.prop(s, "rail_width")
            col.prop(s, "frame_depth")
            col.prop(s, "field_depth")
            if s.panel_style == 'RAISED':
                col.prop(s, "panel_depth")
                col.prop(s, "panel_gap")
                col.prop(s, "panel_bevel")

            box = layout.box()
            box.prop(s, "cap_enabled")
            if s.cap_enabled:
                col = box.column()
                col.prop(s, "cap_profile")
                col.prop(s, "cap_height")
                col.prop(s, "cap_thickness")

            profiles = {s.bb_profile if s.bb_enabled else None, s.cap_profile if s.cap_enabled else None}
            if 'BEVEL' in profiles or profiles & {'QUARTER', 'OGEE'}:
                box = layout.box()
                box.label(text="Profile Detail")
                col = box.column()
                if 'BEVEL' in profiles:
                    col.prop(s, "bevel_size")
                    col.prop(s, "bevel_segments")
                if profiles & {'QUARTER', 'OGEE'}:
                    col.prop(s, "curve_segments")

        box = layout.box()
        box.label(text="Placement")
        col = box.column()
        col.prop(s, "placement")
        col.prop(s, "up_mode")
        col.prop(s, "miter_limit")

        box = layout.box()
        box.label(text="Hidden Faces")
        col = box.column()
        col.prop(s, "remove_back")
        col.prop(s, "remove_bottom")

        box = layout.box()
        box.label(text="UVs")
        col = box.column()
        col.prop(s, "uv_mode")
        col.prop(s, "uv_tile_size")

        box = layout.box()
        box.label(text="Decals")
        col = box.column()
        col.prop(s, "floor_decal")
        sub = col.column()
        sub.active = s.floor_decal
        sub.prop(s, "floor_decal_width")
        col.prop(s, "wall_decal")
        sub = col.column()
        sub.active = s.wall_decal
        sub.prop(s, "wall_decal_height")
        col.prop(s, "decal_offset")
        col.prop(s, "decal_tile_length")

        box = layout.box()
        box.label(text="Source")
        col = box.column()
        if context.mode == 'EDIT_MESH':
            col.prop(s, "selected_edges_only")
        col.prop(s, "replace_existing")


# ----------------------------------------------------------------------------
# Registration
# ----------------------------------------------------------------------------

classes = (
    FloorTrimSettings,
    MESH_OT_generate_floor_trim,
    VIEW3D_PT_floor_trim,
)


def register():
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.floor_trim = PointerProperty(type=FloorTrimSettings)


def unregister():
    del bpy.types.Scene.floor_trim
    for c in reversed(classes):
        bpy.utils.unregister_class(c)


if __name__ == "__main__":
    register()
