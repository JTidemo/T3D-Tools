import math

import bpy
import bmesh
from bpy.props import BoolProperty
from bpy_extras import view3d_utils
from mathutils import Vector, Matrix, geometry

# Switch constraint while transforming (number keys are left free for numeric input)
MODE_KEYS = {
    'E': 'EDGE',
    'F': 'FACE',
    'N': 'NORMAL',
    'C': 'NONE',
}

NUM_KEYS = {
    'ZERO': '0', 'ONE': '1', 'TWO': '2', 'THREE': '3', 'FOUR': '4',
    'FIVE': '5', 'SIX': '6', 'SEVEN': '7', 'EIGHT': '8', 'NINE': '9',
    'NUMPAD_0': '0', 'NUMPAD_1': '1', 'NUMPAD_2': '2', 'NUMPAD_3': '3',
    'NUMPAD_4': '4', 'NUMPAD_5': '5', 'NUMPAD_6': '6', 'NUMPAD_7': '7',
    'NUMPAD_8': '8', 'NUMPAD_9': '9',
    'PERIOD': '.', 'NUMPAD_PERIOD': '.',
}

AXES = {
    'X': Vector((1.0, 0.0, 0.0)),
    'Y': Vector((0.0, 1.0, 0.0)),
    'Z': Vector((0.0, 0.0, 1.0)),
}

addon_keymaps = []


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------

def get_mode(scene):
    if scene.cmove_edge:
        return 'EDGE'
    if scene.cmove_face:
        return 'FACE'
    if scene.cmove_normal:
        return 'NORMAL'
    return 'NONE'


def _exclusive(name):
    """Update callback: turning one constraint on turns the others off."""
    def update(self, context):
        if getattr(self, name):
            for other in ("cmove_edge", "cmove_face", "cmove_normal"):
                if other != name and getattr(self, other):
                    setattr(self, other, False)
    return update


# ---------------------------------------------------------------------------
# Math helpers
# ---------------------------------------------------------------------------

def line_param(p, n, o, d):
    """Parameter t of the point on line p + t*n closest to ray o + s*d (n, d unit)."""
    w = p - o
    b = n.dot(d)
    denom = 1.0 - b * b
    if denom < 0.01:  # line (almost) parallel to the view ray: uncontrollable
        return None
    return (b * d.dot(w) - n.dot(w)) / denom


def plane_hit(o, d, p, n):
    """Intersection of ray with the plane (p, n); None if nearly edge-on."""
    if abs(n.dot(d)) < 0.05:
        return None
    return geometry.intersect_line_plane(o, o + d, p, n)


def project_delta(mode, vd, delta):
    """Reduce a free 3D displacement to what the constraint allows."""
    if mode == 'NORMAL':
        return vd.n * delta.dot(vd.n)
    if mode == 'FACE':
        return delta - vd.n * delta.dot(vd.n)
    if mode == 'EDGE':
        best_score = 0.0
        best = Vector((0.0, 0.0, 0.0))
        for vec in vd.edges:
            along = delta.dot(vec)
            if along <= 0.0:
                continue
            score = along / vec.length
            if score > best_score:
                best_score = score
                best = vec * min(along / vec.length_squared, 1.0)
        return best
    return delta


# ---------------------------------------------------------------------------
# Data containers
# ---------------------------------------------------------------------------

class _ObjData:
    def __init__(self, obj, bm):
        self.obj = obj
        self.bm = bm
        self.mw = obj.matrix_world.copy()
        self.mw_inv = self.mw.inverted_safe()
        self.verts = []


class _Vert:
    __slots__ = ("bv", "orig", "p", "n", "edges", "cands", "t0", "hit0", "driver")


# ---------------------------------------------------------------------------
# Shared modal logic
# ---------------------------------------------------------------------------

class _ConstrainedTransform:
    native_name = ""    # matching bpy.ops.transform operator, used when no constraint is on
    title = ""
    uses_axis = False   # X/Y/Z axis keys (scale and rotate)

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH'
                and context.area is not None
                and context.area.type == 'VIEW_3D'
                and context.region_data is not None)

    def invoke(self, context, event):
        mode = get_mode(context.scene)
        self.from_drag = (event.value == 'CLICK_DRAG')

        if mode == 'NONE' and not self.from_drag:
            # No constraint: behave exactly like the normal G / R / S
            return getattr(bpy.ops.transform, self.native_name)('INVOKE_DEFAULT')

        self.area = context.area
        self.region = context.region
        self.rv3d = context.region_data
        self.mode = mode
        self.num_str = ""
        self.axis = None
        self.axis_plane = False
        self.last_mouse = Vector((event.mouse_region_x, event.mouse_region_y))

        if self.from_drag:
            # started by click-drag in a tool: begin where the button went down
            self.start = Vector((event.mouse_prev_press_x - context.region.x,
                                 event.mouse_prev_press_y - context.region.y))
        else:
            self.start = self.last_mouse.copy()

        # "Follow Active" only applies to moving: the active vertex drives the others
        follow = context.scene.cmove_follow and self.native_name == "translate"
        self.driver_vd = None

        self.objs = []
        total = 0
        for obj in context.objects_in_mode_unique_data:
            if obj.type != 'MESH':
                continue
            bm = bmesh.from_edit_mesh(obj.data)
            bm.normal_update()
            od = _ObjData(obj, bm)
            nmat = od.mw.to_3x3().inverted_safe().transposed()
            act = bm.select_history.active if follow else None
            for bv in bm.verts:
                if not bv.select:
                    continue
                vd = _Vert()
                vd.driver = False
                if (act is not None and self.driver_vd is None
                        and isinstance(act, bmesh.types.BMVert) and bv == act):
                    vd.driver = True
                    self.driver_vd = vd
                vd.bv = bv
                vd.orig = bv.co.copy()
                vd.p = od.mw @ bv.co
                vd.n = (nmat @ bv.normal).normalized()
                vd.edges = []
                # edges leading to non-selected neighbours (the ones we can slide along)
                for e in bv.link_edges:
                    other = e.other_vert(bv)
                    if other.select:
                        continue
                    vec = (od.mw @ other.co) - vd.p
                    if vec.length > 1e-9:
                        vd.edges.append(vec)
                vd.cands = []
                vd.t0 = None
                vd.hit0 = None
                od.verts.append(vd)
            total += len(od.verts)
            self.objs.append(od)

        if total == 0:
            self.report({'WARNING'}, "Nothing selected")
            return {'CANCELLED'}

        if follow and (self.driver_vd is None or total < 2):
            self.driver_vd = None
            self.report({'INFO'}, "Follow Active: select two or more vertices, "
                                  "with the driver selected last")

        self._prepare()
        self._status()
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    # -- helpers -----------------------------------------------------------

    def _ray(self, coord):
        o = view3d_utils.region_2d_to_origin_3d(self.region, self.rv3d, coord)
        d = view3d_utils.region_2d_to_vector_3d(self.region, self.rv3d, coord).normalized()
        return o, d

    def _numeric(self):
        try:
            return float(self.num_str)
        except ValueError:
            return None

    def _axis_vec(self):
        return AXES[self.axis] if self.axis else None

    def _status(self):
        names = {'NONE': "None", 'EDGE': "Edge", 'FACE': "Face", 'NORMAL': "Normal"}
        txt = "%s [%s]" % (self.title, names[self.mode])
        if self.uses_axis and self.axis:
            txt += "   axis: %s%s" % ("not " if self.axis_plane else "", self.axis)
        if self.num_str:
            txt += "   value: %s" % self.num_str
        if getattr(self, "driver_vd", None) is not None:
            txt += "   (others follow the active vertex)"
        txt += "   |   E Edge  F Face  N Normal  C None"
        if self.uses_axis:
            txt += "  |  X/Y/Z axis (Shift = plane)"
        txt += "  |  type a number for an exact value  |  click/Enter confirm, RMB/Esc cancel"
        self.area.header_text_set(txt)

    def _apply(self, mouse):
        ctx = self._begin(mouse)
        for od in self.objs:
            for vd in od.verts:
                delta = self._delta(vd, ctx)
                vd.bv.co = od.mw_inv @ (vd.p + delta)
            bmesh.update_edit_mesh(od.obj.data, loop_triangles=True, destructive=False)

    def _restore(self):
        for od in self.objs:
            for vd in od.verts:
                vd.bv.co = vd.orig
            bmesh.update_edit_mesh(od.obj.data, loop_triangles=True, destructive=False)

    # -- modal -------------------------------------------------------------

    def modal(self, context, event):
        et = event.type

        if et == 'MOUSEMOVE':
            self.last_mouse = Vector((event.mouse_region_x, event.mouse_region_y))
            if self._numeric() is None:  # a typed value overrides the mouse
                self._apply(self.last_mouse)
            return {'RUNNING_MODAL'}

        if event.value == 'PRESS':
            changed = False

            if et in NUM_KEYS:
                self.num_str += NUM_KEYS[et]
                changed = True
            elif et in {'MINUS', 'NUMPAD_MINUS'}:
                if self.num_str.startswith('-'):
                    self.num_str = self.num_str[1:]
                else:
                    self.num_str = '-' + self.num_str
                changed = True
            elif et == 'BACK_SPACE':
                self.num_str = self.num_str[:-1]
                changed = True
            elif et in MODE_KEYS and not (event.ctrl or event.alt):
                self.mode = MODE_KEYS[et]
                self._prepare()
                changed = True
            elif et in AXES and self.uses_axis:
                if self.axis == et and self.axis_plane == event.shift:
                    self.axis = None
                else:
                    self.axis = et
                    self.axis_plane = event.shift
                changed = True

            if changed:
                self._status()
                self._apply(self.last_mouse)
                return {'RUNNING_MODAL'}

        confirm = False
        if event.value == 'PRESS' and et in {'RET', 'NUMPAD_ENTER'}:
            confirm = True
        elif self.from_drag:
            confirm = (et == 'LEFTMOUSE' and event.value == 'RELEASE' and not self.num_str)
        else:
            confirm = (event.value == 'PRESS' and et in {'LEFTMOUSE', 'SPACE'})
        if confirm:
            self.area.header_text_set(None)
            return {'FINISHED'}

        if event.value == 'PRESS' and et in {'RIGHTMOUSE', 'ESC'}:
            self._restore()
            self.area.header_text_set(None)
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}


# ---------------------------------------------------------------------------
# Constrained Move
# ---------------------------------------------------------------------------

class MESH_OT_constrained_move(_ConstrainedTransform, bpy.types.Operator):
    """Move selection using the active constraint (Edge / Face / Normal)"""
    bl_idname = "mesh.constrained_move"
    bl_label = "Constrained Move"
    bl_options = {'REGISTER', 'UNDO'}

    native_name = "translate"
    title = "Constrained Move"

    def _prepare(self):
        o, d = self._ray(self.start)
        mode = self.mode

        if mode == 'NONE':
            pts = [vd.p for od in self.objs for vd in od.verts]
            self.median = sum(pts, Vector()) / len(pts)
            self.view_dir = (self.rv3d.view_rotation @ Vector((0.0, 0.0, -1.0))).normalized()
            self.hit0 = plane_hit(o, d, self.median, self.view_dir)
            return

        for od in self.objs:
            for vd in od.verts:
                if mode == 'NORMAL':
                    vd.t0 = line_param(vd.p, vd.n, o, d)
                elif mode == 'FACE':
                    vd.hit0 = plane_hit(o, d, vd.p, vd.n)
                elif mode == 'EDGE':
                    vd.cands = []
                    p2d = view3d_utils.location_3d_to_region_2d(self.region, self.rv3d, vd.p)
                    if p2d is None:
                        continue
                    for vec in vd.edges:
                        q2d = view3d_utils.location_3d_to_region_2d(
                            self.region, self.rv3d, vd.p + vec)
                        if q2d is None:
                            continue
                        e2d = q2d - p2d
                        if e2d.length_squared >= 4.0:  # skip edges seen end-on
                            vd.cands.append((vec, e2d))

    def _begin(self, mouse):
        o, d = self._ray(mouse)
        delta_all = Vector((0.0, 0.0, 0.0))
        if self.mode == 'NONE':
            hit = plane_hit(o, d, self.median, self.view_dir)
            if hit is not None and self.hit0 is not None:
                delta_all = hit - self.hit0
        ctx = (o, d, mouse - self.start, delta_all, self._numeric(), None)
        if self.driver_vd is not None:
            # the active vertex moves by its own constraint; the rest copy that displacement
            ctx = ctx[:5] + (self._own_delta(self.driver_vd, ctx),)
        return ctx

    def _delta(self, vd, ctx):
        drv = ctx[5]
        if drv is not None and not vd.driver:
            # follower: exactly the driver's displacement (offset kept), unconstrained
            return drv
        return self._own_delta(vd, ctx)

    def _own_delta(self, vd, ctx):
        o, d, m, delta_all, value, _drv = ctx
        mode = self.mode
        zero = Vector((0.0, 0.0, 0.0))

        if mode == 'NONE':
            return delta_all

        if mode == 'NORMAL':
            if value is not None:               # typed distance along the normal
                return vd.n * value
            t = line_param(vd.p, vd.n, o, d)
            if t is not None and vd.t0 is not None:
                return vd.n * (t - vd.t0)
            return zero

        if mode == 'FACE':
            hit = plane_hit(o, d, vd.p, vd.n)
            if hit is not None and vd.hit0 is not None:
                return hit - vd.hit0
            return zero

        # EDGE: follow whichever edge the mouse is pulling along the most
        best_score = 0.0
        best_frac = 0.0
        best_vec = None
        for vec, e2d in vd.cands:
            along = m.dot(e2d)
            score = along / e2d.length
            if score > best_score:
                best_score = score
                best_frac = min(along / e2d.length_squared, 1.0)
                best_vec = vec
        if value is not None:                   # typed distance along that edge
            if best_vec is None and vd.edges:
                best_vec = vd.edges[0]
            if best_vec is None:
                return zero
            return best_vec.normalized() * min(max(value, 0.0), best_vec.length)
        if best_vec is None:
            return zero
        return best_vec * best_frac


# ---------------------------------------------------------------------------
# Scale / Rotate (shared pivot logic)
# ---------------------------------------------------------------------------

class _PivotTransform(_ConstrainedTransform):
    uses_axis = True

    def _setup_pivot(self):
        """Compute the pivot and its screen position once per operator run."""
        if getattr(self, "pivot", None) is not None:
            return False
        pts = [vd.p for od in self.objs for vd in od.verts]
        self.pivot = sum(pts, Vector()) / len(pts)
        p2d = view3d_utils.location_3d_to_region_2d(self.region, self.rv3d, self.pivot)
        if p2d is None:
            p2d = Vector((self.region.width * 0.5, self.region.height * 0.5))
        self.pivot2d = p2d
        return True


class MESH_OT_constrained_scale(_PivotTransform, bpy.types.Operator):
    """Scale selection about its median; each vertex's motion is limited by the active constraint"""
    bl_idname = "mesh.constrained_scale"
    bl_label = "Constrained Scale"
    bl_options = {'REGISTER', 'UNDO'}

    native_name = "resize"
    title = "Constrained Scale"

    def _prepare(self):
        if self._setup_pivot():
            self.d0 = max((self.start - self.pivot2d).length, 10.0)

    def _begin(self, mouse):
        v = self._numeric()
        if v is not None:                       # e.g. type 0 to flatten
            return v
        return max((mouse - self.pivot2d).length / self.d0, 0.0)

    def _delta(self, vd, factor):
        r = vd.p - self.pivot
        ax = self._axis_vec()
        if ax is not None:
            along = ax * r.dot(ax)
            r = (r - along) if self.axis_plane else along
        return project_delta(self.mode, vd, r * (factor - 1.0))


class MESH_OT_constrained_rotate(_PivotTransform, bpy.types.Operator):
    """Rotate selection about its median; each vertex's motion is limited by the active constraint"""
    bl_idname = "mesh.constrained_rotate"
    bl_label = "Constrained Rotate"
    bl_options = {'REGISTER', 'UNDO'}

    native_name = "rotate"
    title = "Constrained Rotate"

    def _screen_angle(self, mouse):
        v = mouse - self.pivot2d
        return math.atan2(v.y, v.x)

    def _prepare(self):
        if self._setup_pivot():
            self.angle = 0.0
            self.prev_a = self._screen_angle(self.start)

    def _begin(self, mouse):
        v = self._numeric()
        if v is not None:                       # typed angle in degrees
            ang = math.radians(v)
        else:
            a = self._screen_angle(mouse)
            da = (a - self.prev_a + math.pi) % (2.0 * math.pi) - math.pi
            self.angle += da
            self.prev_a = a
            ang = self.angle

        toward = (self.rv3d.view_rotation @ Vector((0.0, 0.0, 1.0))).normalized()
        ax = self._axis_vec()
        if ax is None:
            ax = toward
            sign = 1.0
        else:
            sign = 1.0 if ax.dot(toward) >= 0.0 else -1.0
        return Matrix.Rotation(ang * sign, 3, ax)

    def _delta(self, vd, rot):
        r = vd.p - self.pivot
        return project_delta(self.mode, vd, rot @ r - r)


# ---------------------------------------------------------------------------
# Misc operator + tools
# ---------------------------------------------------------------------------

class MESH_OT_constraint_none(bpy.types.Operator):
    bl_idname = "mesh.constraint_none"
    bl_label = "No Constraint"
    bl_description = "Turn off all move constraints"

    def execute(self, context):
        s = context.scene
        s.cmove_edge = False
        s.cmove_face = False
        s.cmove_normal = False
        return {'FINISHED'}


_TOOL_SELECT_KEYMAP = (
    ("view3d.select",
     {"type": 'LEFTMOUSE', "value": 'CLICK'},
     {"properties": [("deselect_all", True)]}),
    ("view3d.select",
     {"type": 'LEFTMOUSE', "value": 'CLICK', "shift": True},
     {"properties": [("toggle", True)]}),
)


class CMOVE_TOOL_move(bpy.types.WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'EDIT_MESH'
    bl_idname = "cmove.move_tool"
    bl_label = "Constrained Move"
    bl_description = ("Drag to move the selection with the active Edge/Face/Normal constraint. "
                      "Click selects, Shift+click extends")
    bl_icon = "ops.transform.translate"
    bl_widget = None
    bl_keymap = _TOOL_SELECT_KEYMAP + (
        ("mesh.constrained_move", {"type": 'LEFTMOUSE', "value": 'CLICK_DRAG'}, None),
    )


class CMOVE_TOOL_rotate(bpy.types.WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'EDIT_MESH'
    bl_idname = "cmove.rotate_tool"
    bl_label = "Constrained Rotate"
    bl_description = ("Drag to rotate the selection about its median with the active "
                      "Edge/Face/Normal constraint. Click selects, Shift+click extends")
    bl_icon = "ops.transform.rotate"
    bl_widget = None
    bl_keymap = _TOOL_SELECT_KEYMAP + (
        ("mesh.constrained_rotate", {"type": 'LEFTMOUSE', "value": 'CLICK_DRAG'}, None),
    )


class CMOVE_TOOL_scale(bpy.types.WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'EDIT_MESH'
    bl_idname = "cmove.scale_tool"
    bl_label = "Constrained Scale"
    bl_description = ("Drag to scale the selection about its median with the active "
                      "Edge/Face/Normal constraint. Click selects, Shift+click extends")
    bl_icon = "ops.transform.resize"
    bl_widget = None
    bl_keymap = _TOOL_SELECT_KEYMAP + (
        ("mesh.constrained_scale", {"type": 'LEFTMOUSE', "value": 'CLICK_DRAG'}, None),
    )


# ---------------------------------------------------------------------------
# Axis Move (Snap): gizmo handles that move along one axis and snap to vertices
# ---------------------------------------------------------------------------

def project_points(persp, width, height, pts):
    """Screen positions (pixels, region space) of Nx3 world points.
    persp: 4x4 numpy perspective matrix. Returns (Nx2 array, valid mask)."""
    import numpy as np
    n = len(pts)
    h = np.concatenate([pts, np.ones((n, 1))], axis=1) @ persp.T
    w = h[:, 3]
    ok = w > 1e-6
    wsafe = np.where(ok, w, 1.0)
    sx = (h[:, 0] / wsafe * 0.5 + 0.5) * width
    sy = (h[:, 1] / wsafe * 0.5 + 0.5) * height
    return np.stack([sx, sy], axis=1), ok


def mouse_ray(persp_inv, width, height, coord):
    """World-space ray (origin, unit direction) through a region pixel."""
    nx = coord[0] / width * 2.0 - 1.0
    ny = coord[1] / height * 2.0 - 1.0

    def unproject(z):
        v = persp_inv @ Vector((nx, ny, z, 1.0))
        return Vector((v.x, v.y, v.z)) / v.w
    near, far = unproject(-1.0), unproject(1.0)
    d = far - near
    if d.length < 1e-12:
        return near, Vector((0.0, 0.0, -1.0))
    return near, d.normalized()


class _AxisCore:
    """The maths of the axis drag, free of any Blender UI so it can be tested."""

    def __init__(self, median, axis, persp, width, height, cands, start):
        import numpy as np
        self.median = median.copy()
        self.axis = axis.normalized()
        self.persp = np.array([list(r) for r in persp], dtype=np.float64)
        self.persp_inv = Matrix(persp).inverted_safe()
        self.w, self.h = width, height
        self.cands = cands                      # Nx3 world positions or None
        o, d = mouse_ray(self.persp_inv, width, height, start)
        self.t0 = line_param(self.median, self.axis, o, d)
        self.cand2d = None
        self.cand_ok = None
        if cands is not None and len(cands):
            self.cand2d, self.cand_ok = project_points(self.persp, width, height, cands)
        # does the axis run mostly up/down or left/right on screen?
        pa, _ok = project_points(self.persp, width, height, np.array(
            [list(self.median), list(self.median + self.axis)]))
        sd = pa[1] - pa[0]
        self.match_y = abs(sd[1]) >= abs(sd[0])      # steep axis: line up with the target's screen height

    def _align(self, tgt):
        """Distance along the axis where the axis' screen position lines up with the
        target on screen (same screen height for a steep axis, same screen x otherwise)."""
        import numpy as np
        k = 1 if self.match_y else 0
        size = self.h if self.match_y else self.w
        h = self.persp @ np.array([tgt.x, tgt.y, tgt.z, 1.0])
        if h[3] <= 1e-9:
            return None
        n = h[k] / h[3]
        A = self.persp @ np.array([self.median.x, self.median.y, self.median.z, 1.0])
        B = self.persp[:, :3] @ np.array(list(self.axis))
        den = B[k] - n * B[3]
        if abs(den) < 1e-12:
            return None
        return float(-(A[k] - n * A[3]) / den)

    def usable(self):
        return self.t0 is not None

    def delta(self, mouse, snap, radius, value=None):
        """(displacement along the axis, snapped world vertex or None)."""
        if value is not None:
            return self.axis * value, None
        if snap and self.cand2d is not None:
            import numpy as np
            dv = self.cand2d - np.array([mouse[0], mouse[1]])
            dist = np.hypot(dv[:, 0], dv[:, 1])
            dist = np.where(self.cand_ok, dist, 1e18)
            i = int(np.argmin(dist))
            if dist[i] <= radius:
                tgt = Vector(self.cands[i])
                sdist = self._align(tgt)
                if sdist is None:
                    sdist = (tgt - self.median).dot(self.axis)
                return self.axis * sdist, tgt
        o, d = mouse_ray(self.persp_inv, self.w, self.h, mouse)
        t = line_param(self.median, self.axis, o, d)
        if t is None:
            return Vector((0.0, 0.0, 0.0)), None
        return self.axis * (t - self.t0), None


_LIVE = {"center": None}          # selection centre while an axis move is running (gizmo follows it)


def _selection_center(context):
    pts = []
    for obj in context.objects_in_mode_unique_data:
        if obj.type != 'MESH':
            continue
        bm = bmesh.from_edit_mesh(obj.data)
        mw = obj.matrix_world
        pts.extend(mw @ v.co for v in bm.verts if v.select)
    if not pts:
        return None
    return sum(pts, Vector()) / len(pts)


MAX_DIRS = 8


def _axis_vectors(context):
    """Directions the handles can move along: axes, normal frame, or the edges at the selection."""
    mode = context.scene.cmove_orient
    glob = [AXES['X'].copy(), AXES['Y'].copy(), AXES['Z'].copy()]
    if mode == 'LOCAL' and context.active_object is not None:
        m = context.active_object.matrix_world.to_3x3()
        return [m.col[i].normalized() for i in range(3)]
    if mode not in {'EDGE', 'NORMAL'}:
        return glob
    dirs = []
    nsum = Vector()
    for obj in context.objects_in_mode_unique_data:
        if obj.type != 'MESH':
            continue
        bm = bmesh.from_edit_mesh(obj.data)
        mw = obj.matrix_world
        m3 = mw.to_3x3()
        for v in bm.verts:
            if not v.select:
                continue
            nsum += (m3 @ v.normal)
            for e in v.link_edges:
                o = e.other_vert(v)
                if o.select and not e.select:
                    continue
                d = (mw @ o.co) - (mw @ v.co)
                if d.length < 1e-9:
                    continue
                d.normalize()
                if all(abs(d.dot(x)) < 0.9995 for x in dirs):
                    dirs.append(d)
    if mode == 'NORMAL':
        if nsum.length < 1e-9:
            return glob
        n = nsum.normalized()
        t = n.cross(Vector((0, 0, 1)) if abs(n.z) < 0.9 else Vector((1, 0, 0))).normalized()
        return [n, t, n.cross(t).normalized()]
    return dirs[:MAX_DIRS] if dirs else glob


class MESH_OT_axis_snap_move(bpy.types.Operator):
    """Move the selection along one axis; snaps to the other vertices"""
    bl_idname = "mesh.axis_snap_move"
    bl_label = "Axis Move (Snap)"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.IntProperty(default=0, min=0, max=MAX_DIRS - 1, options={'SKIP_SAVE'})

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH' and context.area is not None
                and context.area.type == 'VIEW_3D' and context.region_data is not None)

    def invoke(self, context, event):
        import numpy as np
        s = context.scene
        self.area, self.region, self.rv3d = context.area, context.region, context.region_data
        self.objs = []
        cands = []
        total = 0
        for obj in context.objects_in_mode_unique_data:
            if obj.type != 'MESH':
                continue
            bm = bmesh.from_edit_mesh(obj.data)
            od = _ObjData(obj, bm)
            for bv in bm.verts:
                if bv.hide:
                    continue
                if bv.select:
                    vd = _Vert()
                    vd.bv, vd.orig, vd.p = bv, bv.co.copy(), od.mw @ bv.co
                    od.verts.append(vd)
                else:
                    cands.append(od.mw @ bv.co)
            total += len(od.verts)
            self.objs.append(od)
        if total == 0:
            self.report({'WARNING'}, "Nothing selected")
            return {'CANCELLED'}
        pts = [vd.p for od in self.objs for vd in od.verts]
        median = sum(pts, Vector()) / len(pts)
        dirs = _axis_vectors(context)
        if self.axis >= len(dirs):
            self.report({'WARNING'}, "No such direction")
            return {'CANCELLED'}
        axis = dirs[self.axis]
        self.start = Vector((event.mouse_region_x, event.mouse_region_y))
        self.last = self.start.copy()
        carr = np.array([list(c) for c in cands], dtype=np.float64) if cands else None
        self.core = _AxisCore(median, axis, self.rv3d.perspective_matrix, self.region.width,
                              self.region.height, carr, self.start)
        if not self.core.usable():
            self.report({'WARNING'}, "That axis points straight at the view: rotate the view first")
            return {'CANCELLED'}
        self.num_str = ""
        self.snap_pt = None
        self.ctrl = event.ctrl
        self.handle = None
        try:
            self.handle = bpy.types.SpaceView3D.draw_handler_add(
                self._draw_overlay, (), 'WINDOW', 'POST_PIXEL')
        except Exception:
            self.handle = None
        _LIVE["center"] = median
        self._status()
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def _numeric(self):
        try:
            return float(self.num_str)
        except ValueError:
            return None

    def _status(self):
        s = bpy.context.scene
        txt = "Axis Move [%s]   vertex snap: %s (Ctrl = %s)" % (
            "XYZ"[self.axis], "on" if s.cmove_vsnap else "off", "off" if s.cmove_vsnap else "on")
        if self.num_str:
            txt += "   value: %s" % self.num_str
        txt += "   |   type a number for an exact distance  |  release/Enter confirm, RMB/Esc cancel"
        self.area.header_text_set(txt)

    def _apply(self):
        s = bpy.context.scene
        snap = bool(s.cmove_vsnap) != bool(self.ctrl)
        delta, tgt = self.core.delta(self.last, snap, s.cmove_snap_px, self._numeric())
        self.snap_pt = tgt
        for od in self.objs:
            for vd in od.verts:
                vd.bv.co = od.mw_inv @ (vd.p + delta)
            bmesh.update_edit_mesh(od.obj.data, loop_triangles=True, destructive=False)
        _LIVE["center"] = self.core.median + delta
        self.area.tag_redraw()

    def _restore(self):
        for od in self.objs:
            for vd in od.verts:
                vd.bv.co = vd.orig
            bmesh.update_edit_mesh(od.obj.data, loop_triangles=True, destructive=False)

    def _end(self):
        self.area.header_text_set(None)
        _LIVE["center"] = None
        if self.handle is not None:
            try:
                bpy.types.SpaceView3D.draw_handler_remove(self.handle, 'WINDOW')
            except Exception:
                pass
            self.handle = None
        self.area.tag_redraw()

    def _draw_overlay(self):
        if self.snap_pt is None:
            return
        try:
            import gpu
            import math
            from gpu_extras.batch import batch_for_shader
            p = view3d_utils.location_3d_to_region_2d(self.region, self.rv3d, self.snap_pt)
            c = view3d_utils.location_3d_to_region_2d(
                self.region, self.rv3d, self.core.median + (_LIVE["center"] - self.core.median
                                                            if _LIVE["center"] is not None
                                                            else Vector()))
            if p is None:
                return
            shader = gpu.shader.from_builtin('UNIFORM_COLOR')
            gpu.state.blend_set('ALPHA')
            try:
                gpu.state.line_width_set(2.0)
            except Exception:
                pass
            ring = [(p.x + math.cos(a * math.tau / 24) * 9, p.y + math.sin(a * math.tau / 24) * 9)
                    for a in range(25)]
            batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": ring})
            shader.bind()
            shader.uniform_float("color", (1.0, 0.85, 0.1, 1.0))
            batch.draw(shader)
            if c is not None:
                line = batch_for_shader(shader, 'LINES', {"pos": [(c.x, c.y), (p.x, p.y)]})
                shader.uniform_float("color", (1.0, 0.85, 0.1, 0.5))
                line.draw(shader)
            gpu.state.blend_set('NONE')
        except Exception:
            pass

    def modal(self, context, event):
        et = event.type

        if et == 'MOUSEMOVE':
            self.last = Vector((event.mouse_region_x, event.mouse_region_y))
            self.ctrl = event.ctrl
            if self._numeric() is None:
                self._apply()
            return {'RUNNING_MODAL'}

        if et in {'LEFT_CTRL', 'RIGHT_CTRL'}:
            self.ctrl = (event.value == 'PRESS')
            self._status()
            if self._numeric() is None:
                self._apply()
            return {'RUNNING_MODAL'}

        if event.value == 'PRESS':
            changed = False
            if et in NUM_KEYS:
                self.num_str += NUM_KEYS[et]
                changed = True
            elif et in {'MINUS', 'NUMPAD_MINUS'}:
                self.num_str = self.num_str[1:] if self.num_str.startswith('-') else '-' + self.num_str
                changed = True
            elif et == 'BACK_SPACE':
                self.num_str = self.num_str[:-1]
                changed = True
            if changed:
                self._status()
                self._apply()
                return {'RUNNING_MODAL'}

        if (et == 'LEFTMOUSE' and event.value == 'RELEASE') or \
                (event.value == 'PRESS' and et in {'RET', 'NUMPAD_ENTER'}):
            self._end()
            return {'FINISHED'}

        if event.value == 'PRESS' and et in {'RIGHTMOUSE', 'ESC'}:
            self._restore()
            self._end()
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}


class CMOVE_GGT_axis_move(bpy.types.GizmoGroup):
    bl_idname = "CMOVE_GGT_axis_move"
    bl_label = "Axis Move (Snap)"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'3D'}

    @classmethod
    def poll(cls, context):
        if context.mode != 'EDIT_MESH':
            return False
        try:
            tool = context.workspace.tools.from_space_view3d_mode(context.mode, create=False)
        except Exception:
            return True
        if tool is None:
            return False
        return tool.idname == "cmove.axis_move_tool" or tool.widget == cls.bl_idname

    def setup(self, context):
        self.arrows = []
        colors = ((0.95, 0.25, 0.30), (0.55, 0.85, 0.15), (0.25, 0.55, 1.0))
        self.dirs = []
        for i in range(MAX_DIRS):
            col = colors[i] if i < 3 else (1.0, 0.6, 0.1)
            gz = self.gizmos.new("GIZMO_GT_arrow_3d")
            props = gz.target_set_operator("mesh.axis_snap_move")
            props.axis = i
            gz.color = col
            gz.alpha = 0.9
            gz.color_highlight = (1.0, 1.0, 1.0)
            gz.alpha_highlight = 1.0
            gz.scale_basis = 0.9
            gz.use_draw_modal = True
            self.arrows.append(gz)
        self.center = None

    def _place(self, context):
        c = _LIVE["center"] if _LIVE["center"] is not None else self.center
        if c is None:
            for gz in self.arrows:
                gz.hide = True
            return
        axes = self.dirs
        for i, gz in enumerate(self.arrows):
            if i >= len(axes):
                gz.hide = True
                continue
            ax = axes[i]
            gz.hide = False
            rot = Vector((0.0, 0.0, 1.0)).rotation_difference(ax).to_matrix().to_4x4()
            gz.matrix_basis = Matrix.Translation(c) @ rot

    def refresh(self, context):
        self.center = _selection_center(context)
        self.dirs = _axis_vectors(context)
        orient = context.scene.cmove_orient
        for i, gz in enumerate(self.arrows):
            col = (0.95, 0.25, 0.30), (0.55, 0.85, 0.15), (0.25, 0.55, 1.0)
            gz.color = col[i] if (i < 3 and orient in {'GLOBAL', 'LOCAL', 'NORMAL'}) else (1.0, 0.6, 0.1)
        self._place(context)

    def _key(self, context):
        k = [context.scene.cmove_orient]
        for obj in context.objects_in_mode_unique_data:
            if obj.type != 'MESH':
                continue
            d = obj.data
            hist = -1
            try:
                h = bmesh.from_edit_mesh(d).select_history.active
                hist = h.index if h is not None else -1
            except Exception:
                pass
            k.append((obj.name, d.total_vert_sel, d.total_edge_sel, d.total_face_sel, hist))
        return tuple(k)

    def draw_prepare(self, context):
        if _LIVE["center"] is None:
            key = self._key(context)
            if key != getattr(self, "_last_key", None):
                self._last_key = key
                self.refresh(context)
                return
        self._place(context)


class CMOVE_TOOL_axis_move(bpy.types.WorkSpaceTool):
    bl_space_type = 'VIEW_3D'
    bl_context_mode = 'EDIT_MESH'
    bl_idname = "cmove.axis_move_tool"
    bl_label = "Axis Move (Snap)"
    bl_description = ("Drag an axis handle to move along it. Move the mouse near another vertex to snap "
                      "to it (projected onto the axis). Ctrl flips snapping, type a number for an "
                      "exact distance. Click selects, drag selects a box")
    bl_icon = "ops.transform.translate"
    bl_widget = "CMOVE_GGT_axis_move"
    bl_keymap = _TOOL_SELECT_KEYMAP + (
        ("view3d.select_box", {"type": 'LEFTMOUSE', "value": 'CLICK_DRAG'},
         {"properties": [("mode", 'SET')]}),
    )


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

class VIEW3D_PT_edit_constraints(bpy.types.Panel):
    bl_label = "Edit Constraints"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "T3D Tools"
    bl_parent_id = "TOOLKIT_PT_modeling"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def draw(self, context):
        s = context.scene
        col = self.layout.column(align=True)
        row = col.row(align=True)
        row.operator("mesh.constraint_none", text="None",
                     depress=(get_mode(s) == 'NONE'))
        row.prop(s, "cmove_edge", text="Edge", toggle=True)
        row.prop(s, "cmove_face", text="Face", toggle=True)
        row.prop(s, "cmove_normal", text="Normal", toggle=True)

        self.layout.prop(s, "cmove_follow")

        box = self.layout.box()
        box.label(text="Axis Move (Snap) tool")
        try:
            t = context.workspace.tools.from_space_view3d_mode(context.mode, create=False)
            box.label(text="Tool active: " + ("yes" if t is not None and t.idname == "cmove.axis_move_tool"
                                              else "no (pick it in the toolbar)"))
        except Exception:
            pass
        box.prop(s, "cmove_vsnap")
        if s.cmove_vsnap:
            box.prop(s, "cmove_snap_px")
        box.prop(s, "cmove_orient", text="Handles")

        col = self.layout.column(align=True)
        col.separator()
        col.label(text="Active for G, R, S and the")
        col.label(text="Constrained Move/Rotate/Scale tools")
        col.label(text="Blender's own gizmos are not affected:")
        col.label(text="use the Axis Move (Snap) tool for a gizmo")
        col.separator()
        col.label(text="While transforming:")
        col.label(text="E Edge  F Face  N Normal  C None")
        col.label(text="Type a number for an exact value")
        col.label(text="X/Y/Z axis (R and S), Shift = plane")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

classes = (
    MESH_OT_constraint_none,
    MESH_OT_constrained_move,
    MESH_OT_constrained_rotate,
    MESH_OT_constrained_scale,
    MESH_OT_axis_snap_move,
    CMOVE_GGT_axis_move,
    VIEW3D_PT_edit_constraints,
)


def register():
    bpy.types.Scene.cmove_edge = BoolProperty(
        name="Edge", description="Constrain movement to the adjacent edges",
        default=False, update=_exclusive("cmove_edge"))
    bpy.types.Scene.cmove_face = BoolProperty(
        name="Face", description="Constrain movement to the surface of the adjacent faces",
        default=False, update=_exclusive("cmove_face"))
    bpy.types.Scene.cmove_normal = BoolProperty(
        name="Normal", description="Constrain movement to the vertex normal",
        default=False, update=_exclusive("cmove_normal"))
    bpy.types.Scene.cmove_follow = BoolProperty(
        name="Follow Active",
        description=("When moving: only the active (last selected) vertex is constrained; the "
                     "other selected vertices follow it with the exact same displacement, "
                     "unconstrained"),
        default=False)

    bpy.types.Scene.cmove_vsnap = BoolProperty(
        name="Snap to Vertices",
        description="Axis Move tool: snap to the other vertices (Ctrl flips this while dragging)",
        default=True)
    bpy.types.Scene.cmove_snap_px = bpy.props.IntProperty(
        name="Snap Distance (px)", description="How close the mouse has to be to a vertex to snap",
        default=28, min=4, max=120)
    bpy.types.Scene.cmove_orient = bpy.props.EnumProperty(
        name="Handles", default='EDGE',
        items=[('EDGE', "Edges", "One handle per edge leaving the selection: follows the edges"),
               ('NORMAL', "Normal", "Along the vertex normal and two tangents"),
               ('GLOBAL', "Global", "World axes"),
               ('LOCAL', "Local", "Axes of the active object")])

    for c in classes:
        bpy.utils.register_class(c)

    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="Mesh", space_type='EMPTY')
        for idname, key in ((MESH_OT_constrained_move.bl_idname, 'G'),
                            (MESH_OT_constrained_rotate.bl_idname, 'R'),
                            (MESH_OT_constrained_scale.bl_idname, 'S')):
            addon_keymaps.append((km, km.keymap_items.new(idname, key, 'PRESS')))

    bpy.utils.register_tool(CMOVE_TOOL_move, after={"builtin.transform"}, separator=True)
    bpy.utils.register_tool(CMOVE_TOOL_rotate, after={CMOVE_TOOL_move.bl_idname})
    bpy.utils.register_tool(CMOVE_TOOL_scale, after={CMOVE_TOOL_rotate.bl_idname})
    bpy.utils.register_tool(CMOVE_TOOL_axis_move, after={CMOVE_TOOL_scale.bl_idname})


def unregister():
    bpy.utils.unregister_tool(CMOVE_TOOL_axis_move)
    bpy.utils.unregister_tool(CMOVE_TOOL_scale)
    bpy.utils.unregister_tool(CMOVE_TOOL_rotate)
    bpy.utils.unregister_tool(CMOVE_TOOL_move)

    for km, kmi in addon_keymaps:
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()

    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    del bpy.types.Scene.cmove_edge
    del bpy.types.Scene.cmove_face
    del bpy.types.Scene.cmove_normal
    del bpy.types.Scene.cmove_follow
    del bpy.types.Scene.cmove_vsnap
    del bpy.types.Scene.cmove_snap_px
    del bpy.types.Scene.cmove_orient


if __name__ == "__main__":
    register()
